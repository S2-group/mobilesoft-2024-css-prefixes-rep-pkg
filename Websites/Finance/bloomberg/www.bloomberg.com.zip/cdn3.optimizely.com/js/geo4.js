(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "GALATI",
      'continent': "EU",
      'country': "RO",
      'region': "",
      'dma': ""
    },
    'ip':"5.13.229.208"
  }]);
})
//
()

;