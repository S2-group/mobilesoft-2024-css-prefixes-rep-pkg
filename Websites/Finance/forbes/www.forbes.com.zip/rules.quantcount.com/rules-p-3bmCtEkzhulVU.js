/*
 Quantcast measurement tag
 Copyright (c) 2008-2019, Quantcast Corp.
*/
(function(h,l,m){var e=function(c){return c.replace(/^[\s\ufeff\xA0]+|[\s\ufeff\xA0]+$/g,"")},k=function(c,b){if(!b)return b;var d,a;d=-1!==c.toLowerCase().indexOf("tag")||-1!==c.toLowerCase().indexOf("keyword")||0===c.toLowerCase().indexOf("qc:");a=-1===c.toLowerCase().indexOf("tag")&&-1===c.toLowerCase().indexOf("keyword")&&0===c.toLowerCase().indexOf("qc:")?!1:!0;a&&(b=b.replace(/\.+/g," "));if(d){a=b.split(",");for(d=0;d<a.length;d++)a[d]=e(a[d]);return a}return e(b.replace(/,+/g," "))};__qc.apply(null,
["rules",[h,null,[[function(c,b){var d=[],a;if("array"==={}.toString.call(b).match(/\s([a-zA-Z]+)/)[1].toLowerCase()){for(a=0;a<b.length;a++)d.push(c+"."+b[a]);return{labels:d.join(",")}}return{labels:c+"."+b}},"Title"]],[[function(c,b,d){b=document.getElementsByTagName("meta");for(var a,e,f=[],g=0;g<b.length;g++)a=b[g],e=a.getAttribute("name")||a.getAttribute("property"),e==d&&(f=f.concat(k(d,a.getAttribute("content"))));0<f.length?c(f):c(!1)},"exactmatch","og:title"]]]])})("p-3bmCtEkzhulVU",window,
document);