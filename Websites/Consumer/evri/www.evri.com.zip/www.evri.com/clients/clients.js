window.clients={
  "2593": {
    "clientName": "Currentbody",
    "clientLogo": "https://images.prismic.io/ev-mercury/5bcfad4c-20ec-4a72-9b2e-ea3e2c85674e_current.png?auto=compress,format"
  },
  "4658": {
    "clientName": "Mobile Fun Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/bfafc1b4-12e6-432e-94c0-0f81b4358658_Circle-Icon-Primary+%281%29+%28002%29.png?auto=compress,format"
  },
  "5140": {
    "clientName": "Branded Garden Products",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5256": {
    "clientName": "Gym King",
    "clientLogo": "https://images.prismic.io/ev-mercury/92e5795a-0f54-46e3-a529-8aded28632e8_GK+Logo.png?auto=compress,format"
  },
  "5469": {
    "clientName": "Dennys Brands",
    "clientLogo": "https://images.prismic.io/ev-mercury/9cec1060-b65b-4520-91d0-bdc557dbce71_dennys+brand.png?auto=compress,format"
  },
  "2620_3": {
    "clientName": "XBite",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26200003app.png"
  },
  "825_7": {
    "clientName": "Clearance 365",
    "clientLogo": null
  },
  "2770_6": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "62_0": {
    "clientName": "Quiz Clothing",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/quiz.png"
  },
  "631_108": {
    "clientName": "Delphis Eco Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/f3ce5d32-848e-48c7-9a6f-cafa1a8db433_delphis+logo.png?auto=compress,format"
  },
  "652_60": {
    "clientName": "StoreMore",
    "clientLogo": null
  },
  "2217_7": {
    "clientName": "Project J",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/logo-cropped-1-.png"
  },
  "276_0": {
    "clientName": "PrettyLittleThing",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/prettylittlething.png"
  },
  "2216_0": {
    "clientName": "Pound Fabrics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pound_fabrics_logo.png"
  },
  "652_30": {
    "clientName": "Tidy Books",
    "clientLogo": null
  },
  "404_0": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos.png"
  },
  "665_2": {
    "clientName": "Topman",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/topman.png"
  },
  "827_5": {
    "clientName": "Carvela",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/carvela_logo.jpg"
  },
  "840_4": {
    "clientName": "Look Again",
    "clientLogo": null
  },
  "4028_19": {
    "clientName": "SWAROVSKI AG",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280019app.png"
  },
  "914_2": {
    "clientName": "The Fulfilling Station",
    "clientLogo": null
  },
  "628_6": {
    "clientName": "HOUSE OF BATH",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "551_42": {
    "clientName": "Amour Group Limited",
    "clientLogo": null
  },
  "652_16": {
    "clientName": "Liberty House Toys",
    "clientLogo": null
  },
  "161_7": {
    "clientName": "QVC free returns",
    "clientLogo": null
  },
  "1963_0": {
    "clientName": "WBYS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/wbys-logo.png"
  },
  "2698_0": {
    "clientName": "Converse",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "1056_5": {
    "clientName": "Landmark PL",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_10": {
    "clientName": "Bradley Furniture",
    "clientLogo": null
  },
  "473_27": {
    "clientName": "Prodigy ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "403_0": {
    "clientName": "WOOD FINISHES DIRECT LTD",
    "clientLogo": null
  },
  "251_0": {
    "clientName": "Rapha Racing ",
    "clientLogo": "https://images.prismic.io/ev-mercury/60f1abea-2693-4333-9104-10562847c101_RAPHA+LOGO+144X144.jpg?auto=compress,format"
  },
  "2579_0": {
    "clientName": "Atom Supplies Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25790000app.png"
  },
  "2216_1": {
    "clientName": "Free Returns",
    "clientLogo": null
  },
  "2371_0": {
    "clientName": "Geodis",
    "clientLogo": null
  },
  "473_18": {
    "clientName": "Denzel's",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "1073_0": {
    "clientName": "The Sleep People",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sleep-people-new-logo.png"
  },
  "2219_0": {
    "clientName": "Luno Fashion",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/luno-fashion-logo.jpg"
  },
  "364_1": {
    "clientName": "Diet Chef",
    "clientLogo": null
  },
  "1050_0": {
    "clientName": "Berghaus",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/berghaus.png"
  },
  "652_66": {
    "clientName": "Rob McAlister",
    "clientLogo": null
  },
  "272_2": {
    "clientName": "Online",
    "clientLogo": null
  },
  "921_25": {
    "clientName": "HipStore",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hip-logo-144x144.jpg"
  },
  "209_0": {
    "clientName": "Disney Store",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/disneystore.png"
  },
  "36_0": {
    "clientName": "LSE Retail Group LTD",
    "clientLogo": null
  },
  "492_47": {
    "clientName": "Topshop",
    "clientLogo": null
  },
  "2593_0": {
    "clientName": "Currentbody",
    "clientLogo": "https://images.prismic.io/ev-mercury/2fd1e235-fe2c-487a-b343-8f75d67b05ae_CB.png?auto=compress,format"
  },
  "652_13": {
    "clientName": "Deluxe Beds",
    "clientLogo": null
  },
  "898_0": {
    "clientName": "Despatch Bay",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/despatch-bay-newlogo.png"
  },
  "184_0": {
    "clientName": "Regatta",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/regatta.png"
  },
  "652_133": {
    "clientName": "Sincere Home and Leisure",
    "clientLogo": null
  },
  "746_0": {
    "clientName": "Supergroup Internet Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/9756e201-f6ab-493a-ac12-7b3af07ac281_Superdry-Logo-768x480+%28002%29+resized.png?auto=compress,format"
  },
  "408_9": {
    "clientName": "Ellesse",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ellesse2.png"
  },
  "151_44": {
    "clientName": "Sports Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1510044app.png"
  },
  "921_8": {
    "clientName": "Tessuti",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tessuti.png"
  },
  "2308_0": {
    "clientName": "VAX",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23080000app.png"
  },
  "109_2": {
    "clientName": "Untuckit",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4633_0": {
    "clientName": "Trophi Logistics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5148_0": {
    "clientName": "Criminal Damage Clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "120_0": {
    "clientName": "Party Avenue Ltd",
    "clientLogo": null
  },
  "128_0": {
    "clientName": "Stitch Fix UK Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/stitchfix.png"
  },
  "520_1": {
    "clientName": "Joe Browns L&L",
    "clientLogo": null
  },
  "193_0": {
    "clientName": "Boux Avenue",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/boux-ave-logonew.png"
  },
  "634_2": {
    "clientName": "Jogonagain",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2460_0": {
    "clientName": "LOVALL",
    "clientLogo": "https://images.prismic.io/ev-mercury/cbceee80-fea6-41a2-911d-0363a437f655_lovall+circle+logo.png?auto=compress,format"
  },
  "662_12": {
    "clientName": "BGP Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/2ef063dd-ce77-4bf9-90e6-23ff49d9fcec_bgp+circle+logo.png?auto=compress,format"
  },
  "5091_1": {
    "clientName": "Big Matts Menswear",
    "clientLogo": "https://images.prismic.io/ev-mercury/9b908319-d4b8-4e54-973f-ae77e8a2c3b8_BIG+MATTS+%281%29+resized.png?auto=compress,format"
  },
  "2149_1": {
    "clientName": "MakeBox & Co",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21490001.png"
  },
  "914_35": {
    "clientName": "Garden Pride Marketing Ltd",
    "clientLogo": null
  },
  "160_19": {
    "clientName": "Tightlines Direct",
    "clientLogo": null
  },
  "667_49": {
    "clientName": "Taunton 1",
    "clientLogo": null
  },
  "95_1": {
    "clientName": "XL Rinkit",
    "clientLogo": null
  },
  "595_3": {
    "clientName": "SEBAGO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sebago-logo.jpg"
  },
  "4075_0": {
    "clientName": "Trade Chem",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_86": {
    "clientName": "ForestGarden",
    "clientLogo": null
  },
  "1942_7": {
    "clientName": "Au Vodka",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/19420007app.png"
  },
  "5062_1": {
    "clientName": "Hawes and Curtis",
    "clientLogo": "https://images.prismic.io/ev-mercury/d5d28987-8d63-4e58-8757-b7f39e0927f0_hawes.PNG?auto=compress,format"
  },
  "606_0": {
    "clientName": "ITD",
    "clientLogo": null
  },
  "254_0": {
    "clientName": "Printerpix",
    "clientLogo": null
  },
  "667_54": {
    "clientName": "Watford 2",
    "clientLogo": null
  },
  "976_0": {
    "clientName": "Dobbies",
    "clientLogo": null
  },
  "0_0": {
    "clientName": "Individual Client",
    "clientLogo": null
  },
  "5110_1": {
    "clientName": "Party Delights",
    "clientLogo": "https://images.prismic.io/ev-mercury/dc90c9e8-c46a-4ec9-8574-9c2145a1d80e_Party+delights+logo.png?auto=compress,format"
  },
  "628_2": {
    "clientName": "CLASSIC CONFIDENCE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "315_0": {
    "clientName": "Calzedonia-Intimissimi-Tezenis",
    "clientLogo": null
  },
  "652_104": {
    "clientName": "Owl Ltd",
    "clientLogo": null
  },
  "253_14": {
    "clientName": "Ness",
    "clientLogo": null
  },
  "652_21": {
    "clientName": "Eden H Limited",
    "clientLogo": null
  },
  "3733_0": {
    "clientName": "Upcycle Labs",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "914_21": {
    "clientName": "Restmor Limited",
    "clientLogo": null
  },
  "631_121": {
    "clientName": "Roam",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2607_0": {
    "clientName": "The Bottle Club",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-bottle-club-logo.png"
  },
  "178_6": {
    "clientName": "FSW LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2509_0": {
    "clientName": "Mamas & Papas",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mamaspapas.png"
  },
  "2425_0": {
    "clientName": "Tog24",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/144x144px-tog24.png"
  },
  "2443_3": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2067_0": {
    "clientName": "POSTLINK",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "339_8": {
    "clientName": "Gola & Jog On Again",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "164_0": {
    "clientName": "Chemist Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1640000app.png"
  },
  "4650_0": {
    "clientName": "CSM Logistics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2715_0": {
    "clientName": "Shein",
    "clientLogo": null
  },
  "811_31": {
    "clientName": "MORI",
    "clientLogo": "https://images.prismic.io/ev-mercury/7f4306de-57d1-4998-9b1e-7d346b81fa9e_MORI_logo_2000x2000+%28002%29.jpg?auto=compress,format"
  },
  "947_0": {
    "clientName": "Pilot",
    "clientLogo": null
  },
  "4062_0": {
    "clientName": "Red Ox Fashion",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_155": {
    "clientName": "Plentific Ltd",
    "clientLogo": null
  },
  "653_14": {
    "clientName": "Motorworld",
    "clientLogo": null
  },
  "4665_0": {
    "clientName": "J&T International",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "272_3": {
    "clientName": "Genflow",
    "clientLogo": null
  },
  "5344_0": {
    "clientName": "Your Ink & Toner Delivery",
    "clientLogo": "https://images.prismic.io/ev-mercury/08810a6d-4262-4a4b-9314-0bcd62d4726c_YourInkTonerDelivery.png?auto=compress,format"
  },
  "3636_4": {
    "clientName": "Goodyear Workwear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4029_20": {
    "clientName": "SWAROVSKI ONLINE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280020app.png"
  },
  "742_4": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos1.png"
  },
  "2376_3": {
    "clientName": "Edutrayplay Ltd",
    "clientLogo": null
  },
  "3735_0": {
    "clientName": "True Traders",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "168_0": {
    "clientName": "M&S",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ms.png"
  },
  "1944_0": {
    "clientName": "Transglobal Express Limited ",
    "clientLogo": null
  },
  "334_1": {
    "clientName": "Photobox",
    "clientLogo": null
  },
  "39_19": {
    "clientName": "Atlantic Therapeutics ",
    "clientLogo": null
  },
  "875_004": {
    "clientName": "Very Yours Clothing",
    "clientLogo": null
  },
  "652_125": {
    "clientName": "Nourison 8047",
    "clientLogo": null
  },
  "178_1": {
    "clientName": "Shield Autocare",
    "clientLogo": null
  },
  "2655_0": {
    "clientName": "Fragrance Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/144x144-fd-logo_.jpg"
  },
  "364_3": {
    "clientName": "Parsley Box",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/parsley-box.png"
  },
  "652_152": {
    "clientName": "Carolina Chair & Table Co",
    "clientLogo": null
  },
  "652_76": {
    "clientName": "Suncast",
    "clientLogo": null
  },
  "1004_3": {
    "clientName": "KWT",
    "clientLogo": null
  },
  "5512_0": {
    "clientName": "Coconut Merchant",
    "clientLogo": "https://images.prismic.io/ev-mercury/fab90844-faa9-42cd-ac74-06ba1d20fdc3_logo+18.05.png?auto=compress,format"
  },
  "550_34": {
    "clientName": "Evri",
    "clientLogo": null
  },
  "4028_12": {
    "clientName": "Tennis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280012app.png"
  },
  "2351_0": {
    "clientName": "Home Garden Ornaments",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23510000app.png"
  },
  "4514_8": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "332_0": {
    "clientName": "Bonmarche",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/bm-logo.png"
  },
  "113_0": {
    "clientName": "Debenhams Plymouth",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "975_76": {
    "clientName": "Daily Paper Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "667_30": {
    "clientName": "Guildford 2",
    "clientLogo": null
  },
  "762_2": {
    "clientName": "Create and Craft",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/cc-logo.png"
  },
  "5067_9": {
    "clientName": "CB",
    "clientLogo": "https://images.prismic.io/ev-mercury/c76ad1e2-096a-4fb3-aab1-340d34999469_CB.png?auto=compress,format"
  },
  "2428_0": {
    "clientName": "Lloyds Pharmacy",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24280000app.png"
  },
  "313_18": {
    "clientName": "Hornby Hobbies Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hornbyhobbiesltd.png"
  },
  "736_0": {
    "clientName": "Wynsors World of Shoes",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wynsors.png"
  },
  "2111_2": {
    "clientName": "Lucie Annabel",
    "clientLogo": "https://images.prismic.io/ev-mercury/d6f4f86d-294f-4bce-8e15-0c78f7ced6b8_annabel.png?auto=compress,format"
  },
  "822_0": {
    "clientName": "Home Bargains",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8220000app.png"
  },
  "268_0": {
    "clientName": "Blacks-Sorted",
    "clientLogo": null
  },
  "3650_0": {
    "clientName": "Forever Unique",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "355_0": {
    "clientName": "Seahaven Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/seahaven.png"
  },
  "74_0": {
    "clientName": "A.K Garments Ltd",
    "clientLogo": null
  },
  "662_10": {
    "clientName": "T&M",
    "clientLogo": "https://images.prismic.io/ev-mercury/f5154fe4-3d4c-4a19-9f27-584d3a772747_t%26m+circle+logo.png?auto=compress,format"
  },
  "652_19": {
    "clientName": "The Original Bedstead Company",
    "clientLogo": null
  },
  "974_97": {
    "clientName": "Stussy UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/4bd2f236-63e9-4167-9b06-c0d4bd8deda4_Stussy+Logo+resized.JPEG?auto=compress,format"
  },
  "948_0": {
    "clientName": "Ultimate Outdoors Sorted",
    "clientLogo": null
  },
  "829_3": {
    "clientName": "Paula's Choice",
    "clientLogo": "https://images.prismic.io/ev-mercury/e4e0643f-d591-456c-a41d-04922e7c90ae_paulas+choice.png?auto=compress,format"
  },
  "2749_26": {
    "clientName": "TWOTHIRDS",
    "clientLogo": "https://images.prismic.io/ev-mercury/5fa46a81-e8d6-4471-9162-15658c9057f7_TWOTHIRDS+bw+logo+%28002%29.jpg?auto=compress,format"
  },
  "975_74": {
    "clientName": "Zhik",
    "clientLogo": null
  },
  "1637_7": {
    "clientName": "Women&#8217;s Best",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/womes-best-1-.jpg"
  },
  "2443_0": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/terrys-logo.jpg"
  },
  "1004_5": {
    "clientName": "Huoyou",
    "clientLogo": null
  },
  "2749_21": {
    "clientName": "Melvin & Hamilton",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2653_001": {
    "clientName": "Syncreon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26530001app.png"
  },
  "892_4": {
    "clientName": "Game",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/game.png"
  },
  "4028_2": {
    "clientName": "IMPERICON",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280002app.png"
  },
  "652_151": {
    "clientName": "Carolina Chair & Table Co",
    "clientLogo": null
  },
  "828_0": {
    "clientName": "Navabi",
    "clientLogo": null
  },
  "272_0": {
    "clientName": "ProFS",
    "clientLogo": null
  },
  "4403_0": {
    "clientName": "FF 3P Warehouse",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5534_0": {
    "clientName": "Vape Club Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/c5de58b2-2cf0-4d01-9db1-30c361c54448_EVRi+Default+Logo.webp?auto=compress,format"
  },
  "093_0": {
    "clientName": "Coopers of Stortford",
    "clientLogo": null
  },
  "3703_0": {
    "clientName": "Eurotrade",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "1004_4": {
    "clientName": "BOXC",
    "clientLogo": null
  },
  "68_0": {
    "clientName": "Arsenal Football Club",
    "clientLogo": null
  },
  "5147_0": {
    "clientName": "Forma House Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/81117cbb-1859-4ae5-97ea-628fb5d25d65_logo+%28002%29+resized+16.2.jpg?auto=compress,format"
  },
  "5062_6": {
    "clientName": "Willy & Dilly Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/a1b2fe88-9af2-427e-a9e9-21fabd6554b5_W%26D_Logo_Evri_144x144pxs.jpg?auto=compress,format"
  },
  "670_2": {
    "clientName": "Andre",
    "clientLogo": null
  },
  "2749_13": {
    "clientName": "Schuhhaus Hittcher",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "674_3": {
    "clientName": "TargetDry",
    "clientLogo": null
  },
  "4028_5": {
    "clientName": "KONTRI SP",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280005app.png"
  },
  "2770_15": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "907_0": {
    "clientName": "Low energy supermarket",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lowenergy-cloud-commerce-logo.jpg"
  },
  "2648_0": {
    "clientName": "Fabletics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/0000001-fabletics.png"
  },
  "184_2": {
    "clientName": "Dare2B",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dare2b.png"
  },
  "520_0": {
    "clientName": "Joe Browns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/joebrowns.png"
  },
  "551_34": {
    "clientName": "Cotswold Trading",
    "clientLogo": null
  },
  "5242_1": {
    "clientName": "Real Watch Company",
    "clientLogo": "https://images.prismic.io/ev-mercury/eb24402d-a6bb-4ad6-bdc4-4ab2f276ad11_real+watch+logo.png?auto=compress,format"
  },
  "743_0": {
    "clientName": "Ideal World",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "831_83": {
    "clientName": "Midlands Associates",
    "clientLogo": null
  },
  "2461_0": {
    "clientName": "Nike",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24610000app.png"
  },
  "3731_0": {
    "clientName": "MK Warehousing LTD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_7": {
    "clientName": "T&G Woodware Ltd",
    "clientLogo": null
  },
  "253_77": {
    "clientName": "Moss Bros",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/moss-bros-logo.png"
  },
  "5648_0": {
    "clientName": "Triton Media Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/2fbc1d72-14df-4699-a5e3-59e9f4ef78cd_Office+point.png?auto=compress,format"
  },
  "982_1": {
    "clientName": "Big Red Tool Box",
    "clientLogo": null
  },
  "831_26": {
    "clientName": "RKW",
    "clientLogo": null
  },
  "5246_0": {
    "clientName": "Apparel Brands Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/dce78b16-68b9-42c3-9632-0c0a6299c66f_BENCH+LOGO+LARGE+%28002%29+resized.png?auto=compress,format"
  },
  "3636_5": {
    "clientName": "Iron Mountain",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "365_0": {
    "clientName": "The Styled Company Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-styled-company.png"
  },
  "652_81": {
    "clientName": "GROHELimited",
    "clientLogo": null
  },
  "4426_0": {
    "clientName": "More Years Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "865_0": {
    "clientName": "TJC",
    "clientLogo": null
  },
  "2699_7": {
    "clientName": "Workwear",
    "clientLogo": "https://images.prismic.io/ev-mercury/71444087-c512-4229-b08a-eab6881a6547_Workwear.png?auto=compress,format"
  },
  "87_0": {
    "clientName": "Lakeland",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "772_22": {
    "clientName": "Darphin",
    "clientLogo": null
  },
  "785_8": {
    "clientName": "Vedia",
    "clientLogo": null
  },
  "903_0": {
    "clientName": "Jon Richard Ltd",
    "clientLogo": null
  },
  "628_7": {
    "clientName": "J D WILLIAMS & CO. LTD.",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6280000app.png"
  },
  "551_45": {
    "clientName": "Last Word Apparel Limited",
    "clientLogo": null
  },
  "27_1": {
    "clientName": "Glasses Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/glasses-direct.png"
  },
  "921_138": {
    "clientName": "Naylors",
    "clientLogo": "https://images.prismic.io/ev-mercury/e263113b-99eb-4231-8902-28cdd3536820_naylors+logo.png?auto=compress,format"
  },
  "2511_6": {
    "clientName": "Nobody's Child",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nc-logo.png"
  },
  "3842_0": {
    "clientName": "Tropic Skincare Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tropic-144x144.jpg"
  },
  "831_33": {
    "clientName": "Prime Road",
    "clientLogo": null
  },
  "570_0": {
    "clientName": "N & S",
    "clientLogo": null
  },
  "1963_3": {
    "clientName": "School Shoes",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/sch-logo.png"
  },
  "87_1": {
    "clientName": "Lakeland for QVC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "914_18": {
    "clientName": "The Fulfilling Station",
    "clientLogo": null
  },
  "826_1": {
    "clientName": "Grattan",
    "clientLogo": null
  },
  "175_0": {
    "clientName": "JT ATKINSON & SONS LIMITED",
    "clientLogo": null
  },
  "975_95": {
    "clientName": "Cole Haan",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "248_2": {
    "clientName": "ITD Global 3",
    "clientLogo": null
  },
  "914_5": {
    "clientName": "General Traffic",
    "clientLogo": null
  },
  "104_0": {
    "clientName": "TESCO",
    "clientLogo": null
  },
  "551_5": {
    "clientName": "The Saville Row Trading Company",
    "clientLogo": null
  },
  "5189_0": {
    "clientName": "Caramella",
    "clientLogo": "https://images.prismic.io/ev-mercury/4803e130-2f5d-4712-9f11-c267e990fe17_Caramella_Logo+%28002%29.png?auto=compress,format"
  },
  "652_28": {
    "clientName": "Ergo CMS Industries Ltd",
    "clientLogo": null
  },
  "652_145": {
    "clientName": "Boscano Ltd",
    "clientLogo": null
  },
  "982_2": {
    "clientName": "Big Red Group - Capital Outdoors",
    "clientLogo": null
  },
  "460_44": {
    "clientName": "Sanderson",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2488_0": {
    "clientName": "Tools 2U Direct SW Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24880000.app.png"
  },
  "826_5": {
    "clientName": "Curvissa",
    "clientLogo": null
  },
  "3417_1": {
    "clientName": "Tucker French Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/plumb2u-logo-002-.png"
  },
  "460_25": {
    "clientName": "Lighting & Interiors Group Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "337_0": {
    "clientName": "Gap",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gap_logo.144x144.jpg"
  },
  "476_1": {
    "clientName": "TTK Express Europe",
    "clientLogo": null
  },
  "894_7": {
    "clientName": "Pop In A Box",
    "clientLogo": null
  },
  "150_17": {
    "clientName": "Pet Supermarket",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1500017app.png"
  },
  "2749_33": {
    "clientName": "Chowa",
    "clientLogo": "https://images.prismic.io/ev-mercury/3dcf395f-7641-488d-83d3-097ee8d79620_chowa.png?auto=compress,format"
  },
  "253_9": {
    "clientName": "Oliver Sweeney",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oliver-sweeney.png"
  },
  "5306_0": {
    "clientName": "Cheaper Online",
    "clientLogo": "https://images.prismic.io/ev-mercury/1148b700-b87d-4af1-9084-5d734d746be7_col-logo-144x144.png?auto=compress,format"
  },
  "188_0": {
    "clientName": "Just Fabulous",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/justfab.png"
  },
  "822_3": {
    "clientName": "Beast",
    "clientLogo": "https://images.prismic.io/ev-mercury/de60bd43-91e9-42f0-9fc8-a3c5540df031_Beast.png?auto=compress,format"
  },
  "149_8": {
    "clientName": "Crepe Erase",
    "clientLogo": null
  },
  "875_3": {
    "clientName": "Pixie Girls",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "430_0": {
    "clientName": "Clipper Logistics",
    "clientLogo": null
  },
  "2296_2": {
    "clientName": "Pinter",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5375_0": {
    "clientName": "FINITE IRRATIONAL LIMITED",
    "clientLogo": "https://images.prismic.io/ev-mercury/406b48f4-2ba8-42e6-9e22-05457f82684b_logo+2+18.5.png?auto=compress,format"
  },
  "2699_6": {
    "clientName": "Decorated clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/35d9fe60-def3-403f-9650-42e2ca841ebd_DECORATEDCLOTHING.png?auto=compress,format"
  },
  "537_0": {
    "clientName": "I Love Fancy Dress Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ilovefancydress.png"
  },
  "1056_10": {
    "clientName": "Landmark AP A",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "1016_0": {
    "clientName": "Buyaparcel.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/buyaparcel_horizontal_dark_.png"
  },
  "885_0": {
    "clientName": "Arvato Direct Injection",
    "clientLogo": null
  },
  "287_0": {
    "clientName": "GFS 3",
    "clientLogo": null
  },
  "127_0": {
    "clientName": "Wool and The Gang",
    "clientLogo": null
  },
  "5163_3": {
    "clientName": "Tupperware Direct",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "914_28": {
    "clientName": "Little Vic Trading ",
    "clientLogo": null
  },
  "66_0": {
    "clientName": "Mango",
    "clientLogo": null
  },
  "975_77": {
    "clientName": "Gymshark",
    "clientLogo": null
  },
  "2773_0": {
    "clientName": "Bolting Darts Ltd",
    "clientLogo": ""
  },
  "683_1": {
    "clientName": "BeautyBay - Beautybay.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beauty-bay.png"
  },
  "4527_0": {
    "clientName": "Amazon STN8",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "551_8": {
    "clientName": "Landmark Global",
    "clientLogo": null
  },
  "2620_5": {
    "clientName": "XBite",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26200005app.png"
  },
  "721_0": {
    "clientName": "FLYMAX",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/all-bags.png"
  },
  "354_0": {
    "clientName": "Aldi",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/aldi.png"
  },
  "218_0": {
    "clientName": "Advanced Supply Chain",
    "clientLogo": null
  },
  "2214_0": {
    "clientName": "Ibex Fulfilment Limited ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ibex-fulfilment-limited-logo.png"
  },
  "3946_0": {
    "clientName": "Tendring Express 2",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "784_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "359_0": {
    "clientName": "Baird Group ",
    "clientLogo": null
  },
  "4995_0": {
    "clientName": "Rapha returns ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "492_4": {
    "clientName": "Woolovers",
    "clientLogo": null
  },
  "220_0": {
    "clientName": "alpinetrek.co.uk",
    "clientLogo": "https://images.prismic.io/ev-mercury/23f7c85e-3f1c-4acd-a865-13fcc94c920b_144x144_UK_BF_CONDUIT_LOGO_4c_RGB_schwarz+%28002%29.png?auto=compress,format"
  },
  "1964_0": {
    "clientName": "Vale Mill",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "150_18": {
    "clientName": "PetMeds",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1500018app.png"
  },
  "2663_0": {
    "clientName": "Zapper",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/zapper-logo.jpg"
  },
  "652_51": {
    "clientName": "Pad UK",
    "clientLogo": null
  },
  "253_26": {
    "clientName": "Koi Footwear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/koi-footwear.png"
  },
  "538_2": {
    "clientName": "Rebound",
    "clientLogo": null
  },
  "894_11": {
    "clientName": "Platform L & L",
    "clientLogo": null
  },
  "1054_0": {
    "clientName": "Porcelain Superstore",
    "clientLogo": "https://images.prismic.io/ev-mercury/6e843b13-1e25-4340-9f28-a143e42ff555_Porcelain+superstore+logo+.png+circle.png?auto=compress,format"
  },
  "772_12": {
    "clientName": "MAC",
    "clientLogo": null
  },
  "890_0": {
    "clientName": "Fulfilment Service Centre",
    "clientLogo": null
  },
  "4431_0": {
    "clientName": "ADSN Solutions Ltd",
    "clientLogo": null
  },
  "272_4": {
    "clientName": "Internet",
    "clientLogo": null
  },
  "109_7": {
    "clientName": "Organo Gold",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "551_53": {
    "clientName": "The Naked Marshmallow",
    "clientLogo": null
  },
  "800_0": {
    "clientName": "Scent Global",
    "clientLogo": null
  },
  "652_162": {
    "clientName": "PlatinumSpa",
    "clientLogo": null
  },
  "772_36": {
    "clientName": "Frederic Malle",
    "clientLogo": null
  },
  "178_2": {
    "clientName": "Nome Trading",
    "clientLogo": null
  },
  "5386_0": {
    "clientName": "Q Retail Stores TA Dibor Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "831_31": {
    "clientName": "Hecom",
    "clientLogo": null
  },
  "310_1": {
    "clientName": "Connect",
    "clientLogo": null
  },
  "150_14": {
    "clientName": "Marketzone 1",
    "clientLogo": null
  },
  "2316_7": {
    "clientName": "Cake World",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4694_1": {
    "clientName": "Supercuts",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/46940001app.png"
  },
  "151_55": {
    "clientName": "GAME",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/game-logonew.png"
  },
  "5618_1": {
    "clientName": "Blue Guard",
    "clientLogo": "https://images.prismic.io/ev-mercury/8e953356-df6c-4b6d-b6cb-7e6869c32229_DF+Circle.png?auto=compress,format"
  },
  "460_43": {
    "clientName": "Candlelight",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "4514_6": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_157": {
    "clientName": "Adeco Trading",
    "clientLogo": null
  },
  "5557_1": {
    "clientName": "The Watch Hut",
    "clientLogo": "https://images.prismic.io/ev-mercury/98f34d43-798a-4b31-8db5-52f5de9d74d9_watch+shop.png?auto=compress,format"
  },
  "2717_0": {
    "clientName": "Makeup.uk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/makeup.uk-144x144.png"
  },
  "4514_7": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "667_24": {
    "clientName": "Croydon 4",
    "clientLogo": null
  },
  "914_27": {
    "clientName": "Cotswold Trading Broadway Ltd",
    "clientLogo": null
  },
  "628_15": {
    "clientName": "JDW - STAFF ACCOUNTS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6280000app.png"
  },
  "975_81": {
    "clientName": "SNS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "826_11": {
    "clientName": "Heine",
    "clientLogo": null
  },
  "434_0": {
    "clientName": "Dunelm",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dunelm.png"
  },
  "914_10": {
    "clientName": "Thane Direct UK Ltd",
    "clientLogo": null
  },
  "4913_0": {
    "clientName": "Ekosport Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "921_15": {
    "clientName": "JD Sports - ActivInstinct",
    "clientLogo": null
  },
  "133_5": {
    "clientName": "KD and Jay 25",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "652_158": {
    "clientName": "Maxim Lighting",
    "clientLogo": null
  },
  "2041_0": {
    "clientName": "Dreibach",
    "clientLogo": null
  },
  "4346_0": {
    "clientName": "Topparcel Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/00001-topparcel-ltd.jpg"
  },
  "3586_0": {
    "clientName": "Frames By Post",
    "clientLogo": "https://images.prismic.io/ev-mercury/e7824bef-a4f7-4ad1-a6df-9a2e9f4bb530_Frames+By+Post+Logo+PNG+144x144+px.png?auto=compress,format"
  },
  "4729_0": {
    "clientName": "CSM Logistics Swindon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "605_33": {
    "clientName": "Daye",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3825_0": {
    "clientName": "Desenio",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "667_10": {
    "clientName": "Bournemouth 2",
    "clientLogo": null
  },
  "652_165": {
    "clientName": "Harwood Textiles",
    "clientLogo": null
  },
  "603_0": {
    "clientName": "Photobox",
    "clientLogo": null
  },
  "772_21": {
    "clientName": "Aveda",
    "clientLogo": null
  },
  "166_0": {
    "clientName": "DOMU Brands",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/domu-brands.png"
  },
  "227_3": {
    "clientName": "Pegasus",
    "clientLogo": null
  },
  "2699_10": {
    "clientName": "Sportswear",
    "clientLogo": "https://images.prismic.io/ev-mercury/3b604cac-2d47-4071-a495-09a246e18d77_SPORTWEAR.png?auto=compress,format"
  },
  "97_0": {
    "clientName": "Debenhams OSSR",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "652_169": {
    "clientName": "J Rosenthal Son Ltd",
    "clientLogo": null
  },
  "631_29": {
    "clientName": "BTME Group",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310029app.png"
  },
  "368_3": {
    "clientName": "Hobbs",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hobbs.png"
  },
  "652_105": {
    "clientName": "nuLOOM Inc",
    "clientLogo": null
  },
  "975_12": {
    "clientName": "Gymshark",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gymshark.png"
  },
  "253_42": {
    "clientName": "Yawn",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/yawn_144x144.png"
  },
  "364_2": {
    "clientName": "Diet Now",
    "clientLogo": null
  },
  "2561_0": {
    "clientName": "Home Supplies Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25610000app.png"
  },
  "1423_0": {
    "clientName": "DFTest",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dftest_logo.jpg"
  },
  "614_0": {
    "clientName": "Boohoo",
    "clientLogo": null
  },
  "82_0": {
    "clientName": "RKW1",
    "clientLogo": null
  },
  "590_0": {
    "clientName": "Purl Apparel Ltd",
    "clientLogo": null
  },
  "125_1": {
    "clientName": "Sell It Back",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sell-it-back-logo.png"
  },
  "840_1": {
    "clientName": "Grattan",
    "clientLogo": null
  },
  "5067_1": {
    "clientName": "Vampire Vape ",
    "clientLogo": "https://images.prismic.io/ev-mercury/df89ba83-799e-475f-abae-13309bad8875_Vampire-100.jpg?auto=compress,format"
  },
  "674_7": {
    "clientName": "Ego Shoes",
    "clientLogo": null
  },
  "27_0": {
    "clientName": "MyOptique Group",
    "clientLogo": null
  },
  "5052_0": {
    "clientName": "Pineapple Island ",
    "clientLogo": "https://images.prismic.io/ev-mercury/9d8b0bcd-f853-451a-a584-251ac5900f28_Pineapple+Island+resized.jpg?auto=compress,format"
  },
  "551_29": {
    "clientName": "UK Surplus",
    "clientLogo": null
  },
  "653_1": {
    "clientName": "The Cake Decorating Company",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-cake-decorating-company.png"
  },
  "720_0": {
    "clientName": "Shoezone",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/shoezone.png"
  },
  "1056_0": {
    "clientName": "Landmark UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "992_0": {
    "clientName": "BorderGuru GmbH",
    "clientLogo": null
  },
  "4563_0": {
    "clientName": "Moccy Moo",
    "clientLogo": "https://images.prismic.io/ev-mercury/07320af8-ffb7-45ba-b395-1381e68a96e7_Moccy+moo+Evri+logo+144x144.png?auto=compress,format"
  },
  "4492_0": {
    "clientName": "Pink Vanilla",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pink-vanilla-logo-01-002-2-this-002-1-.png"
  },
  "492_34": {
    "clientName": "M and M Direct",
    "clientLogo": null
  },
  "652_64": {
    "clientName": "Vitavia",
    "clientLogo": null
  },
  "2770_10": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "662_7": {
    "clientName": "neat.",
    "clientLogo": "https://images.prismic.io/ev-mercury/668e665f-4030-420f-ba2f-2913f31f70c1_neat+logo.png?auto=compress,format"
  },
  "2273_0": {
    "clientName": "Easylife",
    "clientLogo": ""
  },
  "802_745": {
    "clientName": "Debenhams Direct - Debenhams",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "2625_0": {
    "clientName": "M&S - Bradford",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ms.png"
  },
  "103_4": {
    "clientName": "Victoria's Secret",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/vs.jpg"
  },
  "50_27": {
    "clientName": "Ikrush",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/500027tracking.png"
  },
  "171_0": {
    "clientName": "IN THE STYLE FASHION LTD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1710000.png"
  },
  "886_1": {
    "clientName": "eBedding",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ebedding.png"
  },
  "473_7": {
    "clientName": "GLTC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gltc_logo_cmyk-144x244px.jpg"
  },
  "914_13": {
    "clientName": "Kao UK Limited",
    "clientLogo": null
  },
  "551_17": {
    "clientName": "Evolution Vaping",
    "clientLogo": null
  },
  "1180_0": {
    "clientName": "Paragon Distribution Ltd",
    "clientLogo": null
  },
  "5108_2": {
    "clientName": "Chocolate Vault",
    "clientLogo": "https://images.prismic.io/ev-mercury/824a902b-8696-44c6-9e68-904e3c7ecd53_Chocolate+Vault.png?auto=compress,format"
  },
  "492_42": {
    "clientName": "Life Style Sports",
    "clientLogo": null
  },
  "894_0": {
    "clientName": "THG",
    "clientLogo": null
  },
  "652_98": {
    "clientName": "HighgateBedsLtd-Kingsmill",
    "clientLogo": null
  },
  "5067_6": {
    "clientName": "Vapestore",
    "clientLogo": "https://images.prismic.io/ev-mercury/f3cc58eb-3c9b-4db5-b18f-c5894593732d_VapeStore-100.jpg?auto=compress,format"
  },
  "708_0": {
    "clientName": "Trodakk Limited",
    "clientLogo": null
  },
  "628_18": {
    "clientName": "CRAZY CLEARANCE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams-2020-144x144.jpg"
  },
  "914_61": {
    "clientName": "The Dune Group",
    "clientLogo": null
  },
  "652_14": {
    "clientName": "Jeanie Accessories Ltd",
    "clientLogo": null
  },
  "829_9": {
    "clientName": "Karaca",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/karaca_144x144.jpg"
  },
  "551_60": {
    "clientName": "OPRO International Ltd",
    "clientLogo": null
  },
  "2306_2": {
    "clientName": "Together Health",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/togetherhealth_144x144.jpg"
  },
  "667_48": {
    "clientName": "Stoke On Trent 4",
    "clientLogo": null
  },
  "287_8": {
    "clientName": "Funky Chalk",
    "clientLogo": null
  },
  "2150_0": {
    "clientName": "Unibos",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/unibos-logonew.jpg"
  },
  "367_0": {
    "clientName": "Karabar Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/karabar_144x144.jpg"
  },
  "1853_0": {
    "clientName": "PLX",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "185_0": {
    "clientName": "Craghoppers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1850000app.png"
  },
  "357_0": {
    "clientName": "Northern Parrots",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/northern-parrots.png"
  },
  "628_13": {
    "clientName": "PREMIER MAN",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/premierman.png"
  },
  "1941_0": {
    "clientName": "Norsk Group",
    "clientLogo": null
  },
  "576_1": {
    "clientName": "Talk Talk",
    "clientLogo": null
  },
  "860_0": {
    "clientName": "TK Maxx",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tkmaxx.png"
  },
  "441_0": {
    "clientName": "The Book People",
    "clientLogo": null
  },
  "2749_2": {
    "clientName": "Alpin Loacker",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "662_11": {
    "clientName": "Suttons",
    "clientLogo": "https://images.prismic.io/ev-mercury/b4c02b7d-2da4-4cc0-9c4c-880431245e8b_suttons+circle+logo.png?auto=compress,format"
  },
  "2428_1": {
    "clientName": "Online Doctor",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24280001app.png"
  },
  "4091_0": {
    "clientName": "MBN Footwear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/011-ev0021-logo-resizing-for-print-in-store-devices_-web-and-app-mbn-footwear-144x144-1-.jpg"
  },
  "216_1": {
    "clientName": "ITD Global",
    "clientLogo": null
  },
  "496_0": {
    "clientName": "Hattons Model Railway",
    "clientLogo": null
  },
  "2730_10": {
    "clientName": "Linens Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e25646b2-555e-4dbb-9843-1a9035df3eb3_luxury+linen.png?auto=compress,format"
  },
  "772_2": {
    "clientName": "Aramis",
    "clientLogo": null
  },
  "109_11": {
    "clientName": "Active Ants",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3376_0": {
    "clientName": "Zendbox Fulfilment",
    "clientLogo": null
  },
  "652_61": {
    "clientName": "Natural Pet Products",
    "clientLogo": null
  },
  "227_2": {
    "clientName": "Chums Web",
    "clientLogo": null
  },
  "785_9": {
    "clientName": "Retro Years",
    "clientLogo": null
  },
  "831_121": {
    "clientName": "Techie Select",
    "clientLogo": "https://images.prismic.io/ev-mercury/c1be7217-b341-4dd3-aaa9-d0a20c7a735a_Techie+Select+Logo.png?auto=compress,format"
  },
  "492_26": {
    "clientName": "Hellmann Logistics",
    "clientLogo": null
  },
  "109_12": {
    "clientName": "Radial – Scentsy",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2358_0": {
    "clientName": "Burton",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23580000app.png"
  },
  "368_2": {
    "clientName": "Phase Eight",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/phaseeight.png"
  },
  "914_20": {
    "clientName": "Classic Football Shirts",
    "clientLogo": null
  },
  "620_12": {
    "clientName": "Lighting Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lighting-direct.png"
  },
  "5281_0": {
    "clientName": "XPO Transport Solutions UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "1963_2": {
    "clientName": "House of Slippers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/hos-logo.png"
  },
  "847_1": {
    "clientName": "Studio",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/studio-we-do-wow.png"
  },
  "5283_1": {
    "clientName": "Laura Mercier",
    "clientLogo": "https://images.prismic.io/ev-mercury/ed4bd5ad-de62-4dbd-a80c-6e44734bb2f9_DF+Circle+lauramercier.png?auto=compress,format"
  },
  "40_16": {
    "clientName": "Lamoda",
    "clientLogo": "https://images.prismic.io/ev-mercury/8c170e5b-9d20-4602-9cae-8a6f04bb890d_lamoda+circle.png?auto=compress,format"
  },
  "492_53": {
    "clientName": "Arbor Vita",
    "clientLogo": null
  },
  "492_6": {
    "clientName": "Millets",
    "clientLogo": null
  },
  "248_1": {
    "clientName": "ITD Global 1",
    "clientLogo": null
  },
  "253_22": {
    "clientName": "Aspiga",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/aspiga.png"
  },
  "886_8": {
    "clientName": "Rectella",
    "clientLogo": null
  },
  "894_10": {
    "clientName": "Zavvi",
    "clientLogo": "https://images.prismic.io/ev-mercury/4cd078b4-b42c-4215-9ad4-84d45cac2bd0_Zavvi+%28002%29+resized.jpg?auto=compress,format"
  },
  "822_1": {
    "clientName": "Home Bargains Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "766_0": {
    "clientName": "ShoeShoeBeDo Ltd",
    "clientLogo": null
  },
  "914_4": {
    "clientName": "Precious Little One",
    "clientLogo": null
  },
  "4414_0": {
    "clientName": "Save on Supplements",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "785_16": {
    "clientName": "Eckman Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/eckman-logo.png"
  },
  "3627_0": {
    "clientName": "Dip",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "59_0": {
    "clientName": "Vivo Technologies",
    "clientLogo": null
  },
  "273_0": {
    "clientName": "GFS 2",
    "clientLogo": null
  },
  "2749_30": {
    "clientName": "Displine",
    "clientLogo": "https://images.prismic.io/ev-mercury/5ca0562a-2431-4dfe-a918-db702b866ac8_displine.png?auto=compress,format"
  },
  "854_0": {
    "clientName": "Huxloe World Fulfilment",
    "clientLogo": null
  },
  "2111_1": {
    "clientName": "Lust Home",
    "clientLogo": "https://images.prismic.io/ev-mercury/ac96abb7-027e-4745-9d7c-1e9fc34adeaf_lusth.png?auto=compress,format"
  },
  "426_0": {
    "clientName": "Pure Luxuries",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pure-luxuries.png"
  },
  "5521_0": {
    "clientName": "Bitec",
    "clientLogo": "https://images.prismic.io/ev-mercury/1022dd2c-d252-4d1e-a502-92a76e5c2133_bitec+logo.png?auto=compress,format"
  },
  "914_30": {
    "clientName": "Cotswold Trading",
    "clientLogo": null
  },
  "125_0": {
    "clientName": "Wrap Distribution",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wrap-distribution.png"
  },
  "460_24": {
    "clientName": "Hill Interiors",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "826_0": {
    "clientName": "FGH Niche Brands",
    "clientLogo": null
  },
  "785_12": {
    "clientName": "Sound and Vision",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sound-vision-logo.png"
  },
  "1051_0": {
    "clientName": "Amazon",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2763_0": {
    "clientName": "Petshop.co.uk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/petsshop_144x144.jpg"
  },
  "248_3": {
    "clientName": "ITD Global 5",
    "clientLogo": null
  },
  "646_0": {
    "clientName": "Scotts & Co",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/scotts-co.png"
  },
  "4725_0": {
    "clientName": "CSM Logistics Middlesex",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "785_19": {
    "clientName": "Best Direct ",
    "clientLogo": "https://images.prismic.io/ev-mercury/23ff9417-7891-4d52-9d48-80a621f1d70b_BD_LOGO_140x140+%28002%29+resized+.png?auto=compress,format"
  },
  "975_66": {
    "clientName": "Sleep Easy",
    "clientLogo": null
  },
  "492_30": {
    "clientName": "Shoezone Ltd",
    "clientLogo": null
  },
  "652_118": {
    "clientName": "Anji Mountain Bamboo Rug Co",
    "clientLogo": null
  },
  "958_2": {
    "clientName": "Per-Scent",
    "clientLogo": null
  },
  "108_0": {
    "clientName": "Easylife",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/easylife-logo.png"
  },
  "683_0": {
    "clientName": "BeautyBay",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beauty-bay.png"
  },
  "2353_0": {
    "clientName": "Origin Broadband",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/origin_logo.png"
  },
  "631_113": {
    "clientName": "LWC Drinks",
    "clientLogo": "https://images.prismic.io/ev-mercury/91a82619-6cc2-4ce8-b077-f6190d234496_lwc+logo.png?auto=compress,format"
  },
  "952_0": {
    "clientName": "Docdata2",
    "clientLogo": null
  },
  "4345_0": {
    "clientName": "Charlotte Tilbury",
    "clientLogo": "https://images.prismic.io/ev-mercury/63f21b31-3bf9-4ba1-9d9f-4cf9fcb0a8b1_CT_Night+Crimson+%28002%29+resized+.png?auto=compress,format"
  },
  "2770_16": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "571_0": {
    "clientName": "Solodi",
    "clientLogo": null
  },
  "2378_0": {
    "clientName": "Sweaty Betty (Returns)",
    "clientLogo": null
  },
  "551_62": {
    "clientName": "Jersey Trading Limited",
    "clientLogo": null
  },
  "2384_0": {
    "clientName": "Benross",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23840000app.png"
  },
  "345_11": {
    "clientName": "Bamboo & Ambience Hardwood floor",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3450011app.png"
  },
  "2229_0": {
    "clientName": "The GC Organisation Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/babaclick-gc-organisation-logo.png"
  },
  "2077_0": {
    "clientName": "Brandfield",
    "clientLogo": null
  },
  "133_3": {
    "clientName": "UKBuyOnline",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "5211_0": {
    "clientName": "Kaico",
    "clientLogo": "https://images.prismic.io/ev-mercury/b83886c4-820f-48dc-8fff-235239019c20_kaico+resized.png?auto=compress,format"
  },
  "1681_0": {
    "clientName": "AP Motor Store Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ap-logo.png"
  },
  "5343_0": {
    "clientName": "Tackle Addicts",
    "clientLogo": "https://images.prismic.io/ev-mercury/76200ecc-7674-4887-8b8a-24b3e9fc8bed_Image.jpeg?auto=compress,format"
  },
  "628_14": {
    "clientName": "SIMPLY BE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/simply-be.png"
  },
  "5386_1": {
    "clientName": "Dibor Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e81562f2-9baf-4a9e-9242-21fda41b343e_Dibor+Logo.jpg?auto=compress,format"
  },
  "5053_0": {
    "clientName": "Stonemanor t/a Apricot",
    "clientLogo": "https://images.prismic.io/ev-mercury/a4e5f318-5599-4926-84ff-c885d78e7340_Picture1+resized.png?auto=compress,format"
  },
  "615_0": {
    "clientName": "ValueLights",
    "clientLogo": "https://images.prismic.io/ev-mercury/290523c6-178d-46ca-9d7c-7cd1235524b2_144x144+logo.png?auto=compress,format"
  },
  "676_0": {
    "clientName": "& Other Stories",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/andotherstories.png"
  },
  "253_54": {
    "clientName": "Curvy Kate",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5288_0": {
    "clientName": "JeanStore",
    "clientLogo": "https://images.prismic.io/ev-mercury/a23ae655-4d29-4bfa-b80b-e8017bf523e0_JEANSTORE_LOGO+resized.jpg?auto=compress,format"
  },
  "191_0": {
    "clientName": "Asendia Huxloe",
    "clientLogo": null
  },
  "5546_0": {
    "clientName": "Sass and Belle",
    "clientLogo": "https://images.prismic.io/ev-mercury/d80ad4f9-d0af-4b5b-9b4a-045afd90134a_sass+and+belle.png?auto=compress,format"
  },
  "395_5": {
    "clientName": "Bell Shoes Ltd.",
    "clientLogo": null
  },
  "492_50": {
    "clientName": "Burtons",
    "clientLogo": null
  },
  "287_158": {
    "clientName": "CLF Distribution Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/1453d282-2c84-437d-be7c-444666fbbc9a_clf+logo.png?auto=compress,format"
  },
  "5429_0": {
    "clientName": "Physique Management Company",
    "clientLogo": "https://images.prismic.io/ev-mercury/7c71d8a9-f6db-4eda-9d7d-f070a83f5ecc_Physique+Be+Confident+Logo+-+Evri.png?auto=compress,format"
  },
  "395_3": {
    "clientName": "GroupOn UK",
    "clientLogo": null
  },
  "442_0": {
    "clientName": "Dunelm",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dunelm.png"
  },
  "652_129": {
    "clientName": "Topeshop",
    "clientLogo": null
  },
  "129_0": {
    "clientName": "Debenhams Lakeside",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "840_9": {
    "clientName": "Bon Prix",
    "clientLogo": null
  },
  "886_14": {
    "clientName": "Nanu.co.uk",
    "clientLogo": null
  },
  "551_25": {
    "clientName": "Purrfect Pet Supplies",
    "clientLogo": null
  },
  "5497_0": {
    "clientName": "The Chuckling Cheese Company Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/d05608d6-d8e7-4eb8-885b-0c18aad84cf6_chuckling.png?auto=compress,format"
  },
  "850_0": {
    "clientName": "Petrol Scooter",
    "clientLogo": null
  },
  "748_1": {
    "clientName": "Achica",
    "clientLogo": null
  },
  "826_6": {
    "clientName": "Swimwear 365",
    "clientLogo": null
  },
  "2311_0": {
    "clientName": "Matalan",
    "clientLogo": "https://images.prismic.io/ev-mercury/00a10a87-3d5a-4114-a1db-0a0fd9115789_DF+Circle+%28002%29+3.png?auto=compress,format"
  },
  "1963_1": {
    "clientName": "Desert Shoes",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/des-logo.png"
  },
  "1209_1": {
    "clientName": "Vision Express UK",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ve_logo_144x144px-02-1-.png"
  },
  "875_1": {
    "clientName": "Badrhino",
    "clientLogo": null
  },
  "652_142": {
    "clientName": "ST Fencing Timber Products",
    "clientLogo": null
  },
  "103_8": {
    "clientName": "Joules",
    "clientLogo": "https://images.prismic.io/ev-mercury/698ba69b-b405-4ca3-a804-442b4b11f3f6_joules.png?auto=compress,format"
  },
  "840_0": {
    "clientName": "Freemans.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fgh.png"
  },
  "4255_0": {
    "clientName": "Coozo",
    "clientLogo": "https://images.prismic.io/ev-mercury/0fff0c8a-6fe7-44f3-81b3-c9a03b920f97_COOZO+Logo.PNG?auto=compress,format"
  },
  "3620_0": {
    "clientName": "Wells Supply Chain",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5242_2": {
    "clientName": "Designer Watch Shop",
    "clientLogo": "https://images.prismic.io/ev-mercury/76128d92-7308-4cbe-8ddb-0026de88c205_designer+logo.png?auto=compress,format"
  },
  "2390_3": {
    "clientName": "Scrub",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/scrub-logo.jpg"
  },
  "39_27": {
    "clientName": "Castore",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/castore-logo.png"
  },
  "267_2": {
    "clientName": "Animal",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/animal-logo.png"
  },
  "2738_3": {
    "clientName": "Blade & Rose",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/blade.png"
  },
  "3592_0": {
    "clientName": "Cloving.co.uk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/cloving-evri-logo2.png"
  },
  "5091_3": {
    "clientName": "Uptheir",
    "clientLogo": "https://images.prismic.io/ev-mercury/9b8b9807-64c9-407c-ad2a-af64d87e1ccc_UPT+logo+%281%29+resized+.png?auto=compress,format"
  },
  "133_7": {
    "clientName": "KD and Jay 75",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "652_128": {
    "clientName": "Vantona Home Ltd",
    "clientLogo": null
  },
  "329_3": {
    "clientName": "Ideal Home Interiors",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ideal-home-interiors.png"
  },
  "2596_0": {
    "clientName": "Skinny Food Company",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/0000001-skinny.png"
  },
  "460_6": {
    "clientName": "Pacific Lifestyle Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "490_0": {
    "clientName": "Consignor",
    "clientLogo": null
  },
  "652_83": {
    "clientName": "BelleekPotteryLtd",
    "clientLogo": null
  },
  "109_4": {
    "clientName": "Rain International",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "492_40": {
    "clientName": "Kiddicare",
    "clientLogo": null
  },
  "475_0": {
    "clientName": "AITRACK.COM",
    "clientLogo": null
  },
  "287_097": {
    "clientName": "Lost Universe",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2870097app.png"
  },
  "2605_0": {
    "clientName": "Bodykind",
    "clientLogo": "https://images.prismic.io/ev-mercury/976e1b00-13a3-4705-8c55-6bc54c7e106f_ITD+Bodykind+logo+%28002%29.png?auto=compress,format"
  },
  "990_0": {
    "clientName": "Finery London",
    "clientLogo": null
  },
  "1648_0": {
    "clientName": "Amazon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon.png"
  },
  "825_10": {
    "clientName": "Lascana",
    "clientLogo": null
  },
  "333_2": {
    "clientName": "Verage 2",
    "clientLogo": null
  },
  "3957_0": {
    "clientName": "Electoys",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "170_0": {
    "clientName": "Vitapoint",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/vitapoint.jpg"
  },
  "551_28": {
    "clientName": "Wayland Games",
    "clientLogo": null
  },
  "759_109": {
    "clientName": "Hub Europe - feelunique",
    "clientLogo": null
  },
  "253_33": {
    "clientName": "La Coqueta",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-coqueta.png"
  },
  "3945_0": {
    "clientName": "PB Retail",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pb-retail-logo-evri-002-.png"
  },
  "652_141": {
    "clientName": "EUProjectTimber",
    "clientLogo": null
  },
  "4_1": {
    "clientName": "GANT UK",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gant-logo.png"
  },
  "287_74": {
    "clientName": "Crew Clothing",
    "clientLogo": null
  },
  "615_1": {
    "clientName": "Value Lights",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/value-lights.png"
  },
  "652_154": {
    "clientName": "Cambertown Ltd",
    "clientLogo": null
  },
  "492_15": {
    "clientName": "To Your Home",
    "clientLogo": null
  },
  "77_0": {
    "clientName": "DG International",
    "clientLogo": null
  },
  "652_32": {
    "clientName": "Henry Watson Properties",
    "clientLogo": null
  },
  "287_6": {
    "clientName": "AGTC Ltd",
    "clientLogo": null
  },
  "551_6": {
    "clientName": "Little Mattress Company Limited",
    "clientLogo": null
  },
  "841_1": {
    "clientName": "Grattan",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/grattan.png"
  },
  "652652_122": {
    "clientName": "PKGreenEnterpriseLtd",
    "clientLogo": null
  },
  "2774_0": {
    "clientName": "Night Store",
    "clientLogo": null
  },
  "875_002": {
    "clientName": "Long Tall Sally",
    "clientLogo": null
  },
  "652_11": {
    "clientName": "Solar Technology",
    "clientLogo": null
  },
  "253_11": {
    "clientName": "I SAW IT FIRST",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/isif.png"
  },
  "791_0": {
    "clientName": "Core Fulfilment",
    "clientLogo": null
  },
  "84_1": {
    "clientName": "Boden",
    "clientLogo": "https://images.prismic.io/ev-mercury/4172ef69-b859-492b-a8f5-1d048fd1a55c_BODEN.png?auto=compress,format"
  },
  "2612_0": {
    "clientName": "Aspire Mattresses",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/aspire-144x144-logo-png..png"
  },
  "4985_0": {
    "clientName": "Flexzon",
    "clientLogo": "https://images.prismic.io/ev-mercury/1c3b4a8a-e36e-4a72-8275-014d722bc039_flexzon+logo+144x144.jpg?auto=compress,format"
  },
  "551_2": {
    "clientName": "Mamas & Papas",
    "clientLogo": null
  },
  "652_94": {
    "clientName": "TheCamouflageCo",
    "clientLogo": null
  },
  "670_3": {
    "clientName": "Rogers Test Tool",
    "clientLogo": null
  },
  "78_1": {
    "clientName": "Fetch",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fetch.png"
  },
  "2653_1": {
    "clientName": "Tech 21",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tech21_400x100.png"
  },
  "2465_0": {
    "clientName": "West Bromwich Albion FC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wba-crest-transparent-png.png"
  },
  "333_5": {
    "clientName": "Verage 5",
    "clientLogo": null
  },
  "1019_0": {
    "clientName": "BSL",
    "clientLogo": null
  },
  "2031_0": {
    "clientName": "GGN Intl Ltd ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ggn-logo.png"
  },
  "4442_0": {
    "clientName": "Exporto",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "370_0": {
    "clientName": "Selazar",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/selazar.png"
  },
  "628_17": {
    "clientName": "AMBROSE WILSON GOLD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ambrose-wilson.png"
  },
  "831_100": {
    "clientName": "HugglePets",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hugglepets-logo.png"
  },
  "2240_0": {
    "clientName": "Diva Gift Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/divagiftlogo.png"
  },
  "149_2": {
    "clientName": "Perricone",
    "clientLogo": null
  },
  "2101_0": {
    "clientName": "Toolstation",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21010000app.png"
  },
  "1963_4": {
    "clientName": "Shuperb",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/shuperb-logo.png"
  },
  "875_001": {
    "clientName": "Badrhino",
    "clientLogo": null
  },
  "2667_0": {
    "clientName": "M&S Personalised Schoolwear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ms.png"
  },
  "86_0": {
    "clientName": "Danbury Mint",
    "clientLogo": null
  },
  "492_22": {
    "clientName": "Cotton Traders 3",
    "clientLogo": null
  },
  "5195_0": {
    "clientName": "Deals Incorporated Ltd",
    "clientLogo": ""
  },
  "2383_0": {
    "clientName": "Marks and Spencer",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ms.png"
  },
  "3636_7": {
    "clientName": "Under Par Golf",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "660_0": {
    "clientName": "Redcats Ebay",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "287_135": {
    "clientName": "Girlguiding",
    "clientLogo": "https://images.prismic.io/ev-mercury/a6bbaefb-bb1c-45ea-92a5-ec253ccb7158_Primary+Corporate+Logo_Top+Left_Print+_+Web+Use+%28002%29.jpg?auto=compress,format"
  },
  "652_0": {
    "clientName": "Wayfair",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wayfair.png"
  },
  "5307_0": {
    "clientName": "ID Gaming Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/404c51d5-9087-4181-b8ac-746cca3f8a0d_id+gaming+logo.png?auto=compress,format"
  },
  "373_0": {
    "clientName": "SMART FORWARDING SMPC",
    "clientLogo": null
  },
  "631_32": {
    "clientName": "Misfits",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310032app.png"
  },
  "628_5": {
    "clientName": "HIGH AND MIGHTY",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/highandmighty.png"
  },
  "430_1": {
    "clientName": "KIDLY",
    "clientLogo": null
  },
  "312_2": {
    "clientName": "Glorious Gangsta",
    "clientLogo": null
  },
  "343_0": {
    "clientName": "Clarks Outlet Online",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/clarks.png"
  },
  "785_1": {
    "clientName": "Home Shopping Selections",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hss-logo.png"
  },
  "652_40": {
    "clientName": "Sixtrees Ltd",
    "clientLogo": null
  },
  "408_8": {
    "clientName": "Berghaus",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/berghaus2.png"
  },
  "798_0": {
    "clientName": "Frayte Global",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/frayte-global.png"
  },
  "2749_1": {
    "clientName": "Dirndl.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_123": {
    "clientName": "XclusiveDecor Ltd",
    "clientLogo": null
  },
  "840_5": {
    "clientName": "Curvissa",
    "clientLogo": null
  },
  "2723_0": {
    "clientName": "Evri",
    "clientLogo": null
  },
  "4751_0": {
    "clientName": "Jel Direct Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "825_9": {
    "clientName": "Bon Prix",
    "clientLogo": null
  },
  "742_2": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos1.png"
  },
  "715_0": {
    "clientName": "Nasty Gal",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nastygal.png"
  },
  "576_0": {
    "clientName": "Anovo UK Limited",
    "clientLogo": null
  },
  "253_1": {
    "clientName": "TM Lewin",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tm-lewin.png"
  },
  "311_0": {
    "clientName": "American Golf",
    "clientLogo": "https://images.prismic.io/ev-mercury/cdfd38ed-d6cf-44e2-b1c2-3c53fc7f68b3_144x144+%28002%29.jpg?auto=compress,format"
  },
  "395_1": {
    "clientName": "Goodwin Smith",
    "clientLogo": null
  },
  "852_0": {
    "clientName": "Hotter Shoes",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hotter.png"
  },
  "2495_0": {
    "clientName": "EVO LIFESTYLE PRODUCTS LIMITED",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/evo-lifestyle-logo.png"
  },
  "5258_1": {
    "clientName": "Littlewoolshop",
    "clientLogo": "https://images.prismic.io/ev-mercury/14c8e721-7346-44b9-9341-7e626a584b9f_little+wool.png?auto=compress,format"
  },
  "52_0": {
    "clientName": "Kingstown",
    "clientLogo": null
  },
  "785_6": {
    "clientName": "Stauer",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/stauer-logo.png"
  },
  "932_0": {
    "clientName": "Holland and Barrett",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/newhollandandbarrett.png"
  },
  "160_14": {
    "clientName": "Radio Times Offers",
    "clientLogo": null
  },
  "604_0": {
    "clientName": "Isagenix",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/isagenix.png"
  },
  "252_1": {
    "clientName": "B2C Europe - B2C Europe UK Stoke",
    "clientLogo": null
  },
  "3850_0": {
    "clientName": "VESPER247.COM LTD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/logo-003-.png"
  },
  "377_0": {
    "clientName": "Melrose Textiles",
    "clientLogo": null
  },
  "2443_6": {
    "clientName": "Terrys Fabrics ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2371_1": {
    "clientName": "Roxi",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/roxi_144x144.jpg"
  },
  "991_18": {
    "clientName": "Infinity Blue",
    "clientLogo": null
  },
  "4225_0": {
    "clientName": "Coozo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/0002-ev0021-logo-resizing-coozo-144x144.png"
  },
  "5351_0": {
    "clientName": "We Grow Webshops B.V.",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2770_21": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "716_2": {
    "clientName": "Hometex Enterprises",
    "clientLogo": null
  },
  "999_2": {
    "clientName": "myonlinepurchase",
    "clientLogo": null
  },
  "2295_0": {
    "clientName": "Justop Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/justop-logo.png"
  },
  "652_87": {
    "clientName": "Wayfair",
    "clientLogo": null
  },
  "4514_1": {
    "clientName": "Terry’s Fabric",
    "clientLogo": ""
  },
  "4646_2": {
    "clientName": "Direct Link Worldwide Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "160_4": {
    "clientName": "Express Reader Offers",
    "clientLogo": null
  },
  "3727_0": {
    "clientName": "Carsio",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5243_0": {
    "clientName": "Beam Group",
    "clientLogo": "https://images.prismic.io/ev-mercury/2b392afe-dbed-4eeb-a431-beb83c9d3199_BEAM.png?auto=compress,format"
  },
  "353_0": {
    "clientName": "Party Delights",
    "clientLogo": "https://images.prismic.io/ev-mercury/d21a31f2-60d8-4565-96dd-2fe2406ee1cf_1891039_686157858093156_392872262_n-350x350.jpg?auto=compress,format"
  },
  "2749_3": {
    "clientName": "Koro",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "303_1": {
    "clientName": "Curtains & Linens",
    "clientLogo": null
  },
  "5165_0": {
    "clientName": "Start-Rite Shoes",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2299_0": {
    "clientName": "JD.com London Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "913_0": {
    "clientName": "M and co",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2696_0": {
    "clientName": "Shein",
    "clientLogo": null
  },
  "3910_2": {
    "clientName": "Protected Species",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/39100002app.png"
  },
  "149_5": {
    "clientName": "Sheer Cover",
    "clientLogo": null
  },
  "667_1": {
    "clientName": "Birmingham 1",
    "clientLogo": null
  },
  "940_0": {
    "clientName": "Brooklyn Trading",
    "clientLogo": null
  },
  "103_6": {
    "clientName": "GAP",
    "clientLogo": "https://images.prismic.io/ev-mercury/7fa06381-bfd4-412d-82fe-f0619fd11bd8_Gap-Core%402x.jpg?auto=compress,format"
  },
  "2770_14": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "338_0": {
    "clientName": "Superdry eBay",
    "clientLogo": "https://images.prismic.io/ev-mercury/9756e201-f6ab-493a-ac12-7b3af07ac281_Superdry-Logo-768x480+%28002%29+resized.png?auto=compress,formathttps://images.prismic.io/ev-mercury/9756e201-f6ab-493a-ac12-7b3af07ac281_Superdry-Logo-768x480+%28002%29+resized.png?auto=compress,format"
  },
  "2496_1": {
    "clientName": "DUSK Collections ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "785_4": {
    "clientName": "Premier Offers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pod-logo.png"
  },
  "628_8": {
    "clientName": "JACAMO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jacamo.png"
  },
  "1020_0": {
    "clientName": "Evri",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/emails/default_client_logo.png"
  },
  "253_21": {
    "clientName": "M Life",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mlife.png"
  },
  "652_101": {
    "clientName": "GrangeFencing",
    "clientLogo": null
  },
  "772_33": {
    "clientName": "Smashbox",
    "clientLogo": null
  },
  "529_0": {
    "clientName": "To Your Home",
    "clientLogo": null
  },
  "492_12": {
    "clientName": "Litecraft",
    "clientLogo": null
  },
  "840_11": {
    "clientName": "Heine",
    "clientLogo": null
  },
  "1807_0": {
    "clientName": "Evri",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2728_0": {
    "clientName": "M&S - Thorncliffe",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ms.png"
  },
  "3404_0": {
    "clientName": "Wolfson Brands (UK) Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "1056_6": {
    "clientName": "Landmark Belgium",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_12": {
    "clientName": "JCC",
    "clientLogo": null
  },
  "473_1": {
    "clientName": "GHD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ghd.png"
  },
  "364_0": {
    "clientName": "Diet Chef",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/diet-chefpng.png"
  },
  "847_13": {
    "clientName": "Express Gifts- Failsworth",
    "clientLogo": null
  },
  "551_23": {
    "clientName": "UCrave Limited",
    "clientLogo": null
  },
  "5679_0": {
    "clientName": "Worst Behavior GmbH",
    "clientLogo": ""
  },
  "2749_4": {
    "clientName": "Colibri",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "492_46": {
    "clientName": "Wallis",
    "clientLogo": null
  },
  "492_45": {
    "clientName": "Evans",
    "clientLogo": null
  },
  "737_2": {
    "clientName": "CMS 1",
    "clientLogo": null
  },
  "652_26": {
    "clientName": "ScotColumbus",
    "clientLogo": null
  },
  "4534_0": {
    "clientName": "Moda Minx Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_168": {
    "clientName": "Turner Bianca",
    "clientLogo": null
  },
  "61_1": {
    "clientName": "BLK Dnm",
    "clientLogo": null
  },
  "817_0": {
    "clientName": "Allport Cargo Services",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "492_52": {
    "clientName": "BeerHawk",
    "clientLogo": null
  },
  "1013_1": {
    "clientName": "A-Z Packaging",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/global-logo.png"
  },
  "652_109": {
    "clientName": "GFDirectBradley",
    "clientLogo": null
  },
  "2318_0": {
    "clientName": "Homespares Centres",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/homespares-logo.jpg"
  },
  "249_0": {
    "clientName": "Lakeland Bliss",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "142_21": {
    "clientName": "London Store",
    "clientLogo": "https://images.prismic.io/ev-mercury/afbb8f19-3865-4b5b-9b97-bdb1a2339876_logo-bianco-2000x2000+%28002%29.png?auto=compress,format"
  },
  "317_0": {
    "clientName": "eTwist",
    "clientLogo": null
  },
  "345_2": {
    "clientName": "Eve Sleep PLC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/eve.png"
  },
  "652_71": {
    "clientName": "MerciaGardenProducts",
    "clientLogo": null
  },
  "483_0": {
    "clientName": "Cheerful Bargains Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/cheerful-bargains.png"
  },
  "887_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "786_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "2770_17": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "2730_8": {
    "clientName": "Julian Charles",
    "clientLogo": "https://images.prismic.io/ev-mercury/d6356333-b16d-4321-9d29-0805b7f4db08_Julian+Charles+%28002%29+resized.jpg?auto=compress,format"
  },
  "448_0": {
    "clientName": "UK Business Supplies",
    "clientLogo": null
  },
  "151_54": {
    "clientName": "Evans Cycles",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1510054app.png"
  },
  "921_5": {
    "clientName": "Millets",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/millets-logonew.png"
  },
  "652_117": {
    "clientName": "Tontarelli",
    "clientLogo": null
  },
  "149_7": {
    "clientName": "Wen",
    "clientLogo": null
  },
  "748_5": {
    "clientName": "ILWF",
    "clientLogo": null
  },
  "551_55": {
    "clientName": "Socal89 Ltd",
    "clientLogo": null
  },
  "5301_0": {
    "clientName": "Axel Agrito",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2217_5": {
    "clientName": "Chillys",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ev0021-logo-resizing-chillies-144x144.png"
  },
  "4118_0": {
    "clientName": "Dream and Fashion",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "428_0": {
    "clientName": "Hello Fresh",
    "clientLogo": null
  },
  "947_4": {
    "clientName": "Camper",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "1448_0": {
    "clientName": "Status Group ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/status_logo.png"
  },
  "4646_0": {
    "clientName": "Axel Arigato",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5510_0": {
    "clientName": "SUMAYAH LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/788375ed-1203-4591-8e45-4531614664dd_sumayah.png?auto=compress,format"
  },
  "5019_0": {
    "clientName": "Glamour Secrets",
    "clientLogo": "https://images.prismic.io/ev-mercury/58e1e654-d97d-4eaa-9d53-e9ef2b3332c3_heart-logo-550+%28002%29+144x144+5019.jpg?auto=compress,format"
  },
  "2197_0": {
    "clientName": "Delamode Printerpix",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "345_97": {
    "clientName": "Maru",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3450097app.png"
  },
  "745_0": {
    "clientName": "Debenhams Health and Beauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "975_22": {
    "clientName": "Evermerc",
    "clientLogo": null
  },
  "2443_2": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_59": {
    "clientName": "Sky Pet Products",
    "clientLogo": null
  },
  "811_26": {
    "clientName": "Islabikes Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/islabikes-ltd.png"
  },
  "137_0": {
    "clientName": "Benefit",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/benefit.png"
  },
  "78_2": {
    "clientName": "Fabled",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fabled.png"
  },
  "460_0": {
    "clientName": "La Redoute",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/4600000.png"
  },
  "149_3": {
    "clientName": "Principle secret",
    "clientLogo": null
  },
  "303_2": {
    "clientName": "Viceroy Bedding",
    "clientLogo": null
  },
  "160_24": {
    "clientName": "Old Gwernyfed",
    "clientLogo": null
  },
  "165_0": {
    "clientName": "Supergroup Internet Limited",
    "clientLogo": null
  },
  "522_0": {
    "clientName": "Whistl - Austria Post",
    "clientLogo": null
  },
  "4620_0": {
    "clientName": "SnackVerse Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/5ff58610-464a-43ef-a773-c90d9d1b5403_snackverse.png?auto=compress,format"
  },
  "40_5": {
    "clientName": "Shop Retail Direct (RB)",
    "clientLogo": null
  },
  "40_14": {
    "clientName": "Humans-Being",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2770_0": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "253_18": {
    "clientName": "Young Outlaws Club",
    "clientLogo": null
  },
  "2306_0": {
    "clientName": "Ogden Fulfilment",
    "clientLogo": null
  },
  "652_116": {
    "clientName": "LLYTech Inc",
    "clientLogo": null
  },
  "4028_6": {
    "clientName": "LUGINA",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280006app.png"
  },
  "275_0": {
    "clientName": "Oypla.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oypla-logo.png"
  },
  "5163_0": {
    "clientName": "High Street TV",
    "clientLogo": "https://images.prismic.io/ev-mercury/6da78b23-69d0-4ef2-9e69-eabc7f3a0a14_highstTV.png?auto=compress,format"
  },
  "551_27": {
    "clientName": "Thane Direct",
    "clientLogo": null
  },
  "417_0": {
    "clientName": "globalegrow",
    "clientLogo": null
  },
  "2339_0": {
    "clientName": "JK Commerce Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/larryroo-logo.jpg"
  },
  "61_0": {
    "clientName": "Matalan",
    "clientLogo": "https://images.prismic.io/ev-mercury/00a10a87-3d5a-4114-a1db-0a0fd9115789_DF+Circle+%28002%29+3.png?auto=compress,format"
  },
  "1016_1": {
    "clientName": "Buyaparcel 2",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/buyaparcel_horizontal_dark_.png"
  },
  "95_0": {
    "clientName": "Rinkit Limited",
    "clientLogo": null
  },
  "785_13": {
    "clientName": "Good Times Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/good-times-logo.png"
  },
  "254_1": {
    "clientName": "ESPsmile",
    "clientLogo": null
  },
  "716_1": {
    "clientName": "Value Max",
    "clientLogo": null
  },
  "834_0": {
    "clientName": "Karen Millen",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/karenmillen.png"
  },
  "844_2": {
    "clientName": "Anthropologie",
    "clientLogo": null
  },
  "631_119": {
    "clientName": "Leosun",
    "clientLogo": "https://images.prismic.io/ev-mercury/062a04fb-57ea-4b82-90e9-2703fe45886a_leosun.png?auto=compress,format"
  },
  "310_16": {
    "clientName": "Hair Products Online",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hairproductsonline-logo.png"
  },
  "326_0": {
    "clientName": "Rideaway",
    "clientLogo": null
  },
  "851_0": {
    "clientName": "Deichmann",
    "clientLogo": "https://images.prismic.io/ev-mercury/5f7e1325-3d9f-415e-bbc3-265ed39fbb51_1_DEI_BM_RGB+resized+.jpg?auto=compress,format"
  },
  "914_17": {
    "clientName": "Saville Row Shirts",
    "clientLogo": null
  },
  "776_1": {
    "clientName": "Quay Australia",
    "clientLogo": null
  },
  "975_5": {
    "clientName": "TML Collection",
    "clientLogo": null
  },
  "131_0": {
    "clientName": "Figleaves",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/figleaves.png"
  },
  "160_29": {
    "clientName": "Treads",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/treads.png"
  },
  "620_13": {
    "clientName": "Lyco",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lyco.png"
  },
  "39_23": {
    "clientName": "S'well",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/s-well-logo.png"
  },
  "253_6": {
    "clientName": "Bluebella",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bluebella.png"
  },
  "975_93": {
    "clientName": "Cariuma",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "345_158": {
    "clientName": "The Malt Miller",
    "clientLogo": null
  },
  "402_0": {
    "clientName": "Pitney Bowes Ltd",
    "clientLogo": null
  },
  "329_0": {
    "clientName": "Manor Park Trading Co Ltd",
    "clientLogo": null
  },
  "999_5": {
    "clientName": "L'Oreal",
    "clientLogo": null
  },
  "894_9": {
    "clientName": "Skin Store",
    "clientLogo": null
  },
  "652_24": {
    "clientName": "3P Enterprise",
    "clientLogo": null
  },
  "4908_0": {
    "clientName": "Do it at Home",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "628_10": {
    "clientName": "JULIPA",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "9999999_0": {
    "clientName": "testclient",
    "clientLogo": null
  },
  "921_7": {
    "clientName": "JD Sports - Ark",
    "clientLogo": null
  },
  "188_2": {
    "clientName": "Savage X",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/savage-x.png"
  },
  "2543_1": {
    "clientName": "Gym & Coffee",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25430001app.png"
  },
  "3636_6": {
    "clientName": "RIPT Clothing",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2598_0": {
    "clientName": "MADE London",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/made_144x144.jpg"
  },
  "2370_0": {
    "clientName": "Wilkos",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23700000app.png"
  },
  "303_0": {
    "clientName": "GFS 8",
    "clientLogo": null
  },
  "4449_0": {
    "clientName": "EASY CARE SOLUTIONS UK LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/b10924ec-a0e6-4439-8230-dd156a75ae72_DF+Circle+solutions.png?auto=compress,format"
  },
  "631_27": {
    "clientName": "TacTree",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310027app.png"
  },
  "911_0": {
    "clientName": "Sosandar",
    "clientLogo": null
  },
  "39_33": {
    "clientName": "Nobodys Child",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nobodysc-logo-144x144.png"
  },
  "652_39": {
    "clientName": "ProGlobal",
    "clientLogo": null
  },
  "5570_1": {
    "clientName": "Sashtime",
    "clientLogo": "https://images.prismic.io/ev-mercury/fb3ecb12-a6b1-4dab-be31-ce635f51df15_SASHTIME.png?auto=compress,format"
  },
  "287_130": {
    "clientName": "Reia",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2870130app.png"
  },
  "2492_0": {
    "clientName": "LOVALL",
    "clientLogo": "https://images.prismic.io/ev-mercury/99cce166-d0b7-4c64-b3da-52489cd6548a_lova.jpg?auto=compress,format"
  },
  "5444_0": {
    "clientName": "Exporto – TwoThirds",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2215_5": {
    "clientName": "Angel",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/angel.png"
  },
  "162_0": {
    "clientName": "Calvetron",
    "clientLogo": null
  },
  "665_3": {
    "clientName": "Dorothy Perkins",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dorothy-perkins.png"
  },
  "40_6": {
    "clientName": "Amazon - Curated UK",
    "clientLogo": null
  },
  "672_0": {
    "clientName": "Oasis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oasis_logonew.png"
  },
  "631_103": {
    "clientName": "Wilsons Pet Food",
    "clientLogo": "https://images.prismic.io/ev-mercury/090e58c3-28de-45a4-9741-72164bbf7c0e_wilsons+dog+food.png?auto=compress,format"
  },
  "892_0": {
    "clientName": "GFS Parcel 2 Go",
    "clientLogo": null
  },
  "5550_0": {
    "clientName": "Salesupply Limited",
    "clientLogo": ""
  },
  "393_0": {
    "clientName": "Jollimans Essentials",
    "clientLogo": null
  },
  "2155_3": {
    "clientName": "Robert Dyas",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21550003app.png"
  },
  "345_92": {
    "clientName": "GFS DF",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3450092app.png"
  },
  "12345_45": {
    "clientName": "_a-test",
    "clientLogo": null
  },
  "772_1": {
    "clientName": "Estee Lauder",
    "clientLogo": null
  },
  "811_32": {
    "clientName": "Scamp & Dude",
    "clientLogo": "https://images.prismic.io/ev-mercury/730381d5-4af2-4899-be72-3a902091e0ea_scampdude.jpg?auto=compress,format"
  },
  "2570_0": {
    "clientName": " Air Up GmbH",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/main-logo_airup_uk-warehouse_144x144.jpg"
  },
  "109_10": {
    "clientName": "Just Spices",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2215_0": {
    "clientName": "Global Reach Logistics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2317_0": {
    "clientName": "Am World Uk Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/am-world-logo.png"
  },
  "633_0": {
    "clientName": "HIGH STREET TV (GROUP) LIMITED",
    "clientLogo": null
  },
  "449_0": {
    "clientName": "Festive Lights",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/festive-lights-144x144.jpg"
  },
  "3422_0": {
    "clientName": "Postlink 24HR",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "433_0": {
    "clientName": "Swizzels",
    "clientLogo": " https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "236_0": {
    "clientName": "Ryman Stationary",
    "clientLogo": null
  },
  "652_163": {
    "clientName": "Valutech/Wayfair Return Centre",
    "clientLogo": null
  },
  "492_1": {
    "clientName": "ReBOUND Returns",
    "clientLogo": null
  },
  "208_0": {
    "clientName": "Mondial Relay",
    "clientLogo": null
  },
  "813_0": {
    "clientName": "Gooseberry Shop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gooseberry.png"
  },
  "3034_0": {
    "clientName": "Your Dog's Club Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/4be53285-debb-4320-a73f-5ac7cd6dcda2_Dogs+Club+144x144+%28002%29.jpg?auto=compress,format"
  },
  "5433_9": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "888_0": {
    "clientName": "Topgrade Sportswear",
    "clientLogo": null
  },
  "914_0": {
    "clientName": "GFS",
    "clientLogo": null
  },
  "748_0": {
    "clientName": "Radial",
    "clientLogo": null
  },
  "4134_0": {
    "clientName": "Digital Spot ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "3636_8": {
    "clientName": "Start Up With Us",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "975_4": {
    "clientName": "Lululemon",
    "clientLogo": null
  },
  "886_10": {
    "clientName": "Branded Bedding",
    "clientLogo": null
  },
  "227_1": {
    "clientName": "Benbrook",
    "clientLogo": null
  },
  "2620_0": {
    "clientName": "Xbite",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "492_20": {
    "clientName": "Rebound UK",
    "clientLogo": null
  },
  "593_0": {
    "clientName": "Wiseloads",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wiseloads.png"
  },
  "162_1": {
    "clientName": "Just Last Season",
    "clientLogo": null
  },
  "368_1": {
    "clientName": "Whistles",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/whistles.png"
  },
  "2155_1": {
    "clientName": "Click Health & Beauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21550001app.png"
  },
  "674_12": {
    "clientName": "Long Tall Sally",
    "clientLogo": null
  },
  "3825_1": {
    "clientName": "The Poster Store",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "952_2": {
    "clientName": "Ace & Tate",
    "clientLogo": null
  },
  "814_0": {
    "clientName": "Jameson Carter",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jameson-carter.png"
  },
  "288_0": {
    "clientName": "Limitless Digital Group",
    "clientLogo": null
  },
  "462_0": {
    "clientName": "Halfords",
    "clientLogo": "https://images.prismic.io/ev-mercury/52aa15f6-c5ed-4384-b592-877f1fdb948d_halfords.png?auto=compress,format"
  },
  "408_2": {
    "clientName": "Berghaus",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/berghaus2.png"
  },
  "121_0": {
    "clientName": "Jolliman Trading Limited",
    "clientLogo": null
  },
  "253_28": {
    "clientName": "WYSE London",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wyse-london.png"
  },
  "2577_0": {
    "clientName": "Horze",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "196_0": {
    "clientName": "Choice Shops Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "667_14": {
    "clientName": "Bradford 2",
    "clientLogo": null
  },
  "2654_0": {
    "clientName": "Allbeauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/144x144-ab-logo_.jpg"
  },
  "914_8": {
    "clientName": "Seur",
    "clientLogo": null
  },
  "748_2": {
    "clientName": "Limal",
    "clientLogo": null
  },
  "311_3": {
    "clientName": "NXT returns",
    "clientLogo": null
  },
  "983_0": {
    "clientName": "Hellmann Logistics",
    "clientLogo": null
  },
  "631_93": {
    "clientName": "Brookside Plant Nursery",
    "clientLogo": "https://images.prismic.io/ev-mercury/68f7caa3-3d46-4aaa-b447-78a0a5a326d5_Brookside+Logo+%28002%29.png?auto=compress,format"
  },
  "408_4": {
    "clientName": "Speedo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/speedo2.png"
  },
  "287_129": {
    "clientName": "Love Lumi",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2870129app.png"
  },
  "150_5": {
    "clientName": "Medic Animal",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1500005app.png"
  },
  "1073_1": {
    "clientName": "Starlight Beds",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/starlight-beds-logo.png"
  },
  "5480_0": {
    "clientName": "I-Shop Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/c3194199-898b-4500-a72b-3ddbe08805c2_I-shop+circle.png?auto=compress,format"
  },
  "4239_0": {
    "clientName": "Hotmilk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4198_0": {
    "clientName": "Songmics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/songmics-002-.jpg"
  },
  "492_3": {
    "clientName": "Wynsors",
    "clientLogo": null
  },
  "652_9": {
    "clientName": "Jeray Sales Ltd",
    "clientLogo": null
  },
  "414_0": {
    "clientName": "Ted Baker",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tedbaker.png"
  },
  "2320_0": {
    "clientName": "Tu Pack Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tu-pack-logo.png"
  },
  "2784_0": {
    "clientName": "Cybex",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5386_2": {
    "clientName": "PetWell",
    "clientLogo": "https://images.prismic.io/ev-mercury/3371e6ec-817e-44c7-81c1-428f566a671a_petwell.png?auto=compress,format"
  },
  "652_55": {
    "clientName": "Lebus Upholstery",
    "clientLogo": null
  },
  "723_0": {
    "clientName": "U Group Ltd",
    "clientLogo": null
  },
  "493_0": {
    "clientName": "Limar Trading Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/limar-trading.png"
  },
  "160_20": {
    "clientName": "Times Readers Offers",
    "clientLogo": null
  },
  "2485_7": {
    "clientName": "Rideaway",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/rideaway-logo.png"
  },
  "652_74": {
    "clientName": "Bonnington",
    "clientLogo": null
  },
  "759_0": {
    "clientName": "Hub Europe",
    "clientLogo": null
  },
  "2770_28": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "419_0": {
    "clientName": "Lavish Luxe Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lavish-luxe.png"
  },
  "408_0": {
    "clientName": "Pentland Brands",
    "clientLogo": null
  },
  "333_0": {
    "clientName": "Verage",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/verage-logo-2017-04-20.jpg"
  },
  "1651_0": {
    "clientName": "Amazon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon.png"
  },
  "545_0": {
    "clientName": "PetShop.co.uk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/petsshop_144x144.jpg"
  },
  "3783_0": {
    "clientName": "Sock Snob",
    "clientLogo": "https://images.prismic.io/ev-mercury/457219dd-a1e9-4f48-bf81-76ade06cb15f_DF+Circle+sock+snob.png?auto=compress,format"
  },
  "142_0": {
    "clientName": "Flostream",
    "clientLogo": null
  },
  "3635_0": {
    "clientName": "Lamoda",
    "clientLogo": "https://images.prismic.io/ev-mercury/68e8c3f5-8470-40d6-b5e0-87bed86fb085_lamoda.png?auto=compress,format"
  },
  "631_91": {
    "clientName": "Access",
    "clientLogo": "https://images.prismic.io/ev-mercury/9c19a9fd-ecdc-4a8a-87e5-c4da47c8a676_Access+%28002.png?auto=compress,format"
  },
  "149_4": {
    "clientName": "Proactive",
    "clientLogo": null
  },
  "2385_0": {
    "clientName": "Shopiago",
    "clientLogo": null
  },
  "2376_0": {
    "clientName": "Lucro Solutions Limited",
    "clientLogo": null
  },
  "498_0": {
    "clientName": "Morphy Richards",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5175_0": {
    "clientName": "Live Unlimited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2103_0": {
    "clientName": "Must Have Ideas Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mhi_uk_logo_with_strapline_144px.png"
  },
  "148_1": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "792_1": {
    "clientName": "Anthropologie",
    "clientLogo": "https://images.prismic.io/ev-mercury/ac0536a0-74f8-45c6-bd0a-26907bcdfeca_AnthropologieLogo_144px.png?auto=compress,format"
  },
  "595_5": {
    "clientName": "ADDICT",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/addict-logo.jpg"
  },
  "829_8": {
    "clientName": "Mark Hill",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mark-hill-2-5-.jpg"
  },
  "841_0": {
    "clientName": "FGH NICHE BRANDS UK",
    "clientLogo": null
  },
  "841_6": {
    "clientName": "Swimwear365",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/swimwear365.png"
  },
  "253_23": {
    "clientName": "Seraphine",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/seraphine.png"
  },
  "5665_0": {
    "clientName": "Abbott Lyon",
    "clientLogo": "https://images.prismic.io/ev-mercury/1ac440b0-ef3d-40d3-9072-3f69acef079d_Abbott+lyon+logo.png?auto=compress,format"
  },
  "975_15": {
    "clientName": "Alexa Chung",
    "clientLogo": null
  },
  "886_2": {
    "clientName": "Brand Alley",
    "clientLogo": null
  },
  "160_8": {
    "clientName": "Mail Shop",
    "clientLogo": null
  },
  "2306_3": {
    "clientName": "Giftzuu",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/giftzuu_144x144.jpg"
  },
  "650_0": {
    "clientName": "Footcandy T/A Simmi London",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/footcandy-logo.png"
  },
  "4925_0": {
    "clientName": "Bulk",
    "clientLogo": "https://images.prismic.io/ev-mercury/85f59b2a-f1e1-47d7-ba91-f3c0a9ee695f_bulk-logo-144-144-black+%28002%29.png?auto=compress,format"
  },
  "4529_0": {
    "clientName": "RK Brands Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "631_105": {
    "clientName": "Robot Mascot",
    "clientLogo": "https://images.prismic.io/ev-mercury/9a221406-4ebd-4d6a-b413-fba51acbbb51_robot+mascot.png?auto=compress,format"
  },
  "2155_4": {
    "clientName": "Wella",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21550004app.png"
  },
  "975_20": {
    "clientName": "Stipshop",
    "clientLogo": null
  },
  "929_0": {
    "clientName": "Wowcher",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/wowcher-logo.png"
  },
  "1942_14": {
    "clientName": "The Ayurveda Experience",
    "clientLogo": "https://images.prismic.io/ev-mercury/caf2815d-5e64-43b3-b7f4-8a804bc24ed4_MicrosoftTeams-image+%2834%29+%281%29.png?auto=compress,format"
  },
  "2355_0": {
    "clientName": "Debenhams",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23550000.app.png"
  },
  "4659_0": {
    "clientName": "Sephora UK",
    "clientLogo": null
  },
  "488_1": {
    "clientName": "Cascade",
    "clientLogo": null
  },
  "2346_0": {
    "clientName": "SCHUH",
    "clientLogo": "https://images.prismic.io/ev-mercury/ceef8e39-2a3e-4744-b94b-dddf7b18c67b_2346.png?auto=compress,format"
  },
  "975_99": {
    "clientName": "Seraphine",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "831_120": {
    "clientName": "LeakBot",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "82_2": {
    "clientName": "RKW Groupon",
    "clientLogo": null
  },
  "551_39": {
    "clientName": "Warwickshire Clothing",
    "clientLogo": null
  },
  "652_8": {
    "clientName": "Baumhaus",
    "clientLogo": null
  },
  "151_52": {
    "clientName": "House of Fraser",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1510052app.png"
  },
  "329_2": {
    "clientName": "Bedding Market",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/home-bedding-store.png"
  },
  "652_131 ": {
    "clientName": "Glitz Home",
    "clientLogo": null
  },
  "64_0": {
    "clientName": "4PX",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "3398_0": {
    "clientName": "My Rocking Kids",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3398000.app.png"
  },
  "5067_8": {
    "clientName": "Lost Mary",
    "clientLogo": "https://images.prismic.io/ev-mercury/d7d384cd-42d1-42cf-a9ac-1a22be763c3d_lost+mary.jpg?auto=compress,format"
  },
  "133_8": {
    "clientName": "KD and Jay 100",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "484_1": {
    "clientName": "Bargainmax - Delta",
    "clientLogo": null
  },
  "653_15": {
    "clientName": "Kia Parts",
    "clientLogo": null
  },
  "4264_0": {
    "clientName": "P-J Local1",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "160_11": {
    "clientName": "MNA Media",
    "clientLogo": null
  },
  "595_2": {
    "clientName": "SUPERGA",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/superga-logo.jpg"
  },
  "2205_1": {
    "clientName": "Mahabis Recycling",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mahabis.png"
  },
  "953_1": {
    "clientName": "Pillow Talk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pillowtak_144x144.jpg"
  },
  "825_8": {
    "clientName": "Witt",
    "clientLogo": null
  },
  "5642_0": {
    "clientName": "ARC X-Media LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "253_30": {
    "clientName": "LF Markey",
    "clientLogo": null
  },
  "253_101": {
    "clientName": "Kitri",
    "clientLogo": "https://images.prismic.io/ev-mercury/15aa8116-48a6-4b02-98d5-edde1e35da5e_Kitri+Logo.png?auto=compress,format"
  },
  "427_0": {
    "clientName": "Net Price Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/netprice-direct-logo.png"
  },
  "2051_0": {
    "clientName": "Cath Kidston",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ck-london-logo.jpg"
  },
  "39_0": {
    "clientName": "Seko UK",
    "clientLogo": null
  },
  "347_0": {
    "clientName": "Jack Wills Limited",
    "clientLogo": null
  },
  "2658_0": {
    "clientName": "Motocross4U Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/motocross4u-logo.png"
  },
  "914_32": {
    "clientName": "BSMW",
    "clientLogo": null
  },
  "3898_0": {
    "clientName": "Courier Branded Uniform",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "205_0": {
    "clientName": "Missy Empire",
    "clientLogo": null
  },
  "652_135": {
    "clientName": "BennettAndBates",
    "clientLogo": null
  },
  "2403_0": {
    "clientName": "Western International Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wig-logo-png-144px-x-144px.png"
  },
  "2300_0": {
    "clientName": "DHL SCS Ecommerce",
    "clientLogo": null
  },
  "824_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "3769_0": {
    "clientName": "This Is It",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tii-logo-154x91-002-.png"
  },
  "667_41": {
    "clientName": "Plymouth 1",
    "clientLogo": null
  },
  "5433_8": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2485_5": {
    "clientName": "Dirtbikebitz",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dirtbikebitz-logo.png"
  },
  "969_0": {
    "clientName": "Stitch Fix",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/stitchfix.png"
  },
  "78_3": {
    "clientName": "Sizzle",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sizzle.png"
  },
  "652_124": {
    "clientName": "Paini UK Ltd",
    "clientLogo": null
  },
  "253_0": {
    "clientName": "Torque Logistics",
    "clientLogo": null
  },
  "894_12": {
    "clientName": "THG",
    "clientLogo": null
  },
  "984_38": {
    "clientName": "Parrot Essentials",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/9840038app.png"
  },
  "652_92": {
    "clientName": "Cro-Ki",
    "clientLogo": null
  },
  "1953_0": {
    "clientName": "Jacques Vert",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jv-logo.png"
  },
  "840_3": {
    "clientName": "Kaleidoscope",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kaleidoscopelogonewmarch21.png"
  },
  "2245_1": {
    "clientName": "UK Vapour Brands Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ukvb-black.png"
  },
  "921_18": {
    "clientName": "JD Sports - Eurohike",
    "clientLogo": null
  },
  "778_0": {
    "clientName": "Hidden Fashion",
    "clientLogo": null
  },
  "1056_3": {
    "clientName": "Landmark AP",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "975_97": {
    "clientName": "UK Tribe/Stussy",
    "clientLogo": "https://images.prismic.io/ev-mercury/4bd2f236-63e9-4167-9b06-c0d4bd8deda4_Stussy+Logo+resized.JPEG?auto=compress,format"
  },
  "492_11": {
    "clientName": "Euroasia",
    "clientLogo": null
  },
  "2579_005": {
    "clientName": "Master of Malt",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/01-ev0021-logo-resizing-master-of-malt-144x144px.png"
  },
  "3882_0": {
    "clientName": "Blade & Rose",
    "clientLogo": null
  },
  "2091_0": {
    "clientName": "Universal Delivery Solutions Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/asset-folder/uds-logo.png"
  },
  "652_65": {
    "clientName": "Rowlett Rutland",
    "clientLogo": null
  },
  "3767_0": {
    "clientName": "Clair De Lune",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "551_10": {
    "clientName": "Flooring Direct",
    "clientLogo": null
  },
  "3859_0": {
    "clientName": "Photo Frames & Art",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/002-ev0021-logo-resizing-for-print-in-store-devices_-web-and-app-photoframesart-144x144.jpg"
  },
  "1004_1": {
    "clientName": "CCL01",
    "clientLogo": null
  },
  "674_1": {
    "clientName": "GH Bass",
    "clientLogo": null
  },
  "652_54": {
    "clientName": "GL Bowron Ltd",
    "clientLogo": null
  },
  "652_37": {
    "clientName": "MacMaster Design",
    "clientLogo": null
  },
  "682_0": {
    "clientName": "Weekday",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/weekday.png"
  },
  "248_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "2526_7": {
    "clientName": "Blue Earth Clean",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25260007app.png"
  },
  "652_49": {
    "clientName": "The Organic Company",
    "clientLogo": null
  },
  "886_12": {
    "clientName": "Sleepy People",
    "clientLogo": null
  },
  "548_0": {
    "clientName": "Harrys Grooming ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/5480000app.png"
  },
  "151_53": {
    "clientName": "Jack Wills",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1510053app.png"
  },
  "1065_0": {
    "clientName": "Amazon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon.png"
  },
  "992_3": {
    "clientName": "hermes Borderguru GmbH",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hbg-logo.png"
  },
  "615_3": {
    "clientName": "Mini-Sun",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mini-sun.png"
  },
  "914_15": {
    "clientName": "Precious Little One Limited",
    "clientLogo": null
  },
  "652_82": {
    "clientName": "NineSchoolsLtd",
    "clientLogo": null
  },
  "652_95": {
    "clientName": "EssentialOutdoorSuppliesLtd",
    "clientLogo": null
  },
  "3402_0": {
    "clientName": "SNS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sns-logo200x200.jpeg"
  },
  "1448_1": {
    "clientName": "L&L Returns",
    "clientLogo": null
  },
  "764_0": {
    "clientName": "COS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/7640000app.png"
  },
  "412_0": {
    "clientName": "Inditex Retail",
    "clientLogo": null
  },
  "5092_0": {
    "clientName": "Amazon LBA2 TTS",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "79_0": {
    "clientName": "Parcel Monkey",
    "clientLogo": null
  },
  "894_13": {
    "clientName": "THG POD",
    "clientLogo": null
  },
  "382_1": {
    "clientName": "Beldray",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beldray-logo.png"
  },
  "253_10": {
    "clientName": "Playful Promises",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/playful-promises.png"
  },
  "5067_0": {
    "clientName": "Flavour Warehouse",
    "clientLogo": "https://images.prismic.io/ev-mercury/51bcd0ec-81cb-44c0-968b-de4a493ead44_flavourw+logo.png?auto=compress,format"
  },
  "4116_0": {
    "clientName": "House of Malt",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "42_0": {
    "clientName": "Hobbycraft",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hobbycraft.png"
  },
  "783_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "1942_2": {
    "clientName": "CovidTestingDirect.com",
    "clientLogo": null
  },
  "4315_0": {
    "clientName": "Pour Moi",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pour-moi-download-resize-1-.png"
  },
  "666_0": {
    "clientName": "Femme Luxe ",
    "clientLogo": "https://images.prismic.io/ev-mercury/de18cacf-e3f6-4266-a877-be1a00e8dca4_FEMME.png?auto=compress,format"
  },
  "697_1": {
    "clientName": "Aqualona Products Ltd",
    "clientLogo": null
  },
  "160_2": {
    "clientName": "Clifford James ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/clifford-james.png"
  },
  "2572_1": {
    "clientName": "Home Bedding Store",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2770_23": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "551_40": {
    "clientName": "Gaynor Sports",
    "clientLogo": null
  },
  "551_47": {
    "clientName": "Little Vic Trading Limited",
    "clientLogo": null
  },
  "831_3": {
    "clientName": "Luggage Travel Bags",
    "clientLogo": null
  },
  "4475_0": {
    "clientName": "Fulfilment Centre",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "667_37": {
    "clientName": "Leeds 1",
    "clientLogo": null
  },
  "514_0": {
    "clientName": "A & S Lighting Ltd",
    "clientLogo": null
  },
  "901_0": {
    "clientName": "Coast",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/coast.png"
  },
  "4465_0": {
    "clientName": "JINGDONG LOGISTICS B.V.",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4724_0": {
    "clientName": "SOSANDAR",
    "clientLogo": "https://images.prismic.io/ev-mercury/9444498f-17a8-4ad1-be02-60bba6c060a8_Sosandar_Logo_144x144px.png?auto=compress,format"
  },
  "252_3": {
    "clientName": "Tikiting (1)",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2678_22": {
    "clientName": "ITD Messina Hembry",
    "clientLogo": "https://images.prismic.io/ev-mercury/5154542f-bae8-4905-beab-fbda7db11127_Messina+Hembry+logo+%28002%29.png?auto=compress,format"
  },
  "287_3": {
    "clientName": "Love Raid Ltd",
    "clientLogo": null
  },
  "921_135": {
    "clientName": "Guilio",
    "clientLogo": null
  },
  "894_51": {
    "clientName": "Myvitamins",
    "clientLogo": "https://images.prismic.io/ev-mercury/c3aa63a4-2e39-4517-a0b3-4a6840e23fab_fb-image+%28002%29.png?auto=compress,format"
  },
  "614_3": {
    "clientName": "Boohoo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/boohoo-man.png"
  },
  "345_149": {
    "clientName": "Jackpotjoy",
    "clientLogo": null
  },
  "454_0": {
    "clientName": "Chain Reaction Cycles",
    "clientLogo": null
  },
  "109_5": {
    "clientName": "Usana ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "886_13": {
    "clientName": "La-Redoute",
    "clientLogo": ""
  },
  "605_5": {
    "clientName": "Worldwide Roar",
    "clientLogo": "https://images.prismic.io/ev-mercury/f4b2167e-b230-485d-9917-79f8cf9b1192_Worldwide+Roar+Logo.jfif?auto=compress,format"
  },
  "5474_0": {
    "clientName": "Spreetail",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "238_0": {
    "clientName": "Secured Express",
    "clientLogo": null
  },
  "122_0": {
    "clientName": "Smiggle",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/smiggle.png"
  },
  "817_4": {
    "clientName": "Allport Cargo Services",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8170004app.png"
  },
  "960_0": {
    "clientName": "SHF2",
    "clientLogo": null
  },
  "2748_0": {
    "clientName": "Bresser GmbH",
    "clientLogo": null
  },
  "2808_0": {
    "clientName": "SellerEngine",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sellerengine-logo-002-144x144.jpg"
  },
  "825_1": {
    "clientName": "Grattan",
    "clientLogo": null
  },
  "543_0": {
    "clientName": "Photobox",
    "clientLogo": null
  },
  "647_0": {
    "clientName": "Selective Marketplace Ltd",
    "clientLogo": null
  },
  "310_25": {
    "clientName": "Night Store",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/logo_144x144-01.png"
  },
  "345_1": {
    "clientName": "Wilko",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wilko.png"
  },
  "914_11": {
    "clientName": "Duncan Fearnley Cricket Sales",
    "clientLogo": null
  },
  "652_134": {
    "clientName": "LFSourcingHomeTextiles",
    "clientLogo": null
  },
  "2699_0": {
    "clientName": "Slick Stitch",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_139": {
    "clientName": "Woodlands",
    "clientLogo": null
  },
  "652_106": {
    "clientName": "BennettAndBates",
    "clientLogo": null
  },
  "252_0": {
    "clientName": "B2C Europe",
    "clientLogo": null
  },
  "921_10": {
    "clientName": "JD Sports - ActivInstinct",
    "clientLogo": null
  },
  "2770_24": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "253_31": {
    "clientName": "Azurina",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/azurina.png"
  },
  "2679_0": {
    "clientName": "Our Warehouse",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "333_3": {
    "clientName": "Apex Euro Ltd",
    "clientLogo": null
  },
  "2678_26": {
    "clientName": "Norwich City FC",
    "clientLogo": "https://images.prismic.io/ev-mercury/ac53d8c4-0c59-4bef-86ae-e1e4ad144dcb_Norwich+city+FC+%28002%29.png?auto=compress,format"
  },
  "2749_6": {
    "clientName": "Bull & Bully",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "492_33": {
    "clientName": "Lands End",
    "clientLogo": null
  },
  "5601_0": {
    "clientName": "Online Reptile Shop Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/25722df1-ccfa-4503-b89d-84dd83017364_reptile.png?auto=compress,format"
  },
  "351_0": {
    "clientName": "Prezzybox",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3510000app.png"
  },
  "285_0": {
    "clientName": "Lancashire Textiles ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lancashire-textiles-logo.png"
  },
  "2749_14": {
    "clientName": "1concepts",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5145_0": {
    "clientName": "Matalan",
    "clientLogo": "https://images.prismic.io/ev-mercury/00a10a87-3d5a-4114-a1db-0a0fd9115789_DF+Circle+%28002%29+3.png?auto=compress,format"
  },
  "1946_0": {
    "clientName": "Wayfair 3",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wayfair.png"
  },
  "4726_0": {
    "clientName": "CSM Logistics Northampton",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "742_1": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos1.png"
  },
  "831_117": {
    "clientName": "Quotemehappy Connect",
    "clientLogo": "https://images.prismic.io/ev-mercury/82031748-d44e-452e-8f8f-4787a1ade9c0_EVRI+QMH+logo.jpg?auto=compress,format"
  },
  "631_28": {
    "clientName": "MedTree",
    "clientLogo": "https://images.prismic.io/ev-mercury/25109c4f-05ef-45ac-8d4f-8b8adce53a9c_TacTree_2022_Evri+144x144.png?auto=compress,format"
  },
  "272_1": {
    "clientName": "Ilmakiage",
    "clientLogo": "https://images.prismic.io/ev-mercury/fa183f75-110f-47b8-8841-a853d70797df_ilmakiage.png?auto=compress,format"
  },
  "108_1": {
    "clientName": "Easylife Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/easylife-logo.png"
  },
  "894_43": {
    "clientName": "ManKind",
    "clientLogo": "https://images.prismic.io/ev-mercury/b5e48f4b-a1a3-46d5-ac9b-dfc19f52a489_ManKind+%28002%29.png?auto=compress,format"
  },
  "772_38": {
    "clientName": "By Kilian",
    "clientLogo": null
  },
  "551_4": {
    "clientName": "Intermail",
    "clientLogo": null
  },
  "862_1": {
    "clientName": "JBD",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "663_0": {
    "clientName": "Lenstore.co.uk",
    "clientLogo": "https://images.prismic.io/ev-mercury/3b59c6f4-ac50-4298-bf56-b235cb5fd8ec_Lenstore_Logo+%28003%29+144x144.jpg?auto=compress,format"
  },
  "5652_0": {
    "clientName": "PIVOTAL Newcastle",
    "clientLogo": ""
  },
  "551_11": {
    "clientName": "Rollersnkes Limited",
    "clientLogo": null
  },
  "652_68": {
    "clientName": "GFDirectBradley",
    "clientLogo": null
  },
  "652_3": {
    "clientName": "Impex Lighting",
    "clientLogo": null
  },
  "160_16": {
    "clientName": "Supplement Centre",
    "clientLogo": null
  },
  "894_4": {
    "clientName": "IWOOT",
    "clientLogo": null
  },
  "631_100": {
    "clientName": "Claude & Co",
    "clientLogo": "https://images.prismic.io/ev-mercury/7991ec27-f274-457f-8283-04d1d08135a8_ClaudeCo+Logo+%28002%29.png?auto=compress,format"
  },
  "2770_22": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "652_91": {
    "clientName": "Mahitti Ltd",
    "clientLogo": null
  },
  "330_0": {
    "clientName": "ZAZ Clothing Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/zaz-clothing-logo.png"
  },
  "0_24": {
    "clientName": "ITD 3 Retro",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/500024logo.png"
  },
  "1004_8": {
    "clientName": "BOXC -insured",
    "clientLogo": null
  },
  "551_9": {
    "clientName": "Landmark Global (Belgium)",
    "clientLogo": null
  },
  "492_9": {
    "clientName": "UK Business Supplies",
    "clientLogo": null
  },
  "473_0": {
    "clientName": "Prolog Fulfilment",
    "clientLogo": null
  },
  "92_1": {
    "clientName": "Wine52",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wine52-logo.png"
  },
  "667_23": {
    "clientName": "Croydon 3",
    "clientLogo": null
  },
  "500_0": {
    "clientName": "FatFace",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fatface.png"
  },
  "921_4": {
    "clientName": "Blacks",
    "clientLogo": "https://images.prismic.io/ev-mercury/1c090d4f-cf9b-4892-8649-d97fb1580407_blacks+logo.png?auto=compress,format"
  },
  "3068_0": {
    "clientName": "Perfume price",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/perfume_price_logo.png"
  },
  "795_0": {
    "clientName": "Moda In Pelle",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/small_moda.png"
  },
  "1950_0": {
    "clientName": "NHS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/emails/logos/19500000.png"
  },
  "5589_0": {
    "clientName": "B.A.M Worldwide LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "707_0": {
    "clientName": "Monki",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/monki-logo.png"
  },
  "151_60": {
    "clientName": "ISAWITFIRST",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "395_2": {
    "clientName": "CWV",
    "clientLogo": null
  },
  "133_0": {
    "clientName": "KD & JAY",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "886_0": {
    "clientName": "Comfy Quilts",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/comfy-quilts.png"
  },
  "674_2": {
    "clientName": "Soletrader",
    "clientLogo": null
  },
  "785_17": {
    "clientName": "DRG Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "975_18": {
    "clientName": "Denham",
    "clientLogo": null
  },
  "4028_17": {
    "clientName": "VELUX",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280017app.png"
  },
  "674_13": {
    "clientName": "Comfy Quilts",
    "clientLogo": null
  },
  "667_28": {
    "clientName": "East London 4",
    "clientLogo": null
  },
  "615_101": {
    "clientName": "Value Lights",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6150101app.png"
  },
  "971_100": {
    "clientName": "LoveCrochet",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lovecrafts.png"
  },
  "392_0": {
    "clientName": "Price Crunchers",
    "clientLogo": null
  },
  "1173_0": {
    "clientName": "Amazon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon.png"
  },
  "2485_2": {
    "clientName": "Country Attire",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/country-attire-logo.png"
  },
  "3636_0": {
    "clientName": "Zulu Brands",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "794_0": {
    "clientName": "Misspap",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/misspap-logonew.png"
  },
  "667_33": {
    "clientName": "Huddersfield 1",
    "clientLogo": null
  },
  "3652_0": {
    "clientName": "Top Cloud",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "215_0": {
    "clientName": "Charles Saunders",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/charles-saunders-logonew.png"
  },
  "595_0": {
    "clientName": "GL DAMECK LTD ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2394_0": {
    "clientName": "We Are Shrine ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/shrine-logo.png"
  },
  "4944_4": {
    "clientName": "We are Tala",
    "clientLogo": "https://images.prismic.io/ev-mercury/d6053475-3ed2-429e-9ea5-f141c18eadd2_tala+logo.png?auto=compress,format"
  },
  "921_11": {
    "clientName": "Ultimate Outdoors",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ultimate-outdoors-logonew.png"
  },
  "2727_0": {
    "clientName": "Essex GS Solutions",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/essexgeneral_144x144-1-.png"
  },
  "4028_8": {
    "clientName": "BRICKCOM",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280008app.png"
  },
  "50_0": {
    "clientName": "Interdelta Ltd",
    "clientLogo": null
  },
  "133_2": {
    "clientName": "Online Retailers",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "772_10": {
    "clientName": "Creme De La Mer",
    "clientLogo": null
  },
  "5433_5": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_96": {
    "clientName": "InnovatorsInternationalLtd",
    "clientLogo": null
  },
  "160_28": {
    "clientName": "Garden Gear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/garden-gear-logo.png"
  },
  "652_167": {
    "clientName": "Belledorm",
    "clientLogo": null
  },
  "800_4": {
    "clientName": "SG Stores",
    "clientLogo": null
  },
  "785_5": {
    "clientName": "Jean Patrique",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jp-logo.png"
  },
  "841_8": {
    "clientName": "Witt",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/witt.png"
  },
  "631_99": {
    "clientName": "Ando Stores",
    "clientLogo": "https://images.prismic.io/ev-mercury/ee0beab3-82ad-4592-bfe3-0af196abc0b8_Ando+%28002%29.jpg?auto=compress,format"
  },
  "595_10": {
    "clientName": "DEBGBGLD ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "297_2": {
    "clientName": "Beauty Flash",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beauty-flash-logonew.jpg"
  },
  "2749_0": {
    "clientName": "Exporto",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "975_86": {
    "clientName": "Boardriders",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "826_7": {
    "clientName": "Clearance 365",
    "clientLogo": null
  },
  "2496_0": {
    "clientName": "DUSK",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24960000app.png"
  },
  "975_16": {
    "clientName": "Karhu",
    "clientLogo": null
  },
  "595_4": {
    "clientName": "KWAY",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kway-logo.jpg"
  },
  "802_795": {
    "clientName": "Debenhams Direct - Debenhams Health & Beauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "2573_0": {
    "clientName": "Aquatix 2u",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/aquatix2u_144x144.jpg"
  },
  "312_6": {
    "clientName": "Monterrain",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/monterrain-logonew.png"
  },
  "270_0": {
    "clientName": "Pin Mill",
    "clientLogo": null
  },
  "20_0": {
    "clientName": "Feelunique",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/feel-unique.png"
  },
  "716_3": {
    "clientName": "TJ Textiles Ltd",
    "clientLogo": null
  },
  "2794_0": {
    "clientName": "INTA AUDIO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/inta-audio-logo-144px.png"
  },
  "955_1": {
    "clientName": "Cotton Traders Shop Returns",
    "clientLogo": null
  },
  "161_0": {
    "clientName": "QVC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1610000app.png"
  },
  "620_14": {
    "clientName": "Online Lighting",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/online-lighting.png"
  },
  "2139_0": {
    "clientName": "Superdrug",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/superdrug.png"
  },
  "914_3": {
    "clientName": "Post 'N' Packages Ltd",
    "clientLogo": null
  },
  "160_22": {
    "clientName": "Your Shop",
    "clientLogo": null
  },
  "341_0": {
    "clientName": "The White Company",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-white-company.png"
  },
  "2149_0": {
    "clientName": "Dynergy Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dynergy-logo.png"
  },
  "1964_1": {
    "clientName": "Vale Mill free returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "1013_0": {
    "clientName": "JPN Enterprises",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jpn-144x144px.png"
  },
  "992_2": {
    "clientName": "Seko Omni-Channel",
    "clientLogo": null
  },
  "551_59": {
    "clientName": "Purely Outdoors",
    "clientLogo": null
  },
  "5207_0": {
    "clientName": "Cycleon B.V.",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "804_4": {
    "clientName": "Warehouse",
    "clientLogo": null
  },
  "652_164": {
    "clientName": "Riva Paoletti",
    "clientLogo": null
  },
  "445_0": {
    "clientName": "Dolly Diamonds Ltd",
    "clientLogo": null
  },
  "975_90": {
    "clientName": "Ganni",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2781_0": {
    "clientName": "Shein UK Distribution - Insured",
    "clientLogo": null
  },
  "921_6": {
    "clientName": "JD Sports - Foot Patrol",
    "clientLogo": null
  },
  "1960_3": {
    "clientName": "Vanmoof",
    "clientLogo": null
  },
  "847_14": {
    "clientName": "Express Gifts- Accrington",
    "clientLogo": null
  },
  "5245_0": {
    "clientName": "Playful Promises",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "160_7": {
    "clientName": "James-Russell",
    "clientLogo": null
  },
  "463_0": {
    "clientName": "La Redoute",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/4630000.png"
  },
  "847_15": {
    "clientName": "Express Gifts- Clayton",
    "clientLogo": null
  },
  "2304_0": {
    "clientName": "4Feet Retail ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/4feetshoes-logo.jpg"
  },
  "886_5": {
    "clientName": "Argos",
    "clientLogo": null
  },
  "2770_19": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "5238_2": {
    "clientName": "Bare Minerals",
    "clientLogo": "https://images.prismic.io/ev-mercury/15992d85-dccf-4f10-a228-e1c3754a0c3e_DF+Circle+bare+minerals.png?auto=compress,format"
  },
  "667_3": {
    "clientName": "Birmingham 3",
    "clientLogo": null
  },
  "652_38": {
    "clientName": "Shine Capital",
    "clientLogo": null
  },
  "525_1": {
    "clientName": "Bombas",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/525001.app.png"
  },
  "831_67": {
    "clientName": "Trilanco",
    "clientLogo": null
  },
  "667_40": {
    "clientName": "Leeds 4",
    "clientLogo": null
  },
  "921_1": {
    "clientName": "JD Sports - Bank",
    "clientLogo": null
  },
  "5432_0": {
    "clientName": "Fable England",
    "clientLogo": "https://images.prismic.io/ev-mercury/9147ba19-7378-4206-ba2c-537ecc3afca8_fablenew.png?auto=compress,format"
  },
  "1813_1": {
    "clientName": "Morley Court",
    "clientLogo": null
  },
  "253_12": {
    "clientName": "Daniel Ricciardo",
    "clientLogo": null
  },
  "446_0": {
    "clientName": "Long Tall Sally",
    "clientLogo": null
  },
  "4675_0": {
    "clientName": "Golfbase",
    "clientLogo": "https://images.prismic.io/ev-mercury/04619587-d9ac-40de-9820-73f207806f76_MicrosoftTeams-image.png?auto=compress,format"
  },
  "550_0": {
    "clientName": "GFS 2 Hour",
    "clientLogo": null
  },
  "785_14": {
    "clientName": "Healthy for Life",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hfl-logo.png"
  },
  "5314_1": {
    "clientName": "Buzz Catering Free Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "253_8": {
    "clientName": "Joy",
    "clientLogo": null
  },
  "246_0": {
    "clientName": "Zalando",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/zalando.png"
  },
  "4944_5": {
    "clientName": "Larizia",
    "clientLogo": ""
  },
  "3383_0": {
    "clientName": "Sweaty Betty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "699_0": {
    "clientName": "Choice Stationery Supplies",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/choicestationarysupplies.png"
  },
  "1498_0": {
    "clientName": "The Good Club",
    "clientLogo": null
  },
  "1_0": {
    "clientName": "Mothercare",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mothercare.png"
  },
  "652_144": {
    "clientName": "Stobarts",
    "clientLogo": null
  },
  "991_0": {
    "clientName": "Promotional Handling",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/promotionalhandling.jpg"
  },
  "539_2": {
    "clientName": "Neena Swim",
    "clientLogo": null
  },
  "785_7": {
    "clientName": "Wellform",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wellform-logo.png"
  },
  "075_88": {
    "clientName": "Karhu",
    "clientLogo": null
  },
  "652_36": {
    "clientName": "JVL Homeware Solutions",
    "clientLogo": null
  },
  "5338_1": {
    "clientName": "Only Curls",
    "clientLogo": "https://images.prismic.io/ev-mercury/5ab8c0bb-7a0b-4dd7-91e7-b435aea9142d_only+curls.png?auto=compress,format"
  },
  "492_41": {
    "clientName": "Redfoot",
    "clientLogo": null
  },
  "4965_0": {
    "clientName": "Online Trendz",
    "clientLogo": "https://images.prismic.io/ev-mercury/ad6bea3b-04dc-4791-8231-bcbca5617bd8_zenqa.png?auto=compress,format"
  },
  "2702_0": {
    "clientName": "AUTODOC AG",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_736": {
    "clientName": "Cambertown Ltd",
    "clientLogo": null
  },
  "631_0": {
    "clientName": "Parcel Hub New Business",
    "clientLogo": null
  },
  "762_0": {
    "clientName": "Ideal World",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "188_1": {
    "clientName": "Just Fabulous",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/justfab.png"
  },
  "3845_0": {
    "clientName": "Brahh 'n' Shape",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "379_0": {
    "clientName": "Pink Boutique",
    "clientLogo": null
  },
  "538_1": {
    "clientName": "ReBOUND Returns",
    "clientLogo": null
  },
  "2647_0": {
    "clientName": "Just Fab (Techstyle Fashion)",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/0000001-justfab.png"
  },
  "368_4": {
    "clientName": "Hochando",
    "clientLogo": null
  },
  "825_4": {
    "clientName": "Look Again",
    "clientLogo": null
  },
  "1056_13": {
    "clientName": "Landmark Belgium A",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4295_0": {
    "clientName": "Bully Billows",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "551_44": {
    "clientName": "Fang & Associates Limited",
    "clientLogo": null
  },
  "595_6": {
    "clientName": "AMPLIFIED",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amplified-logo.jpg"
  },
  "886_6": {
    "clientName": "QVC",
    "clientLogo": null
  },
  "3375_0": {
    "clientName": "David Luke Ltd",
    "clientLogo": null
  },
  "4637_0": {
    "clientName": "AdventCalendarsOrchardcards",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "345_143": {
    "clientName": "CC Moore",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/c.c-moore.jpg"
  },
  "50_24": {
    "clientName": "3 Retro Ltd ",
    "clientLogo": "https://images.prismic.io/ev-mercury/0c5a6c89-5154-4b0d-ab43-2048df898aa3_ITD+3+Retro+logo+%28002%29.png?auto=compress,format"
  },
  "631_74": {
    "clientName": "DriveDen Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310074app.png"
  },
  "1056_11": {
    "clientName": "Landmark NL A",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "886_11": {
    "clientName": "Comfy Quilts",
    "clientLogo": null
  },
  "652_34": {
    "clientName": "Buschbeck ",
    "clientLogo": null
  },
  "5448_0": {
    "clientName": "HADSON",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "992_4": {
    "clientName": "Omni LHR",
    "clientLogo": null
  },
  "2329_2": {
    "clientName": "OrcaHygiene",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/orcahygiene-logo.png"
  },
  "615_2": {
    "clientName": "Iconic Lights",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/iconic-lights.png"
  },
  "238_3": {
    "clientName": "Latchams",
    "clientLogo": null
  },
  "460_42": {
    "clientName": "Asiatic Rugs",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "810_0": {
    "clientName": "Music Magpie",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/musicmagpie144x144.jpg"
  },
  "2749_29": {
    "clientName": "TB International",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "628_19": {
    "clientName": "Home Essentials",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/home-essentials.png"
  },
  "853_0": {
    "clientName": "Find me a gift",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/findmeagift.png"
  },
  "551_50": {
    "clientName": "Worldwide Confectionery Limited",
    "clientLogo": null
  },
  "2763_1": {
    "clientName": "Huntland",
    "clientLogo": null
  },
  "160_5": {
    "clientName": "Fishtec",
    "clientLogo": null
  },
  "507_0": {
    "clientName": "Uniqlo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/uniqlo.png"
  },
  "492_48": {
    "clientName": "Topman",
    "clientLogo": null
  },
  "3544_0": {
    "clientName": "Personalised Gift Studio LTD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/35440000app.png"
  },
  "785_11": {
    "clientName": "Historic Motor Museum",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hmmm-logo.png"
  },
  "540_1": {
    "clientName": "Harper Collins ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/harper-collins.png"
  },
  "975_17": {
    "clientName": "Groupon",
    "clientLogo": null
  },
  "169_0": {
    "clientName": "Baukjen & Isabella Oliver",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/baukjen-logo.png"
  },
  "2511_0": {
    "clientName": "SEKO Omni-Channel Logistics",
    "clientLogo": null
  },
  "628_1": {
    "clientName": "AMBROSE WILSON P.L.C",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ambrose-wilson.png"
  },
  "178_4": {
    "clientName": "Rk Star",
    "clientLogo": null
  },
  "662_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "811_29": {
    "clientName": "VELO",
    "clientLogo": "https://images.prismic.io/ev-mercury/55924e3d-823b-4aa9-b612-2b900d85875e_VELO+%28002%29.png?auto=compress,format"
  },
  "2155_2": {
    "clientName": "Feelunique",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21550002app.png"
  },
  "825_11": {
    "clientName": "Heine",
    "clientLogo": null
  },
  "2770_1": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "345_161": {
    "clientName": "Girlguiding",
    "clientLogo": "https://images.prismic.io/ev-mercury/a6bbaefb-bb1c-45ea-92a5-ec253ccb7158_Primary+Corporate+Logo_Top+Left_Print+_+Web+Use+%28002%29.jpg?auto=compress,format"
  },
  "551_58": {
    "clientName": "Oh Polly",
    "clientLogo": null
  },
  "4567_0": {
    "clientName": "Cards for Good Causes",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "921_126": {
    "clientName": "JD Sports",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "50_30": {
    "clientName": "Twenty47 Logistics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/500030logo.png"
  },
  "3950_0": {
    "clientName": "Camera World",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4636_0": {
    "clientName": "Awesome Shoes Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "934_0": {
    "clientName": "Clarks",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/clarks.png"
  },
  "36_1": {
    "clientName": "Value Lights",
    "clientLogo": null
  },
  "4028_13": {
    "clientName": "SWATCH",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280013app.png"
  },
  "469_0": {
    "clientName": "Bells Shoes",
    "clientLogo": null
  },
  "951_0": {
    "clientName": "ParcelDen",
    "clientLogo": null
  },
  "914_37": {
    "clientName": "Snug City",
    "clientLogo": null
  },
  "662_6": {
    "clientName": "Evri",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "1941_3": {
    "clientName": "Giggles",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/giggle-logo_144x144.png"
  },
  "652_114": {
    "clientName": "Wayfair",
    "clientLogo": null
  },
  "56_0": {
    "clientName": "Tesco Direct 056",
    "clientLogo": null
  },
  "551_18": {
    "clientName": "Post n Packages Limited",
    "clientLogo": null
  },
  "551_35": {
    "clientName": "Constantine Limited",
    "clientLogo": null
  },
  "3908_0": {
    "clientName": "Silent Dreams",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/silent-dreams-144x-144x-.png"
  },
  "5031_0": {
    "clientName": "G Decor Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "77_12": {
    "clientName": "Screen with envy",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/screen-with-envy-order.jpg"
  },
  "2049_0": {
    "clientName": "Matalan",
    "clientLogo": "https://images.prismic.io/ev-mercury/00a10a87-3d5a-4114-a1db-0a0fd9115789_DF+Circle+%28002%29+3.png?auto=compress,format"
  },
  "3636_1": {
    "clientName": "Sports and Safety",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "921_22": {
    "clientName": "Kukri Sports",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kukri-logo.png"
  },
  "5569_0": {
    "clientName": "Vipa Car Parts",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3382_0": {
    "clientName": "I Saw It First",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/isawitfirst.144x144-002-.png"
  },
  "40_3": {
    "clientName": "Harvey Roob",
    "clientLogo": null
  },
  "310_032": {
    "clientName": "Cheaper Online",
    "clientLogo": "https://images.prismic.io/ev-mercury/516688df-b9d3-4780-86e8-610a4dc6f91d_Cheaper+online.png?auto=compress,format"
  },
  "4428_0": {
    "clientName": "Brandpath",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "674_4": {
    "clientName": "Isabella Oliver",
    "clientLogo": null
  },
  "896_0": {
    "clientName": "PTS Worldwide Express",
    "clientLogo": null
  },
  "492_14": {
    "clientName": "Agent Provocateur",
    "clientLogo": null
  },
  "216_0": {
    "clientName": "Parcel Station",
    "clientLogo": "https://images.prismic.io/ev-mercury/f74c56d0-aa89-4d35-9524-078afae1961f_logowhite-500+%28002%29+resized.jpg?auto=compress,format"
  },
  "2081_0": {
    "clientName": "Craft Gin Club",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/craft-gin-club-logo.png"
  },
  "519_0": {
    "clientName": "Parcel Wise",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/parcel-wise.png"
  },
  "2075_0": {
    "clientName": "Bochen Trading LTD / T/A Panana",
    "clientLogo": null
  },
  "2593_1": {
    "clientName": "Currentbody",
    "clientLogo": "https://images.prismic.io/ev-mercury/5bcfad4c-20ec-4a72-9b2e-ea3e2c85674e_current.png?auto=compress,format"
  },
  "652_72": {
    "clientName": "Silverline",
    "clientLogo": null
  },
  "709_0": {
    "clientName": "Arvarto Rituals",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/rituals.png"
  },
  "2485_4": {
    "clientName": "Blackleaf",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/blackleaf-logo.png"
  },
  "652_115": {
    "clientName": "LLYTech Inc",
    "clientLogo": null
  },
  "287_149": {
    "clientName": "TOAST",
    "clientLogo": "https://images.prismic.io/ev-mercury/2fb20d6a-b19f-47ea-bdbb-f389f15e4b2b_toast+logo+RESIZED.png?auto=compress,format"
  },
  "1960_1": {
    "clientName": "Medpets",
    "clientLogo": null
  },
  "841_9": {
    "clientName": "Bon Prix",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bonprix.png"
  },
  "4525_0": {
    "clientName": "Synergy Retail Support",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2618_0": {
    "clientName": "Crew Clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/754ed685-98cd-496d-8bc0-fd9e4c48e895_crew.png?auto=compress,format"
  },
  "321_0": {
    "clientName": "Premium Lamps",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/premium-lamps.png"
  },
  "1842_0": {
    "clientName": "Vraj RCH Ltd",
    "clientLogo": null
  },
  "1004_11": {
    "clientName": "Sourceful Insured",
    "clientLogo": null
  },
  "443_2": {
    "clientName": "ZeroWater",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "909_0": {
    "clientName": "Safelincs",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/safelinc.png"
  },
  "2620_4": {
    "clientName": "XBite",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26200004app.png"
  },
  "742_5": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos.png"
  },
  "817_6": {
    "clientName": "Remedy Drinks",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8170006app.png"
  },
  "2156_0": {
    "clientName": "T J Hughes ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tj-hughes-logo.jpg"
  },
  "652_136": {
    "clientName": "BennettAndBates",
    "clientLogo": null
  },
  "772_26": {
    "clientName": "Tom Ford",
    "clientLogo": null
  },
  "4550_1": {
    "clientName": "MPAY",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_122": {
    "clientName": "PKGreenEnterpriseLtd",
    "clientLogo": null
  },
  "551_13": {
    "clientName": "Cotswold Trading Broadway Ltd",
    "clientLogo": null
  },
  "1808_0": {
    "clientName": "Evri",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "737_1": {
    "clientName": "CM001",
    "clientLogo": null
  },
  "506_0": {
    "clientName": "Kidco Trading Ltd",
    "clientLogo": null
  },
  "4279_0": {
    "clientName": "No Gunk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/0000-no-gunk-144-x-144.jpg"
  },
  "440_0": {
    "clientName": "We Can Source It",
    "clientLogo": null
  },
  "716_4": {
    "clientName": "DulceLino Ltd",
    "clientLogo": null
  },
  "929_6": {
    "clientName": "Wow AB",
    "clientLogo": " https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2289_0": {
    "clientName": "Yorkshire Trading Co.",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ytc-144-x-144.png"
  },
  "2664_0": {
    "clientName": "Baruch Enterprises Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/thebatterymasters_logo_144x144px.png"
  },
  "389_0": {
    "clientName": "RWB Fulfilment",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/rwb-fulfilment.png"
  },
  "4005_0": {
    "clientName": "Euro Car Mats",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/02-ev0021-logo-resizing-for-print-in-store-devices_-web-and-app-click-carmats-144x144.png"
  },
  "492_44": {
    "clientName": "Dorothy Perkins",
    "clientLogo": null
  },
  "653_13": {
    "clientName": "Taylors",
    "clientLogo": null
  },
  "652_121": {
    "clientName": "Champion Sheds",
    "clientLogo": null
  },
  "4533_0": {
    "clientName": "Wetsuit Outlet",
    "clientLogo": "https://images.prismic.io/ev-mercury/4bc318f9-42ea-4599-b296-a6404bfe5345_WO+SOCIAL+ICON+%281%29.jpg?auto=compress,format"
  },
  "5317_9": {
    "clientName": "David Gandy Wellwear",
    "clientLogo": "https://images.prismic.io/ev-mercury/4c6c8d9d-9a44-4473-a004-a650f8d6009a_david+gandy.png?auto=compress,format"
  },
  "2730_4": {
    "clientName": "J Rosenthal & Son (Free)",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2749_31": {
    "clientName": "Werns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "253_29": {
    "clientName": "Skinny Dip",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/skinny-dip.png"
  },
  "2485_8": {
    "clientName": "Simply Scuba",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/simply-scuba-logo.png"
  },
  "2680_0": {
    "clientName": "Lookiero",
    "clientLogo": "https://images.prismic.io/ev-mercury/30f718ed-5a17-4791-b96d-4db6b4eedf7d_lookario.png?auto=compress,format"
  },
  "826_10": {
    "clientName": "Lascana",
    "clientLogo": null
  },
  "447_0": {
    "clientName": "JoJo Maman Bebe",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jojo-logo.jpg"
  },
  "653_3": {
    "clientName": "The Amazing Chocolate Workshop",
    "clientLogo": null
  },
  "932_2": {
    "clientName": "GNC",
    "clientLogo": null
  },
  "5345_0": {
    "clientName": "Plastoreg Smidt GmbH",
    "clientLogo": "https://images.prismic.io/ev-mercury/00852bbf-f4de-4385-bd96-f5c1ab1194f0_DF+Circle+%28002%29+122.png?auto=compress,format"
  },
  "975_19": {
    "clientName": "Vionics",
    "clientLogo": null
  },
  "2288_0": {
    "clientName": "Nantwich Cheese Company Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nantwich-cheese-co.png"
  },
  "900_0": {
    "clientName": "River Island",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/riverisland.png"
  },
  "284_0": {
    "clientName": "Tesco Direct 284",
    "clientLogo": null
  },
  "2532_0": {
    "clientName": "Drop Point",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/droppoint-212x300.png"
  },
  "4601_0": {
    "clientName": "Snowleader",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "232_0": {
    "clientName": "Universal Textiles",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/universaltextilesoutletlogo_144x.jpg"
  },
  "2699_11": {
    "clientName": "My Clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/a11413a6-3658-44ad-8ed9-6e54327c2e4d_MYCLOTHING.png?auto=compress,format"
  },
  "999_4": {
    "clientName": "3 Monkeys",
    "clientLogo": null
  },
  "39_34": {
    "clientName": "Castore Glasgow",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2572_0": {
    "clientName": "M & R Imports Ltd ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25720000app.png"
  },
  "652_153": {
    "clientName": "Cambertown Ltd",
    "clientLogo": null
  },
  "3689_0": {
    "clientName": "Start Fitness",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ev0021-logo-resizing-for-print-in-store-devices_-web-and-app-start-fitness-logo-144x144px-sma.png"
  },
  "975_105": {
    "clientName": "Hera Clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/8f106b8e-2155-405e-8911-85cc483750c2_hera+logo.png?auto=compress,format"
  },
  "310_0": {
    "clientName": "Huxloe Logistics",
    "clientLogo": null
  },
  "703_0": {
    "clientName": "Damart",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/7030000app.png"
  },
  "975_102": {
    "clientName": "Gym+Coffee UK Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2699_22": {
    "clientName": "Club Legends",
    "clientLogo": "https://images.prismic.io/ev-mercury/38fd7b12-178d-43df-b520-72c9863a67e8_CLUBLEGENDS.png?auto=compress,format"
  },
  "25_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "894_18": {
    "clientName": "Allsole",
    "clientLogo": "https://images.prismic.io/ev-mercury/1d632b73-0cfa-412a-bc04-fa6db8cd1427_Allsole-Logo-1024x636+%28002%29.jpg?auto=compress,format"
  },
  "460_40": {
    "clientName": " Rex Brown",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "297_0": {
    "clientName": "Gorgeous Shop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gorgeousshop.png"
  },
  "2682_0": {
    "clientName": "Reskinned",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/reskinned-logo.png"
  },
  "914_12": {
    "clientName": "Good For Nothing Ltd",
    "clientLogo": null
  },
  "628_9": {
    "clientName": "SHOE TAILOR",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "2013_10": {
    "clientName": "Shoe Embassy ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/shoe-embassy_logo.png"
  },
  "354_1": {
    "clientName": "Aldi Hampers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/aldi.png"
  },
  "5433_0": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/b5f94ab7-6f1b-4617-bdb3-0fdc95430c54_ann+summers.png?auto=compress,format"
  },
  "50_1": {
    "clientName": "Fetchy",
    "clientLogo": null
  },
  "538_0": {
    "clientName": "Rebound",
    "clientLogo": null
  },
  "5353_0": {
    "clientName": "Mint Velvet",
    "clientLogo": "https://images.prismic.io/ev-mercury/f069dd74-b4c6-4760-a514-e49e51755c38_mintvelvet.png?auto=compress,format"
  },
  "975_104": {
    "clientName": "Happy Returns",
    "clientLogo": ""
  },
  "2050_0": {
    "clientName": "Salvation Army",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon-donate.png"
  },
  "2345_0": {
    "clientName": "TW Wholesale",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wholesale-and-superstore.png"
  },
  "109_0": {
    "clientName": "Radial",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "310_34": {
    "clientName": "R&G Homeware",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5433_4": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "1004_9": {
    "clientName": "Huoyou -insured",
    "clientLogo": null
  },
  "914_36": {
    "clientName": "OPRO International Ltd",
    "clientLogo": null
  },
  "975_9": {
    "clientName": "EMU",
    "clientLogo": null
  },
  "4736_0": {
    "clientName": "Central Leisure Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/93cb4443-7e6b-4407-a3e4-90be3a81bbc9_Racing+Planet+-+New+Logo.png?auto=compress,format"
  },
  "487_0": {
    "clientName": "Super Smart Services Ltd",
    "clientLogo": null
  },
  "935_0": {
    "clientName": "Party Delights Sorted",
    "clientLogo": "https://images.prismic.io/ev-mercury/d21a31f2-60d8-4565-96dd-2fe2406ee1cf_1891039_686157858093156_392872262_n-350x350.jpg?auto=compress,format"
  },
  "5108_1": {
    "clientName": "The Branded Gift Co.",
    "clientLogo": "https://images.prismic.io/ev-mercury/f601ef09-1ece-4804-a3ea-e3f43ab31393_BGC+%28Purple+BG%29+%281%29+%28002%29.png?auto=compress,format"
  },
  "339_0": {
    "clientName": "Jacobsons",
    "clientLogo": null
  },
  "382_2": {
    "clientName": "Home of Brands",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/homepfbrands_144x144.jpg"
  },
  "5433_6": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "492_8": {
    "clientName": "Mountain Warehouse",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2670000app.png"
  },
  "224_0": {
    "clientName": "Moss Bros",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mossbros.png"
  },
  "1069_1": {
    "clientName": "Ransom Spares Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "975_14": {
    "clientName": "EMU",
    "clientLogo": null
  },
  "492_32": {
    "clientName": "JustFabulous",
    "clientLogo": null
  },
  "652_23": {
    "clientName": "House of Paws",
    "clientLogo": null
  },
  "1953_1": {
    "clientName": "Puzzle",
    "clientLogo": null
  },
  "531_0": {
    "clientName": "White Stuff",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/5310000app.png"
  },
  "2770_30": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "5149_0": {
    "clientName": "ZeroWater",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "631_115": {
    "clientName": "Good Food Group",
    "clientLogo": "https://images.prismic.io/ev-mercury/32560d95-a6c3-4fe3-b036-9311ffa036d0_good+food+group.png?auto=compress,format"
  },
  "160_10": {
    "clientName": "Mirror Reader Offers",
    "clientLogo": null
  },
  "5346_0": {
    "clientName": "UK Grow Shop Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/0c9bbb85-493f-434c-a77f-fd974752d82b_ukgrowshop.png?auto=compress,format"
  },
  "3753_0": {
    "clientName": "Tendering Express",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "655_0": {
    "clientName": "Stortford Toys Limited",
    "clientLogo": null
  },
  "2314_0": {
    "clientName": "Retromend Limited",
    "clientLogo": null
  },
  "64_7": {
    "clientName": "fulfilment",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2699_12": {
    "clientName": "Direct Clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff978175-4b34-4051-9925-fbbbdef24546_DIRECTCLOTHING.png?auto=compress,format"
  },
  "2770_4": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "194_1": {
    "clientName": "Wolves",
    "clientLogo": "https://images.prismic.io/ev-mercury/3ff67d34-3b9a-4844-9ac5-a1fb61244f5b_Wolves+Badge+CMYK.jpg?auto=compress,format"
  },
  "4424_0": {
    "clientName": "Marc OPolo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "470_0": {
    "clientName": "Lesara 2",
    "clientLogo": null
  },
  "786_1": {
    "clientName": "Austria Post",
    "clientLogo": null
  },
  "235_0": {
    "clientName": "The Works",
    "clientLogo": "https://images.prismic.io/ev-mercury/06bd2a2b-c51d-490e-9b46-204826f515a1_theworks.png?auto=compress,format"
  },
  "451_0": {
    "clientName": "Cleverboxes Ltd",
    "clientLogo": null
  },
  "4617_0": {
    "clientName": "TruffleShuffle.com",
    "clientLogo": "https://images.prismic.io/ev-mercury/f3c4c20b-969e-4413-9b0e-b3b5f31ffe89_truffleshuff.png?auto=compress,format"
  },
  "2485_9": {
    "clientName": "Nightgear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nightwear-logo.png"
  },
  "4006_0": {
    "clientName": "Birkenstock",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_70": {
    "clientName": "GrandInternationalDecor",
    "clientLogo": null
  },
  "4256_0": {
    "clientName": "NG World",
    "clientLogo": "https://images.prismic.io/ev-mercury/d3e4571c-e09d-4a34-a7e7-7c958262145d_NGWORLD+logo.jpg?auto=compress,format"
  },
  "921_13": {
    "clientName": "Woodhouse",
    "clientLogo": null
  },
  "551_49": {
    "clientName": "ALM Electrical Solutions Limited",
    "clientLogo": null
  },
  "785_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "362_0": {
    "clientName": "Lands End",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lands-end.png"
  },
  "2526_1": {
    "clientName": "Oceans",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25260001app.png"
  },
  "253_17": {
    "clientName": "JKA",
    "clientLogo": null
  },
  "985_0": {
    "clientName": "Ideal Textiles",
    "clientLogo": null
  },
  "5088_0": {
    "clientName": "Asendia",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5170_0": {
    "clientName": "Applied Nutrition",
    "clientLogo": "https://images.prismic.io/ev-mercury/37eb16dd-f025-4deb-a80b-3d4e786eb316_applied+nutrition+resized.jpg?auto=compress,format"
  },
  "5025_0": {
    "clientName": "Oh Polly Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "551_33": {
    "clientName": "Superdrug",
    "clientLogo": null
  },
  "3754_3": {
    "clientName": "Mattel",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/00000001-mattel-logo.jpg"
  },
  "2718_0": {
    "clientName": "Rupali Online",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/27180000app.png"
  },
  "2770_11": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "2242_0": {
    "clientName": "UBsend A/S",
    "clientLogo": null
  },
  "670_1": {
    "clientName": "Toms Shoes",
    "clientLogo": null
  },
  "737_0": {
    "clientName": "Central Mailing Services",
    "clientLogo": null
  },
  "631_78": {
    "clientName": "Tiddlers & Nippers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310078app.png"
  },
  "921_12": {
    "clientName": "JD Sports - Cloggs",
    "clientLogo": null
  },
  "5433_2": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3734_0": {
    "clientName": "Gini London Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "847_0": {
    "clientName": "Studio",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "3994_0": {
    "clientName": "Holland Cooper Clothing Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "958_3": {
    "clientName": "GroupOn",
    "clientLogo": null
  },
  "476_0": {
    "clientName": "Tookail LTD",
    "clientLogo": null
  },
  "914_29": {
    "clientName": "Rehab Fashion",
    "clientLogo": null
  },
  "652_25": {
    "clientName": "Swanglen",
    "clientLogo": null
  },
  "345_162": {
    "clientName": "Milner Off Road",
    "clientLogo": "https://images.prismic.io/ev-mercury/4151e108-1958-4adf-bcc0-0deb40fe7b8e_NEW+MILNER+LOGO+resized.jpg?auto=compress,format"
  },
  "160_21": {
    "clientName": "Time Inc",
    "clientLogo": null
  },
  "2479_15": {
    "clientName": "Wera Toolrebels",
    "clientLogo": "https://images.prismic.io/ev-mercury/01e6f004-56c3-4451-a745-12b5e5343830_1202258750273824.jhODXZEmuyaGcG5l97PC_height640.png?auto=compress,format"
  },
  "516_0": {
    "clientName": "I Want Fabric",
    "clientLogo": null
  },
  "643_0": {
    "clientName": "J Parker Bulbs",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/j-parkers-logo.png"
  },
  "5677_0": {
    "clientName": "PolyBags",
    "clientLogo": "https://images.prismic.io/ev-mercury/226e0d06-406d-4bb6-8795-c8c3d3639227_PolyBags+Logo+-+144x144.png?auto=compress,format"
  },
  "5372_0": {
    "clientName": "La Redoute France",
    "clientLogo": "https://images.prismic.io/ev-mercury/c360fc10-8563-436c-b632-9809f30a445b_EVRi+Default+Logo.webp?auto=compress,format"
  },
  "738_0": {
    "clientName": "Studio",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/studio-we-do-wow.png"
  },
  "667_35": {
    "clientName": "Huddersfield 3",
    "clientLogo": null
  },
  "2431_1": {
    "clientName": "Mr Marvis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mr-marvis-logo.png"
  },
  "652_31": {
    "clientName": "Jarapa",
    "clientLogo": null
  },
  "3565_0": {
    "clientName": "Mypure.co.uk",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "914_1": {
    "clientName": "Molton Brown",
    "clientLogo": null
  },
  "656_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "2376_4": {
    "clientName": "Treats n Sweets UK Ltd",
    "clientLogo": null
  },
  "4619_0": {
    "clientName": "Medino Online",
    "clientLogo": "https://images.prismic.io/ev-mercury/1411b9ad-5491-4190-9656-ab409fb340d9_medino+logo.png?auto=compress,format"
  },
  "3636_2": {
    "clientName": " Island Green",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4373_0": {
    "clientName": "Tamaris",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5433_7": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2431_2": {
    "clientName": "The Modern man",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/modernmanlogo.jpg"
  },
  "1056_12": {
    "clientName": "Landmark PL A",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2597_0": {
    "clientName": "MADE.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/made_144x144.jpg"
  },
  "831_119": {
    "clientName": "Dimensions Scotland Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/39612aec-133d-4cae-ad96-37f70ac360af_L%26R+logo.png?auto=compress,format"
  },
  "148_2": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "492_19": {
    "clientName": "HiHouse.co.uk",
    "clientLogo": null
  },
  "2770_12": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "538_4": {
    "clientName": "Rebound Torque Logistics",
    "clientLogo": null
  },
  "2476_0": {
    "clientName": "Medicinemarketplace.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mmplogo-purple1200px.png"
  },
  "5256_1": {
    "clientName": "GYM KING FREE",
    "clientLogo": " https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "93_0": {
    "clientName": "Coopers of Stortford",
    "clientLogo": null
  },
  "2699_16": {
    "clientName": "Dollymix",
    "clientLogo": "https://images.prismic.io/ev-mercury/42fdb82b-6605-4bf0-b240-5ce081d55669_Dollymix.png?auto=compress,format"
  },
  "754_0": {
    "clientName": "H&M",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/handm.png"
  },
  "2297_0": {
    "clientName": "AYP Healthcare",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ayp-logo.png"
  },
  "2485_1": {
    "clientName": "Surfdome",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/surfdome-logo.png"
  },
  "3417_0": {
    "clientName": "Plumb2u",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "162_2": {
    "clientName": "Clifford James",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/clifford-james.png"
  },
  "652_58": {
    "clientName": "JWP Ltd",
    "clientLogo": null
  },
  "652_110": {
    "clientName": "GFDirectBradleyShenstone",
    "clientLogo": null
  },
  "3910_4": {
    "clientName": "KATE LIVING",
    "clientLogo": "https://images.prismic.io/ev-mercury/298ecd46-23aa-4e00-8e38-9250b71c1277_KATE+LIVING+144X144+1.png?auto=compress,format"
  },
  "765_0": {
    "clientName": "Now Fulfilment",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/now-fulfilment.png"
  },
  "4728_0": {
    "clientName": "CSM Logistics Oxfordshire",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "1056_2": {
    "clientName": "Landmark US",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "356_0": {
    "clientName": "Cult Beauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/cult-beauty.png"
  },
  "667_52": {
    "clientName": "Taunton 4",
    "clientLogo": null
  },
  "2642_0": {
    "clientName": "The W10 Collection",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26420000app.png"
  },
  "526_0": {
    "clientName": "Habitat",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/habitat.png"
  },
  "652_119": {
    "clientName": "Plow Hearth",
    "clientLogo": null
  },
  "841_10": {
    "clientName": "Lascana",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lascana.png"
  },
  "825_6": {
    "clientName": "Swimwear 365",
    "clientLogo": null
  },
  "841_2": {
    "clientName": "Freemans",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/freemans-new.png"
  },
  "4634_0": {
    "clientName": "BtoH Ltd (Back to Home)",
    "clientLogo": ""
  },
  "78_0": {
    "clientName": "Ocado",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ocado.png"
  },
  "975_72": {
    "clientName": "Love Brand & Co",
    "clientLogo": null
  },
  "2770_25": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "825_0": {
    "clientName": "FGH Agency",
    "clientLogo": null
  },
  "971_0": {
    "clientName": "LoveCrafts",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lovecrafts.png"
  },
  "551_14": {
    "clientName": "AJS Workwear Ltd",
    "clientLogo": null
  },
  "914_6": {
    "clientName": "Lovell Rugby",
    "clientLogo": null
  },
  "4533_1": {
    "clientName": "The Drillshed",
    "clientLogo": "https://images.prismic.io/ev-mercury/0693159d-39b5-4266-8a41-e4255e634661_drillshed+logo.png?auto=compress,format"
  },
  "659_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "628_11": {
    "clientName": "MARISOTA",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6280000app.png"
  },
  "160_17": {
    "clientName": "Telegraph Reader Offers",
    "clientLogo": null
  },
  "652_138": {
    "clientName": "Lasita",
    "clientLogo": null
  },
  "253_13": {
    "clientName": "Sahara",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sahara.png"
  },
  "652_112": {
    "clientName": "RutlandCountyGardenFurniture",
    "clientLogo": null
  },
  "287_150": {
    "clientName": "BAM Clothing",
    "clientLogo": "https://images.prismic.io/ev-mercury/ec7c4b40-7ebb-4092-91fe-8864255292bb_BAMboo.png?auto=compress,format"
  },
  "2357_0": {
    "clientName": "Dorothy Perkins",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23570000app.png"
  },
  "792_0": {
    "clientName": "URBAN",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/urban-outfitters.png"
  },
  "253_25": {
    "clientName": "Pink Clove",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pink-clove.png"
  },
  "894_6": {
    "clientName": "My Protein",
    "clientLogo": null
  },
  "492_10": {
    "clientName": "Mango UK",
    "clientLogo": null
  },
  "2115_0": {
    "clientName": "Electrical World",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/electrical-world-logo.png"
  },
  "921_9": {
    "clientName": "Oswald Bailey",
    "clientLogo": null
  },
  "460_1": {
    "clientName": "La Redoute",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "5163_2": {
    "clientName": "Tupperware Direct",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2533_0": {
    "clientName": "B&M",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bm-logo-144x144.png"
  },
  "1004_10": {
    "clientName": "YTO &#8211; insured",
    "clientLogo": null
  },
  "586_0": {
    "clientName": "Secret Sales Ltd",
    "clientLogo": null
  },
  "1004_2": {
    "clientName": "CCL Insured",
    "clientLogo": null
  },
  "551_43": {
    "clientName": "Hippychick Ltd",
    "clientLogo": null
  },
  "1209_2": {
    "clientName": "VE Collection returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2068_0": {
    "clientName": "UPX UK Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/upx-uk-logo.png"
  },
  "117_11": {
    "clientName": "Haddow Group",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "467_0": {
    "clientName": "FDS Corporation Ltd",
    "clientLogo": null
  },
  "5199_0": {
    "clientName": "RDi International Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/5005820c-7966-4726-b291-7417bc5f0cf5_homevalet-120x30px+for+Amazon+%28002%29.jpg?auto=compress,format"
  },
  "254_2": {
    "clientName": "Elite",
    "clientLogo": null
  },
  "665_5": {
    "clientName": "Wallis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wallis-logo.jpg"
  },
  "2289_1": {
    "clientName": "Rydale",
    "clientLogo": null
  },
  "791_6": {
    "clientName": "4th & Reckless",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/4th-reckless.png"
  },
  "4716_0": {
    "clientName": "Hurley Burley Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "492_28": {
    "clientName": "JDS",
    "clientLogo": null
  },
  "829_0": {
    "clientName": "Walker Logistics ",
    "clientLogo": null
  },
  "1958_5": {
    "clientName": "Tigers Global Thurrock 7Mesh",
    "clientLogo": null
  },
  "328_0": {
    "clientName": "Tokyo Laundry",
    "clientLogo": null
  },
  "2749_22": {
    "clientName": "Paul Valentine",
    "clientLogo": "https://images.prismic.io/ev-mercury/ceac3950-340f-48b8-a480-789113052694_Paul_Valentine_black_neu.jpg?auto=compress,format"
  },
  "3509_0": {
    "clientName": "Ormskirk Pets",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/opmain.png"
  },
  "5545_0": {
    "clientName": "Eurologisticsworld",
    "clientLogo": "https://images.prismic.io/ev-mercury/a030fdb5-28dd-4fa9-8936-50598df0f741_EURO+LOGISTICS+LOGO.png?auto=compress,format"
  },
  "453_1": {
    "clientName": "Pure Collection",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pure-collection-logonew.jpg"
  },
  "2140_0": {
    "clientName": "Savers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/savers-logo.svg"
  },
  "652_170": {
    "clientName": "Elite Housewares",
    "clientLogo": null
  },
  "956_0": {
    "clientName": "The White Company (UK) Limited",
    "clientLogo": null
  },
  "551_46": {
    "clientName": "Global Pheonix Technologies",
    "clientLogo": null
  },
  "975_13": {
    "clientName": "The Trade Partner",
    "clientLogo": null
  },
  "802_735": {
    "clientName": "Debenhams Direct - Debenhams",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "759_125": {
    "clientName": "Hub Europe - Decrescent",
    "clientLogo": null
  },
  "916_0": {
    "clientName": "Country House Outdoor",
    "clientLogo": null
  },
  "390_3": {
    "clientName": "Big Home Shop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/big-home-shop.png"
  },
  "149_1": {
    "clientName": "Meaningful Beauty",
    "clientLogo": null
  },
  "48_2": {
    "clientName": "Create and Craft",
    "clientLogo": null
  },
  "2699_20": {
    "clientName": "Akuma Sports",
    "clientLogo": "https://images.prismic.io/ev-mercury/a756eb4c-ab51-485c-867c-1111c4bf6f47_AKUMASPORTS.png?auto=compress,format"
  },
  "1989_0": {
    "clientName": "TVP Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tvp-logo.png"
  },
  "1069_0": {
    "clientName": "Ransom Spares",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5062_2": {
    "clientName": "Ghost London",
    "clientLogo": "https://images.prismic.io/ev-mercury/e87a107d-ab05-4395-a612-795ed6052074_Ghost+154px+x+91px+%28002%29+resized.jpg?auto=compress,format"
  },
  "4663_0": {
    "clientName": "OutdoorGB",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "653_0": {
    "clientName": "Parcelhub",
    "clientLogo": null
  },
  "333_6": {
    "clientName": "MSZ1",
    "clientLogo": null
  },
  "382_0": {
    "clientName": "No1Brands4you",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/no1brands4you-logo.png"
  },
  "2749_19": {
    "clientName": " TeVeo",
    "clientLogo": "https://images.prismic.io/ev-mercury/c6ad9fcd-2343-438b-9707-a38902053202_Teveo-Logo-Full-Black.png?auto=compress,format"
  },
  "975_2": {
    "clientName": "SDBX 001",
    "clientLogo": null
  },
  "119_0": {
    "clientName": "Debenhams Milton Keynes OSSR",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "492_29": {
    "clientName": "Joe Browns",
    "clientLogo": null
  },
  "652_100": {
    "clientName": "PhoenixSafe",
    "clientLogo": null
  },
  "151_37": {
    "clientName": "Sports Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1510037app.png"
  },
  "5185_0": {
    "clientName": "Select Hardware Ltd ",
    "clientLogo": "https://images.prismic.io/ev-mercury/d7d369c8-1d74-4222-bb3e-8cdb617d5640_kf+logo.png?auto=compress,format"
  },
  "109_3": {
    "clientName": "ASEA",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_137": {
    "clientName": "Cushoo",
    "clientLogo": null
  },
  "3375_1": {
    "clientName": "Grass and Air Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/grass-air-144x144px-002-.png"
  },
  "398_0": {
    "clientName": "Primrose",
    "clientLogo": null
  },
  "4_5": {
    "clientName": "Ballyclare",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1618578365-5243110m.png"
  },
  "645_0": {
    "clientName": "Scotts and Co",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/scotts-co.png"
  },
  "404_1": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos.png"
  },
  "2739_9": {
    "clientName": "Austin's",
    "clientLogo": "https://images.prismic.io/ev-mercury/07f1ae54-53d7-4440-beaf-38c4fb5e2043_austins.png?auto=compress,format"
  },
  "2111_0": {
    "clientName": "I Love Wallpaper",
    "clientLogo": "https://images.prismic.io/ev-mercury/1250c101-3498-4478-ad5a-8ef692ab3ba0_ilovewall.png?auto=compress,format"
  },
  "189_0": {
    "clientName": "Home Discount",
    "clientLogo": null
  },
  "670_0": {
    "clientName": "Parcelnet",
    "clientLogo": null
  },
  "3720_0": {
    "clientName": "Pixie Girls",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5608_0": {
    "clientName": "Spudos",
    "clientLogo": "https://images.prismic.io/ev-mercury/443e7783-77ed-40f4-a87a-2c74b7e57f04_spudos.png?auto=compress,format"
  },
  "840_6": {
    "clientName": "Swimwear365",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/swimwear365.png"
  },
  "2431_4": {
    "clientName": "Calissa",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/calissa-logo.jpg"
  },
  "551_22": {
    "clientName": "Pharmacy Direct Ltd",
    "clientLogo": null
  },
  "5172_0": {
    "clientName": "Bier Company",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "674_9": {
    "clientName": "EveMattress",
    "clientLogo": null
  },
  "551_0": {
    "clientName": "GFS 4 Hour",
    "clientLogo": null
  },
  "535_0": {
    "clientName": "Larena Fashions",
    "clientLogo": null
  },
  "3728_0": {
    "clientName": "Intertextiles",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "233_0": {
    "clientName": "Oodji",
    "clientLogo": null
  },
  "408_3": {
    "clientName": "Boxfresh",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/boxfresh2.png"
  },
  "2699_17": {
    "clientName": "Molly & Monty",
    "clientLogo": "https://images.prismic.io/ev-mercury/9d773f6f-46b5-454e-a625-626b520ae38f_MOLLYANDMONTY.png?auto=compress,format"
  },
  "652_89": {
    "clientName": "Vitavia",
    "clientLogo": null
  },
  "2419_0": {
    "clientName": "Patch",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/patch-plants-logo.png"
  },
  "2770_20": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "329_1": {
    "clientName": "Bedding Market",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/home-bedding-store.png"
  },
  "226_0": {
    "clientName": "John Cotton Group Ltd",
    "clientLogo": null
  },
  "310_32": {
    "clientName": "Cheaper Online",
    "clientLogo": "https://images.prismic.io/ev-mercury/516688df-b9d3-4780-86e8-610a4dc6f91d_Cheaper+online.png?auto=compress,format"
  },
  "653_2": {
    "clientName": "TCOC",
    "clientLogo": null
  },
  "737_5": {
    "clientName": "CMS 4",
    "clientLogo": null
  },
  "2699_5": {
    "clientName": "M&S Personalised Schools Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4924_0": {
    "clientName": "J & A COMMERCE LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/8be55826-bdcb-4ede-b05a-8638896b17af_thumbnail_PHOTO-2022-11-23-09-42-36+%28002%29+6.2.jpeg?auto=compress,format"
  },
  "667_60": {
    "clientName": "Bradford 5",
    "clientLogo": null
  },
  "390_0": {
    "clientName": "Big Home Shop",
    "clientLogo": null
  },
  "361_1": {
    "clientName": "Wiggle",
    "clientLogo": "https://images.prismic.io/ev-mercury/3003ae4e-c825-4598-b128-2428767b2498_DF+Circle+%28002%29+wiggle.png?auto=compress,format"
  },
  "151_66": {
    "clientName": "Frasers",
    "clientLogo": "https://images.prismic.io/ev-mercury/ca146160-a7b1-4e91-a1c0-a236624e1351_EVRI+144x144.png?auto=compress,format"
  },
  "109_9": {
    "clientName": "R.E.M Beauty",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "866_0": {
    "clientName": "Linens Limited",
    "clientLogo": null
  },
  "4562_0": {
    "clientName": "Heavenly Feet",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3423_0": {
    "clientName": "My Brightstar Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wallart.jpg"
  },
  "556_0": {
    "clientName": "Missguided Electio",
    "clientLogo": null
  },
  "306_1": {
    "clientName": "MHP SMS",
    "clientLogo": null
  },
  "181_0": {
    "clientName": "Postscript",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/postscript.png"
  },
  "4240_0": {
    "clientName": "JD Sports",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-sports.png"
  },
  "4530_0": {
    "clientName": "Kikiyo",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "591_0": {
    "clientName": "CE Stevenson Motors",
    "clientLogo": null
  },
  "29_2": {
    "clientName": "Precious Little One",
    "clientLogo": null
  },
  "2689_0": {
    "clientName": "Galaxy Connect Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/galaxy144.jpg"
  },
  "4897_000": {
    "clientName": "Londonlovesbeauty.com",
    "clientLogo": "https://images.prismic.io/ev-mercury/20812b76-2e61-4fd6-a125-2d78610d45ea_Logo+for+London+Loves+Beauty+144x144.jpg?auto=compress,format"
  },
  "421_0": {
    "clientName": "Outdoor Value",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/outdoor-value.png"
  },
  "155_0": {
    "clientName": "Beachbody UK Ltd",
    "clientLogo": null
  },
  "975_71": {
    "clientName": "Love Brand & Co",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/9750071.png"
  },
  "551_38": {
    "clientName": "Lovell Sports",
    "clientLogo": null
  },
  "5644_0": {
    "clientName": "UKB4C Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/919c213c-b379-4627-aa09-2717b9cfdb61_ukb2c.png?auto=compress,format"
  },
  "103_7": {
    "clientName": "JoJo Maman Bebe",
    "clientLogo": "https://images.prismic.io/ev-mercury/693ee862-4819-4899-9f55-c2fda1f52647_jojo.png?auto=compress,format"
  },
  "914_31": {
    "clientName": "Last Word Apparel Ltd",
    "clientLogo": null
  },
  "652_46": {
    "clientName": "Minka Enterprises",
    "clientLogo": null
  },
  "652_146": {
    "clientName": "GFDirectBradleyEastGrinstead",
    "clientLogo": null
  },
  "178_7": {
    "clientName": "Taj Logistics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5314_0": {
    "clientName": "Buzz Catering",
    "clientLogo": "https://images.prismic.io/ev-mercury/4b1bb420-cebd-4ab9-bae2-9af754925607_buzz+logo.png?auto=compress,format"
  },
  "5549_0": {
    "clientName": "Lounge",
    "clientLogo": "https://images.prismic.io/ev-mercury/688ac961-189e-4dd3-afd8-36f6f3b24828_lounge.png?auto=compress,format"
  },
  "2699_14": {
    "clientName": "Player Layer",
    "clientLogo": "https://images.prismic.io/ev-mercury/8dc12cfe-4128-442e-87ca-e2b7d0bd7254_PLAYERLAYER.png?auto=compress,format"
  },
  "2526_2": {
    "clientName": "Frank Green",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25260002app.png"
  },
  "914_26": {
    "clientName": "Johnny's Sister Limited",
    "clientLogo": null
  },
  "711_0": {
    "clientName": "Debenhams",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "253_20": {
    "clientName": "Royal & Awesome",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/royalawesome.png"
  },
  "2770_9": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "889_0": {
    "clientName": "Lakeland Light & Large",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "612_0": {
    "clientName": "Precision Printing",
    "clientLogo": null
  },
  "894_38": {
    "clientName": "Glossybox",
    "clientLogo": "https://images.prismic.io/ev-mercury/a366f1e8-586c-46c4-9441-9c0543f1ac5f_glossybox.png?auto=compress,format"
  },
  "4446_0": {
    "clientName": "Active Ants",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "530_0": {
    "clientName": "Lakeland DD Suppliers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "665_6": {
    "clientName": "Miss Selfridge",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/miss-selfridge.png"
  },
  "670_6": {
    "clientName": "Dani Return Test",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "29_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "880_0": {
    "clientName": "Forward",
    "clientLogo": null
  },
  "2749_5": {
    "clientName": "Horl",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "631_81": {
    "clientName": "Cardiff City FC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310081.png"
  },
  "999_0": {
    "clientName": "Trojan Electronics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/00001trojan-logo.jpg"
  },
  "772_3": {
    "clientName": "Clinique",
    "clientLogo": null
  },
  "1004_0": {
    "clientName": "CCL",
    "clientLogo": null
  },
  "840_2": {
    "clientName": "Freemans",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/freemans-new.png"
  },
  "953_0": {
    "clientName": "WeRChristmas",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/werchristmas.png"
  },
  "817_2": {
    "clientName": "See Switches",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8170002app.png"
  },
  "2668_0": {
    "clientName": "Postal Connection",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/postcologo_144x144-2-.png"
  },
  "2319_0": {
    "clientName": "John Aird & Co ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/john-aird-co-logo.jpg"
  },
  "2699_8": {
    "clientName": "Schoolwear",
    "clientLogo": "https://images.prismic.io/ev-mercury/945ad12e-30a3-4022-853c-4369bc16e177_SCHOOLWEAR.png?auto=compress,format"
  },
  "804_1": {
    "clientName": "Karen Millen",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/karenmillen.png"
  },
  "395_0": {
    "clientName": "Redfoot",
    "clientLogo": null
  },
  "160_6": {
    "clientName": "Guardian Reader Offers",
    "clientLogo": null
  },
  "1952_0": {
    "clientName": "Edinburgh Woollen Mill",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/ewm-logo.png"
  },
  "550_31": {
    "clientName": "NIO Cocktails",
    "clientLogo": null
  },
  "4028_11": {
    "clientName": "MAMMUT",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280011app.png"
  },
  "652_97": {
    "clientName": "AgaRangemaster",
    "clientLogo": null
  },
  "2543_3": {
    "clientName": "Tori Belle",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tori-belle_144x144.jpg"
  },
  "1853_1": {
    "clientName": "NODI",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5625_0": {
    "clientName": "South Eastern Horticultural",
    "clientLogo": ""
  },
  "914_34": {
    "clientName": "Hippychick Ltd",
    "clientLogo": null
  },
  "2749_11": {
    "clientName": "Tierliebhaber",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4087_0": {
    "clientName": "Thrift+",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "473_26": {
    "clientName": "Playlikemum",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2267_0": {
    "clientName": "Pets at Home",
    "clientLogo": "https://images.prismic.io/ev-mercury/120c4224-51ab-4e4e-adb6-843e6ac2ffb3_pets+at+home+circle+logo.png?auto=compress,format"
  },
  "275_1": {
    "clientName": "Package In Ltd ",
    "clientLogo": null
  },
  "2749_20": {
    "clientName": "Vivi Mari",
    "clientLogo": "https://images.prismic.io/ev-mercury/4fb4ca90-fb73-43cf-a823-13f765a946d4_VIVIMARI-Logo.png?auto=compress,format"
  },
  "2612_1": {
    "clientName": "Aspire Furniture",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/aspire-144x144-logo-png..png"
  },
  "667_13": {
    "clientName": "Bradford 1",
    "clientLogo": null
  },
  "652_93": {
    "clientName": "HighgateBedsLtd",
    "clientLogo": null
  },
  "681_0": {
    "clientName": "ITD Global International",
    "clientLogo": null
  },
  "667_16": {
    "clientName": "Bradford 4",
    "clientLogo": null
  },
  "492_24": {
    "clientName": "DOMU Brands",
    "clientLogo": null
  },
  "785_10": {
    "clientName": "Direct Express",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/direct-xpress-logo.png"
  },
  "36_2": {
    "clientName": "Iconic Lights",
    "clientLogo": null
  },
  "914_23": {
    "clientName": "Feather London",
    "clientLogo": null
  },
  "3922_0": {
    "clientName": "Cernucci",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/39220000app.png"
  },
  "785_2": {
    "clientName": "Eckman",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/eckman-logo.png"
  },
  "492_13": {
    "clientName": "Cascade",
    "clientLogo": null
  },
  "652_67": {
    "clientName": "Garden Games Ltd",
    "clientLogo": null
  },
  "5317_4": {
    "clientName": "AKT London",
    "clientLogo": "https://images.prismic.io/ev-mercury/42f13440-22da-44b2-bf24-9592c58cf177_AKT%E2%80%93Logo-Black.png?auto=compress,format"
  },
  "739_0": {
    "clientName": "Superdry",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/superdry.png"
  },
  "652_2": {
    "clientName": "Sambell Engineering Limited",
    "clientLogo": null
  },
  "3996_0": {
    "clientName": "Boxraw Ltd",
    "clientLogo": ""
  },
  "80_0": {
    "clientName": "Afibel",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/afibel-logo.png"
  },
  "272_5": {
    "clientName": "Ogoship Return",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ogoship-return-logo.png"
  },
  "934_1": {
    "clientName": "DSV",
    "clientLogo": null
  },
  "975_91": {
    "clientName": "Ganni",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "932_4": {
    "clientName": "Healthbox",
    "clientLogo": null
  },
  "631_82": {
    "clientName": "The Electrical counter",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310082.png"
  },
  "975_8": {
    "clientName": "Unilever",
    "clientLogo": null
  },
  "3558_0": {
    "clientName": "Great Bear Distribution Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "288_12": {
    "clientName": "TrueShopping R",
    "clientLogo": null
  },
  "460_38": {
    "clientName": "Lloyd Pascal",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "811_28": {
    "clientName": "VUSE",
    "clientLogo": "https://images.prismic.io/ev-mercury/e090f559-578d-450b-854a-fbe078b0bfd5_VUSE+%28002%29.png?auto=compress,format"
  },
  "585_0": {
    "clientName": "Ossa Fashion Ltd",
    "clientLogo": null
  },
  "1013_2": {
    "clientName": "TPZ group Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/01-tpz.jpg"
  },
  "1209_0": {
    "clientName": "Vision Express",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/visionexpress.png"
  },
  "112_0": {
    "clientName": "Buy It Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/buy-it-direct.png"
  },
  "652_79": {
    "clientName": "BentleyDesignsLtd",
    "clientLogo": null
  },
  "4307_0": {
    "clientName": "Just Worn",
    "clientLogo": "https://images.prismic.io/ev-mercury/a9f24165-bd67-45bd-9b26-1ccdd93522ad_justwarnlogo.png?auto=compress,format"
  },
  "667_26": {
    "clientName": "East London 2",
    "clientLogo": null
  },
  "975_0": {
    "clientName": "Bleckmann Logistics",
    "clientLogo": null
  },
  "825_5": {
    "clientName": "Curvissa",
    "clientLogo": null
  },
  "2133_0": {
    "clientName": "Jarrold & Sons Ltd ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jarrold_logo.png"
  },
  "390_2": {
    "clientName": "Gym Room",
    "clientLogo": null
  },
  "460_45": {
    "clientName": "Present Time",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "768_2": {
    "clientName": "The Cake Decorating Company",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-cake-decorating-company.png"
  },
  "914_7": {
    "clientName": "Mamas & Papas",
    "clientLogo": null
  },
  "462_19": {
    "clientName": "Atlantic Therapeutics",
    "clientLogo": null
  },
  "1958_0": {
    "clientName": "Tigers Global Logistics",
    "clientLogo": null
  },
  "5618_2": {
    "clientName": "Gentle Grip",
    "clientLogo": "https://images.prismic.io/ev-mercury/cf8f207e-e0cb-4a25-afa9-87a3fb9be74c_gentle++grip.png?auto=compress,format"
  },
  "6652_108": {
    "clientName": "Woven Magic",
    "clientLogo": null
  },
  "2252_0": {
    "clientName": "Poundland",
    "clientLogo": "https://images.prismic.io/ev-mercury/c129bb21-27f0-4624-b3e5-7a28ecb728e0_Poundland_X_Poundshop_Logo.jpg?auto=compress,format"
  },
  "3586_1": {
    "clientName": "FBP",
    "clientLogo": "https://images.prismic.io/ev-mercury/e7824bef-a4f7-4ad1-a6df-9a2e9f4bb530_Frames+By+Post+Logo+PNG+144x144+px.png?auto=compress,format"
  },
  "289_1": {
    "clientName": "Blackfeather Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/blackfeather.png"
  },
  "840_8": {
    "clientName": "Witt",
    "clientLogo": null
  },
  "2245_0": {
    "clientName": "Totally Wicked Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/totally-wicked-144x144.jpg"
  },
  "597_0": {
    "clientName": "Quickco",
    "clientLogo": null
  },
  "460_41": {
    "clientName": "Asiatic Rugs",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4922_0": {
    "clientName": "preworn",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2205_0": {
    "clientName": "Mahabis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mahabis.png"
  },
  "4514_9": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2231_0": {
    "clientName": "Green Fulfilment Limited ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/green-fulfilment-limited-logo.png"
  },
  "5120_0": {
    "clientName": "T Shirt and Sons Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "390_1": {
    "clientName": "Physio Room",
    "clientLogo": null
  },
  "150_15": {
    "clientName": "Marketzone 2",
    "clientLogo": null
  },
  "538_3": {
    "clientName": "Rebound Gymshark",
    "clientLogo": null
  },
  "841_3": {
    "clientName": "Kaleidoscope",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kaleidoscopelogonewmarch21.png"
  },
  "5163_1": {
    "clientName": "Tupperware Direct",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "825_2": {
    "clientName": "Freemans",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/freemans-new.png"
  },
  "652_156": {
    "clientName": "Adeco Trading",
    "clientLogo": null
  },
  "574_0": {
    "clientName": "BVG Group - Brecon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bvg-brecon.png"
  },
  "109_8": {
    "clientName": "Pixi",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4028_1": {
    "clientName": "EG STRAUSS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280001app.png"
  },
  "2456_0": {
    "clientName": "The Godspeed Group",
    "clientLogo": "https://images.prismic.io/ev-mercury/5a7d5c16-b6fb-4cfb-a0d8-f6c860852d86_godspeed+2.png?auto=compress,format"
  },
  "253_32": {
    "clientName": "House of Sunny",
    "clientLogo": null
  },
  "253_98": {
    "clientName": "Hot Milk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hotmilk-logom.png"
  },
  "826_8": {
    "clientName": "Witt",
    "clientLogo": null
  },
  "894_3": {
    "clientName": "Ideal Shape",
    "clientLogo": null
  },
  "3415_0": {
    "clientName": "Fulfilment crowd returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4751_1": {
    "clientName": "Double Second ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "241_0": {
    "clientName": "Debenhams Concession",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "3037_1": {
    "clientName": "Bitiba",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/30370001app.png"
  },
  "5067_5": {
    "clientName": "ELFBAR",
    "clientLogo": "https://images.prismic.io/ev-mercury/4a3bee6d-a352-4446-9369-71036c699bce_Elfbar-100.jpg?auto=compress,format"
  },
  "999_6": {
    "clientName": "TCA",
    "clientLogo": null
  },
  "2306_1": {
    "clientName": "Lights 4 Fun",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lights4fun_144x144.jpg"
  },
  "178_0": {
    "clientName": "Erde Ventus Ltd",
    "clientLogo": null
  },
  "248_4": {
    "clientName": "ITD Global 10",
    "clientLogo": null
  },
  "2749_12": {
    "clientName": "Dagsmejan",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "492_27": {
    "clientName": "Jacques Vert Group Ltd",
    "clientLogo": null
  },
  "975_11": {
    "clientName": "Vilebrequin",
    "clientLogo": null
  },
  "652_4": {
    "clientName": "Blackdog Upholstery Limited",
    "clientLogo": null
  },
  "4465_1": {
    "clientName": "Hunkemoller",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "473_19": {
    "clientName": "APS (DOH)",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "492_23": {
    "clientName": "Debenhams Direct",
    "clientLogo": null
  },
  "297_3": {
    "clientName": "Jersey Beauty Co.",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jersey-beauty-co.png"
  },
  "757_0": {
    "clientName": "Go Outdoors Sorted",
    "clientLogo": null
  },
  "198_0": {
    "clientName": "HB Products Limited",
    "clientLogo": null
  },
  "4402_0": {
    "clientName": "Naturisimo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/44020000app.png"
  },
  "71_0": {
    "clientName": "Love Crafts",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/love-crafts.png"
  },
  "259_0": {
    "clientName": "Mister-auto",
    "clientLogo": null
  },
  "5034_0": {
    "clientName": "Pure Pet Food",
    "clientLogo": "https://images.prismic.io/ev-mercury/93e51179-ab82-4767-a3d2-7809a714def8_the+chuck+cheese.png?auto=compress,format"
  },
  "656_1": {
    "clientName": "Evans Boutique",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "981_0": {
    "clientName": "Avon Cosmetics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/avon.png"
  },
  "899_0": {
    "clientName": "EC-Hub",
    "clientLogo": null
  },
  "253_27": {
    "clientName": "Lush London",
    "clientLogo": null
  },
  "2217_3": {
    "clientName": "Asendia HQ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2296_0": {
    "clientName": "JD.com International UK Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_63": {
    "clientName": "Hulme Architectural Fencing",
    "clientLogo": null
  },
  "876_0": {
    "clientName": "Quay",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/quay.png"
  },
  "804_2": {
    "clientName": "Oasis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oasis.png"
  },
  "653_4": {
    "clientName": "Premier Housewares",
    "clientLogo": null
  },
  "1941_1": {
    "clientName": "Smiffys",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/smiffys-logo_144x144px.png"
  },
  "631_109": {
    "clientName": "Botivo",
    "clientLogo": "https://images.prismic.io/ev-mercury/d7940409-748c-4d20-a9f0-d1de0624f854_botivo+logo.png?auto=compress,format"
  },
  "2749_25": {
    "clientName": "Magic Holz ",
    "clientLogo": "https://images.prismic.io/ev-mercury/659b9e06-e515-4a49-92ef-4a3aabb975d0_Black+logo+-+no+background+%28002%29.png?auto=compress,format"
  },
  "2462_0": {
    "clientName": "Maniere De Voir",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/manieredevoir_144x144.png"
  },
  "652_17": {
    "clientName": "Pro-Global Companies Ltd",
    "clientLogo": null
  },
  "2528_0": {
    "clientName": "Cricket Direct Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/cricketdirect144x144-1-.jpg"
  },
  "572_0": {
    "clientName": "AWIWE Solutions GMBH",
    "clientLogo": null
  },
  "914_72": {
    "clientName": "Brevitt Rieker",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/brevit-logo.jpg"
  },
  "4731_0": {
    "clientName": "CSM Logistics Bristol",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "933_0": {
    "clientName": "Dune Group",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dune-group.png"
  },
  "5037_0": {
    "clientName": "Tamaris ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "921_16": {
    "clientName": "Peter Storm",
    "clientLogo": null
  },
  "667_25": {
    "clientName": "East London 1",
    "clientLogo": null
  },
  "310_39": {
    "clientName": "Nudient",
    "clientLogo": ""
  },
  "921_17": {
    "clientName": "JD Sports - Brasher",
    "clientLogo": null
  },
  "716_5": {
    "clientName": "Voice 7 Communication Ltd",
    "clientLogo": null
  },
  "921_3": {
    "clientName": "Scotts Menswear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/scotts.png"
  },
  "722_0": {
    "clientName": "GO Outdoors",
    "clientLogo": null
  },
  "2770_18": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "2770_8": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "293_0": {
    "clientName": "IMX",
    "clientLogo": null
  },
  "178_8": {
    "clientName": "British Car Mats",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2489_002": {
    "clientName": "Rise and Fall",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24890002.app.png"
  },
  "40_17": {
    "clientName": "Solskin",
    "clientLogo": "https://images.prismic.io/ev-mercury/393505b6-7edb-4662-8252-89ffe01a5a69_solskin+circle.png?auto=compress,format"
  },
  "1842_1": {
    "clientName": "Vraj RCH 2",
    "clientLogo": null
  },
  "984_47": {
    "clientName": "WHW",
    "clientLogo": "https://images.prismic.io/ev-mercury/9b8a5cd6-c96a-4df9-9308-bff71851a088_whw+logo+144x144.png?auto=compress,format"
  },
  "287_154": {
    "clientName": "Fourds Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/fcdb6b1b-fa21-4136-a902-9c373b31afaf_GFS+3+154.png?auto=compress,format"
  },
  "5454_0": {
    "clientName": "Fitmart (ESN)",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "148_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "665_4": {
    "clientName": "Evans",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/evans.png"
  },
  "2414_0": {
    "clientName": "Zapper",
    "clientLogo": null
  },
  "658_0": {
    "clientName": "Vinted",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "975_36": {
    "clientName": "Seven For All Mankind return",
    "clientLogo": null
  },
  "447_2": {
    "clientName": "JoJo CS",
    "clientLogo": null
  },
  "184_1": {
    "clientName": "Hawkshed",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hawkshead.png"
  },
  "273_1": {
    "clientName": "Wilkos",
    "clientLogo": null
  },
  "253_15": {
    "clientName": "Sock Ons",
    "clientLogo": null
  },
  "183_0": {
    "clientName": "Kaledeiscope",
    "clientLogo": null
  },
  "312_3": {
    "clientName": "Loyalti",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/loyalti.png"
  },
  "652_5": {
    "clientName": "WF North Allerton",
    "clientLogo": null
  },
  "551_19": {
    "clientName": "The Perfume Shop Limited",
    "clientLogo": null
  },
  "975_7": {
    "clientName": "Gymshark",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/gymshark.png"
  },
  "2270_0": {
    "clientName": "Box On Couriers Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/boxoncourier.png"
  },
  "2325_0": {
    "clientName": "House of Returns",
    "clientLogo": null
  },
  "849_0": {
    "clientName": "Whirlpool UK Appliance Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/05d29b64-cd14-4e76-9312-5b6dceb8b0bf_download+%28002%29.png?auto=compress,format"
  },
  "160_1": {
    "clientName": "BVG-Airflo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bvgairflogroup.png"
  },
  "652_56": {
    "clientName": "LockStock and Barrel",
    "clientLogo": null
  },
  "5036_0": {
    "clientName": "Dynamic Parts Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/ac48ac7f-ff37-46b6-90ef-b9fcbcad5fbf_Dynamic+Parts+Ltd+Logo+%28002%29+resized.jpg?auto=compress,format"
  },
  "4479_0": {
    "clientName": "UK Business Supplies",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2416_0": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "652_15": {
    "clientName": "UKHND",
    "clientLogo": null
  },
  "232_3": {
    "clientName": "Pertemba",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pertembalogo_144x144.jpg"
  },
  "551_12": {
    "clientName": "Hattons Model Railway Limited",
    "clientLogo": null
  },
  "5152_0": {
    "clientName": "Pack-IT.Com Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/186e0bec-323c-4f88-bcc9-b1d07951812e_pack+it+logo+%28003%29.jpg?auto=compress,format"
  },
  "652_103": {
    "clientName": "TheGardenVillage",
    "clientLogo": null
  },
  "4511_0": {
    "clientName": "CleanCo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5042_0": {
    "clientName": "AWD-IT",
    "clientLogo": "https://images.prismic.io/ev-mercury/e62fa95b-7c7d-4a55-8a07-13fdd18be85d_AWD-IT+Logo+BG+%28002%29+144x144.jpg?auto=compress,format"
  },
  "253_24": {
    "clientName": "La Fleur Amour",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-fleur-amour.png"
  },
  "4526_0": {
    "clientName": "Sinners Attire",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5570_0": {
    "clientName": "HSI Global Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/93e72264-8e6c-4c29-9d2e-2cf810ad91eb_HSI.png?auto=compress,format"
  },
  "473_28": {
    "clientName": "Strix",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "453_0": {
    "clientName": "Woolovers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/woolovers-logonew.jpg"
  },
  "2738_1": {
    "clientName": "Champo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/champo_doshas-02-004-002-.png"
  },
  "2735_0": {
    "clientName": "allplants",
    "clientLogo": "https://images.prismic.io/ev-mercury/6dd1fec6-f200-46cc-8b59-d531845e38f9_67fa499f-8e56-4477-91ba-357c46521173.jpg?auto=compress,format"
  },
  "62_1": {
    "clientName": "QUIZMAN",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/quizman.png"
  },
  "253_72": {
    "clientName": "Albaray",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/albaray144x144.png"
  },
  "150_19": {
    "clientName": "PAWS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1500019app.png"
  },
  "2699_18": {
    "clientName": "Shrey Sports",
    "clientLogo": "https://images.prismic.io/ev-mercury/f6ff6137-7eb7-438a-bdd1-039ab1bce9c6_SHREYSPORTS.png?auto=compress,format"
  },
  "190_0": {
    "clientName": "3P Logistics",
    "clientLogo": null
  },
  "180_0": {
    "clientName": "Wish B V",
    "clientLogo": null
  },
  "844_0": {
    "clientName": "URBN UK Ltd",
    "clientLogo": null
  },
  "507_1": {
    "clientName": "Uniqlo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/uniqlo.png"
  },
  "2155_7": {
    "clientName": "Coty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/21550007app.png"
  },
  "631_90": {
    "clientName": "Saracens",
    "clientLogo": "https://images.prismic.io/ev-mercury/f5b1d582-1521-4d75-985b-80f938fe0df8_Saracens.png?auto=compress,format"
  },
  "178_3": {
    "clientName": "Nucleus One",
    "clientLogo": null
  },
  "2489_2": {
    "clientName": "Rise and Fall",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/logo-141x141.png"
  },
  "333_4": {
    "clientName": "MSZ",
    "clientLogo": null
  },
  "95_3": {
    "clientName": "Rinkit account returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "3391_0": {
    "clientName": "RKW",
    "clientLogo": null
  },
  "287_143": {
    "clientName": "Nemesis",
    "clientLogo": "https://images.prismic.io/ev-mercury/ffa1db76-23f1-419f-a819-4ac301da53c7_Nemesis.png?auto=compress,format"
  },
  "4428_5": {
    "clientName": "Ray-Ban",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "894_8": {
    "clientName": "Pro Bike Kit",
    "clientLogo": "https://images.prismic.io/ev-mercury/48e14db0-c804-47a4-a5d5-f9f054ed76ce_probikekit-vector-logo+%28002%29.png?auto=compress,format"
  },
  "634_0": {
    "clientName": "Sportsshoes",
    "clientLogo": "https://images.prismic.io/ev-mercury/0a03feeb-dc79-41f4-a7ec-791a3d2d10c8_Sportsshoes.png?auto=compress,format"
  },
  "1056_8": {
    "clientName": "Landmark UK A",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "674_5": {
    "clientName": "Baukjen",
    "clientLogo": null
  },
  "287_156": {
    "clientName": "CleanCo",
    "clientLogo": "https://images.prismic.io/ev-mercury/238ac0c1-b1ff-448b-a67b-c7a413d2727b_clean+co+logo.png?auto=compress,format"
  },
  "253_53": {
    "clientName": "BraStop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5091_2": {
    "clientName": "Large and Tall Menswear",
    "clientLogo": "https://images.prismic.io/ev-mercury/f3224de2-a565-4c42-af80-65454b71b046_LT+%281%29+RESIZED.png?auto=compress,format"
  },
  "551_30": {
    "clientName": "Perfect Supply",
    "clientLogo": null
  },
  "1068_0": {
    "clientName": "Flavourly",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/flavourly-logo.png"
  },
  "921_20": {
    "clientName": "Supply and Demand",
    "clientLogo": null
  },
  "253_37": {
    "clientName": "Elev8",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/elev8.png"
  },
  "674_8": {
    "clientName": "Abbott Lyon",
    "clientLogo": null
  },
  "918_0": {
    "clientName": "Debenhams Sherburn",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "807_0": {
    "clientName": "ShopRunBack",
    "clientLogo": null
  },
  "975_92": {
    "clientName": "Cariuma",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/9750092app.png"
  },
  "151_67": {
    "clientName": "Amara Living",
    "clientLogo": "https://images.prismic.io/ev-mercury/f1c02c0a-0ac5-447b-8aba-5ee901128c64_amara.png?auto=compress,format"
  },
  "473_6": {
    "clientName": "Hummel",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4028_23": {
    "clientName": "TECTAKE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280023app.png"
  },
  "664_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "5317_3": {
    "clientName": "Lottie London",
    "clientLogo": "https://images.prismic.io/ev-mercury/ac42fd74-1827-48c7-899e-fcc9c3d5c5b1_lottie+london.png?auto=compress,format"
  },
  "287_151": {
    "clientName": "Boxsaver",
    "clientLogo": "https://images.prismic.io/ev-mercury/932cbe5e-0d23-4327-af10-a73e968bb6ca_boxsaver+logo.png?auto=compress,format"
  },
  "492_36": {
    "clientName": "QVC",
    "clientLogo": null
  },
  "652_85": {
    "clientName": "ModeDesigns",
    "clientLogo": null
  },
  "508_0": {
    "clientName": "H&M",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/handm.png"
  },
  "473_10": {
    "clientName": "3M SAMPLES",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2088_0": {
    "clientName": "Direct Warehouse Limited",
    "clientLogo": null
  },
  "652_73": {
    "clientName": "Cambertown Ltd",
    "clientLogo": null
  },
  "652_150": {
    "clientName": "Vidalux",
    "clientLogo": null
  },
  "652_140": {
    "clientName": "VikingSpas",
    "clientLogo": null
  },
  "1056_4": {
    "clientName": "Landmark NL",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "873_0": {
    "clientName": "John Lewis & Partners",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/johnlewis.png"
  },
  "551_1": {
    "clientName": "FatFace",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fatface.png"
  },
  "785_3": {
    "clientName": "Personal Choice",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pc-logo.png"
  },
  "1944_1": {
    "clientName": "Transglobal Express Ltd Feltham",
    "clientLogo": null
  },
  "1954_0": {
    "clientName": "Jaeger",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jaeger-logo.png"
  },
  "90_0": {
    "clientName": "Jigsaw",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jigsaw-logo.png"
  },
  "410_0": {
    "clientName": "Smyths",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/smyths.png"
  },
  "14_0": {
    "clientName": "Richard Jackson Garden",
    "clientLogo": null
  },
  "662_8": {
    "clientName": "The Art Shop Skipton",
    "clientLogo": "https://images.prismic.io/ev-mercury/d9e12a9c-dbcb-458a-a36a-0e2eb54b5a1b_theartshop.png?auto=compress,format"
  },
  "933_1": {
    "clientName": "Dune",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dune-group.png"
  },
  "811_25": {
    "clientName": "Trade Supply",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8110025app.png"
  },
  "2142_0": {
    "clientName": "SBD Holdings Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/sbd-logo.png"
  },
  "486_0": {
    "clientName": "Misspap",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/misspap-logonew.png"
  },
  "2372_1": {
    "clientName": "Grizzi",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23720001app.png"
  },
  "312_5": {
    "clientName": "Zavetti ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2571_0": {
    "clientName": "WJ Industrial",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wj-industrial_144x144.jpg"
  },
  "652_75": {
    "clientName": "Triton Wayfair",
    "clientLogo": null
  },
  "2749_18": {
    "clientName": "Camper Active",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "758_0": {
    "clientName": "myParcelDelivery.com",
    "clientLogo": null
  },
  "914_33": {
    "clientName": "The Naked Marshmallow",
    "clientLogo": null
  },
  "975_79": {
    "clientName": "Lovevery",
    "clientLogo": null
  },
  "804_0": {
    "clientName": "Aurora Fashions",
    "clientLogo": null
  },
  "40_0": {
    "clientName": "Rex Brown Ltd",
    "clientLogo": null
  },
  "893_0": {
    "clientName": "Club L London (Retail) LTD",
    "clientLogo": null
  },
  "495_0": {
    "clientName": "Global Gift House",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/global-logo.png"
  },
  "306_0": {
    "clientName": "Peak Health Distribution",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/emails/default_client_logo.png"
  },
  "652_102": {
    "clientName": "BebeStyle",
    "clientLogo": null
  },
  "596_1": {
    "clientName": "Studio",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/studio-we-do-wow.png"
  },
  "46_0": {
    "clientName": "Cotton Traders",
    "clientLogo": null
  },
  "473_20": {
    "clientName": "HH Global",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "984_49": {
    "clientName": "FDM",
    "clientLogo": "https://images.prismic.io/ev-mercury/4b5b7a7a-68dc-4a8d-a625-722ab84b9bd8_0x0%5B49%5D.png?auto=compress,format"
  },
  "667_2": {
    "clientName": "Birmingham 2",
    "clientLogo": null
  },
  "921_24": {
    "clientName": "JDS Free Returns",
    "clientLogo": null
  },
  "492_2": {
    "clientName": "Lesara GmbH",
    "clientLogo": null
  },
  "84_0": {
    "clientName": "Boden",
    "clientLogo": "https://images.prismic.io/ev-mercury/4172ef69-b859-492b-a8f5-1d048fd1a55c_BODEN.png?auto=compress,format"
  },
  "2315_0": {
    "clientName": "Personalised Gifts",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/giftslogo.png"
  },
  "5703_0": {
    "clientName": "Exporto - TeVeo",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "737_3": {
    "clientName": "CMS 2",
    "clientLogo": null
  },
  "5062_4": {
    "clientName": "Matchstick Monkey Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/44a65919-39e5-4860-84ad-5b099174be18_MM_Logo_Evri-154x91pxs+%28002%29.jpg?auto=compress,format"
  },
  "894_85": {
    "clientName": "Cult Beauty",
    "clientLogo": "https://images.prismic.io/ev-mercury/8c311e3f-95e6-4b9c-91b2-5dd4e66cc41a_download+%28002%29.jfif?auto=compress,format"
  },
  "999_1": {
    "clientName": "Poundworld",
    "clientLogo": null
  },
  "652_160": {
    "clientName": "Baumhaus",
    "clientLogo": null
  },
  "5283_0": {
    "clientName": "Orveon",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "160_12": {
    "clientName": "NWN Media",
    "clientLogo": null
  },
  "2730_0": {
    "clientName": "J Rosenthal & Son",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4663_2": {
    "clientName": "SportsGB",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4114_0": {
    "clientName": "Bouquet Hampers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "188_105": {
    "clientName": "Fabletics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fabletics.png"
  },
  "894_50": {
    "clientName": "Myvegan",
    "clientLogo": "https://images.prismic.io/ev-mercury/11da6165-a10b-4f50-b732-ee635076f3fb_MyVegan+%28002%29.png?auto=compress,format"
  },
  "667_15": {
    "clientName": "Bradford 3",
    "clientLogo": null
  },
  "344_0": {
    "clientName": "Disney",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/disney.png"
  },
  "975_60": {
    "clientName": "Otrium Returns",
    "clientLogo": null
  },
  "381_0": {
    "clientName": "Lakeland Kitchenware",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "772_17": {
    "clientName": "Jo Malone",
    "clientLogo": null
  },
  "5618_3": {
    "clientName": "Heat Holders",
    "clientLogo": "https://images.prismic.io/ev-mercury/afd06c87-e2f7-46ed-a57a-64d457de7dc2_heat.png?auto=compress,format"
  },
  "897_0": {
    "clientName": "Cloud Fulfilment LTD",
    "clientLogo": null
  },
  "652_6": {
    "clientName": "Dams International",
    "clientLogo": null
  },
  "551_3": {
    "clientName": "Lovell Rugby",
    "clientLogo": null
  },
  "492_31": {
    "clientName": "John Lewis",
    "clientLogo": null
  },
  "253_7": {
    "clientName": "Lorna Jane",
    "clientLogo": null
  },
  "638_0": {
    "clientName": "Sekologistics London Ltd",
    "clientLogo": null
  },
  "2197_8": {
    "clientName": "Rowen and Wren ",
    "clientLogo": "https://images.prismic.io/ev-mercury/9c4d8643-695d-4ab3-9038-b8b0863bba5d_R%26W.PNG?auto=compress,format"
  },
  "748_6": {
    "clientName": "Idle Man",
    "clientLogo": null
  },
  "31_0": {
    "clientName": "Missguided",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/misguided.png"
  },
  "551_57": {
    "clientName": "Priorsend Ltd",
    "clientLogo": null
  },
  "551_15": {
    "clientName": "A5 Logistics Limited",
    "clientLogo": null
  },
  "652_107": {
    "clientName": "AroraDesign",
    "clientLogo": null
  },
  "2217_10": {
    "clientName": "The Hippie Shake",
    "clientLogo": "https://images.prismic.io/ev-mercury/783d5091-eb84-4696-853d-4ac71393b937_Asendia+22.11+144x144.jpg?auto=compress,format ythorproev"
  },
  "2217_6": {
    "clientName": "Worth A Million",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/000012wam.jpg"
  },
  "2390_1": {
    "clientName": "Poly Pads",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/polypads-logo.jpg"
  },
  "886_9": {
    "clientName": "Marks and Spencer",
    "clientLogo": null
  },
  "3_0": {
    "clientName": "Green Finger and Pet Planet",
    "clientLogo": null
  },
  "462_1": {
    "clientName": "D100 homework",
    "clientLogo": null
  },
  "2109_0": {
    "clientName": "Send Cloud",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sendcloud-logo.png"
  },
  "133_4": {
    "clientName": "Rustic Seating",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "771_0": {
    "clientName": "ARKET",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/arket.png"
  },
  "871_0": {
    "clientName": "Citysprint UK Limited",
    "clientLogo": null
  },
  "2749_16": {
    "clientName": "Metallbude",
    "clientLogo": "https://images.prismic.io/ev-mercury/619c5857-bf2b-4467-85f6-26e00ba6845c_1202320773970188.skEtpzZKivlJDIyzOkLU_height640.png?auto=compress,format"
  },
  "2217_9": {
    "clientName": "Chilly’s Trade in",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4194_0": {
    "clientName": "Keller Sports",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4109_0": {
    "clientName": "GXO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "921_19": {
    "clientName": "JD Sports - Finish Line",
    "clientLogo": null
  },
  "253_89": {
    "clientName": "Nooshie",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nooshie-black-square.jpg"
  },
  "81_0": {
    "clientName": "Amazon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon.png"
  },
  "782_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "2449_0": {
    "clientName": "Wilton Bradley",
    "clientLogo": null
  },
  "841_11": {
    "clientName": "Heine",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/heine_png.png"
  },
  "2749_9": {
    "clientName": "KORO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "485_0": {
    "clientName": "Motel Rocks ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/motelrockslogo.png"
  },
  "1942_5": {
    "clientName": "Nolii 9047",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "673_0": {
    "clientName": "Oliver Bonas",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oliver-bonas-logo.png"
  },
  "168_1": {
    "clientName": "M&S Personalised Schools",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/5a4fbefa9d52a21a6848ca3f.jpg"
  },
  "345_73": {
    "clientName": "Crew Clothing",
    "clientLogo": null
  },
  "3704_0": {
    "clientName": "Global Football ",
    "clientLogo": "https://images.prismic.io/ev-mercury/c6742b26-f7ae-43af-9bbb-7c18725ef8d4_global+football.png?auto=compress,format"
  },
  "4944_2": {
    "clientName": "Hera London",
    "clientLogo": "https://images.prismic.io/ev-mercury/70698e13-141a-4c6a-b129-90a46afb3fd3_Hera+Logo.png?auto=compress,format"
  },
  "2376_1": {
    "clientName": "UkFlowerGirlBoutique",
    "clientLogo": null
  },
  "667_47": {
    "clientName": "Stoke On Trent 3",
    "clientLogo": null
  },
  "975_1": {
    "clientName": "BMX X001",
    "clientLogo": null
  },
  "95_5": {
    "clientName": "Speed Track UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/0535ac0f-4843-4831-8ea2-4dfd8d7e109a_speed+track+6.12+resized.png?auto=compress,format"
  },
  "652_149": {
    "clientName": "Paladin Radiators",
    "clientLogo": null
  },
  "4472_0": {
    "clientName": "Ruggable 2",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2678_4": {
    "clientName": "Interdelta N",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26780004app.png"
  },
  "2770_29": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "2730_9": {
    "clientName": "Austin's",
    "clientLogo": "https://images.prismic.io/ev-mercury/07f1ae54-53d7-4440-beaf-38c4fb5e2043_austins.png?auto=compress,format"
  },
  "460_23": {
    "clientName": "Searchlight Electric Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "772_27": {
    "clientName": "Bumble & Bumble",
    "clientLogo": null
  },
  "4942_0": {
    "clientName": "Contempee ",
    "clientLogo": "https://images.prismic.io/ev-mercury/8ad4f5a8-00f4-44c9-a2b8-955e6de2cdd8_contempee-logo+%28003%29+resized.png?auto=compress,format"
  },
  "2134_0": {
    "clientName": "Dunelm",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/dunelm.png"
  },
  "3893_9": {
    "clientName": "Lyle & Scott",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "473_23": {
    "clientName": "House of Colour",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2620_2": {
    "clientName": "XBite",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26200002app.png"
  },
  "418_0": {
    "clientName": "Handlestore.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/handlestore.png"
  },
  "674_10": {
    "clientName": "Smart Buy Glasses",
    "clientLogo": null
  },
  "492_25": {
    "clientName": "Finery London",
    "clientLogo": null
  },
  "2768_0": {
    "clientName": "ghd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/27680000app.png"
  },
  "4631_0": {
    "clientName": "SilkFred",
    "clientLogo": "https://images.prismic.io/ev-mercury/92deb0fc-3340-49cd-b897-f16f14b1d6c0_silkfred.png?auto=compress,format"
  },
  "92_0": {
    "clientName": "Beer52",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beer52_144x144-new.png"
  },
  "287_142": {
    "clientName": "Nemesis",
    "clientLogo": "https://images.prismic.io/ev-mercury/4151e108-1958-4adf-bcc0-0deb40fe7b8e_NEW+MILNER+LOGO+resized.jpg?auto=compress,format"
  },
  "841_7": {
    "clientName": "Clearance 365",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/clearance.png"
  },
  "2543_0": {
    "clientName": "Yantra Fulfilment Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/6e97c9ab-fa8f-4292-adfa-ffc276be9c07_Yantra+logo+%28002%29.png?auto=compress,format"
  },
  "875_003": {
    "clientName": "Pixie Girls",
    "clientLogo": null
  },
  "287_7": {
    "clientName": "Landmark",
    "clientLogo": null
  },
  "2498_0": {
    "clientName": "ATR Wholesale",
    "clientLogo": null
  },
  "975_58": {
    "clientName": "DeFacto Returns",
    "clientLogo": null
  },
  "580_0": {
    "clientName": "Mango UK",
    "clientLogo": null
  },
  "3812_0": {
    "clientName": "Popgear Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/popgear-logo-cropped.png"
  },
  "4378_0": {
    "clientName": "Ekosport",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2428_2": {
    "clientName": "John Bell & Croyden",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/24280002app.png"
  },
  "5469_0": {
    "clientName": "Dennys Brands",
    "clientLogo": "https://images.prismic.io/ev-mercury/9cec1060-b65b-4520-91d0-bdc557dbce71_dennys+brand.png?auto=compress,format"
  },
  "142_22": {
    "clientName": "Abigail Ahern",
    "clientLogo": "https://images.prismic.io/ev-mercury/76d3ecef-f34f-41b5-b769-aeef2fc95828_abigail+ahern.png?auto=compress,format"
  },
  "160_9": {
    "clientName": "Matrix-Nutrition",
    "clientLogo": null
  },
  "5110_2": {
    "clientName": "Ginger Ray",
    "clientLogo": "https://images.prismic.io/ev-mercury/79790753-f980-43b0-a30d-7244f7db211d_GingerRay.png?auto=compress,format"
  },
  "551_36": {
    "clientName": "Rehab Fashion Limited",
    "clientLogo": null
  },
  "2298_0": {
    "clientName": "Deuba",
    "clientLogo": null
  },
  "39_29": {
    "clientName": "MANSCAPED",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/390029app.png"
  },
  "652_80": {
    "clientName": "BelfieldFurnishings",
    "clientLogo": null
  },
  "2395_0": {
    "clientName": "Refy Beauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/refy.png"
  },
  "4_0": {
    "clientName": "Noatum Logistics UK Limited",
    "clientLogo": null
  },
  "5206_0": {
    "clientName": "Recomme Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4730_0": {
    "clientName": "CSM Logistics Hertfordshire",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "667_21": {
    "clientName": "Croydon 1",
    "clientLogo": null
  },
  "541_0": {
    "clientName": "Cass Art",
    "clientLogo": null
  },
  "538_13": {
    "clientName": "Maneire De Voir Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2448_0": {
    "clientName": "STK Sticker Craft",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/stk-stickers-and-crafts-144x144.jpg"
  },
  "361_0": {
    "clientName": "Wiggle",
    "clientLogo": "https://images.prismic.io/ev-mercury/3003ae4e-c825-4598-b128-2428767b2498_DF+Circle+%28002%29+wiggle.png?auto=compress,format"
  },
  "1484_1": {
    "clientName": "Who Gives a Crap",
    "clientLogo": null
  },
  "2587_0": {
    "clientName": "ChoiceShops Logistics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "742_0": {
    "clientName": "ASOS",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "921_14": {
    "clientName": "JD Sports - Brown Bag",
    "clientLogo": null
  },
  "492_17": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos.png"
  },
  "667_36": {
    "clientName": "Huddersfield 4",
    "clientLogo": null
  },
  "659_3": {
    "clientName": "Click Spares",
    "clientLogo": "https://images.prismic.io/ev-mercury/c7a80106-05fa-49ac-9be3-1083e0385d92_click+logo.png?auto=compress,format"
  },
  "362_1": {
    "clientName": "Lands End",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lands-end.png"
  },
  "262_1": {
    "clientName": "Achica",
    "clientLogo": null
  },
  "652_130": {
    "clientName": "Glitz Home",
    "clientLogo": null
  },
  "4040_0": {
    "clientName": "PetShopcouk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2032_0": {
    "clientName": "Flatworld Commerce Limited",
    "clientLogo": null
  },
  "539_0": {
    "clientName": "Oh Polly",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oh-polly-logo.png"
  },
  "492_21": {
    "clientName": "Damart",
    "clientLogo": null
  },
  "551_54": {
    "clientName": "BSMW Limited",
    "clientLogo": null
  },
  "160_18": {
    "clientName": "The Sun Reader Orders",
    "clientLogo": null
  },
  "900_1": {
    "clientName": "River Island",
    "clientLogo": null
  },
  "443_0": {
    "clientName": "2tech Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2tech-logo.png"
  },
  "968_0": {
    "clientName": "ISHOP247 Ltd",
    "clientLogo": null
  },
  "4_6": {
    "clientName": "Simon Jersey",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/simon-jersey.png"
  },
  "492_49": {
    "clientName": "Miss Selfridge",
    "clientLogo": null
  },
  "483_1": {
    "clientName": "PopYum Foods",
    "clientLogo": "https://images.prismic.io/ev-mercury/4eaf1559-2554-4219-bbd6-d501d838c9d5_popyum.png?auto=compress,format"
  },
  "652_52": {
    "clientName": "Stewart Superior",
    "clientLogo": null
  },
  "109_1": {
    "clientName": "Morphe",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/morphe.png"
  },
  "2770_5": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "2783_0": {
    "clientName": "Pest Control Supermarket.com Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "984_52": {
    "clientName": "RUGSCH",
    "clientLogo": "https://images.prismic.io/ev-mercury/07eacf86-9f83-49f5-b558-4f6d886811f4_rugsh.png?auto=compress,format"
  },
  "631_92": {
    "clientName": "The Simple Folk",
    "clientLogo": "https://images.prismic.io/ev-mercury/13f55119-2083-4157-b721-8e2e14b04e3b_simple+folk+circle+logo.png?auto=compress,format"
  },
  "4529_1": {
    "clientName": "BOA - Because of Alice",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "471_1": {
    "clientName": "Lounge by Zalando",
    "clientLogo": "https://images.prismic.io/ev-mercury/c605c45a-b6cb-4ff1-ad92-1b82ffba374f_lounge+by+zalando+resized.png?auto=compress,format://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "253_16": {
    "clientName": "10store.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/10store.png"
  },
  "785_18": {
    "clientName": "Best Direct Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5341_0": {
    "clientName": "Passport Global Inc",
    "clientLogo": "https://images.prismic.io/ev-mercury/78ad7091-e155-4b6a-b197-b60103424b3f_passport.png?auto=compress,format"
  },
  "2947_0": {
    "clientName": "Lululemon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lulemon-yogo-type-rgb-1-.png"
  },
  "2392_0": {
    "clientName": "Direct Cosmetics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/direct-cosmetics-logo.jpg"
  },
  "862_0": {
    "clientName": "AMOS",
    "clientLogo": null
  },
  "253_36": {
    "clientName": "Spoke",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/spoke.png"
  },
  "4694_3": {
    "clientName": "Regis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/46940003app.png"
  },
  "662_9": {
    "clientName": "Click Spares",
    "clientLogo": "https://images.prismic.io/ev-mercury/c7a80106-05fa-49ac-9be3-1083e0385d92_click+logo.png?auto=compress,format"
  },
  "2749_35": {
    "clientName": "Gorilla Sports",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "492_18": {
    "clientName": "I Want Fabric",
    "clientLogo": null
  },
  "5541_0": {
    "clientName": "KBX Tradex Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/482e4146-81ac-492c-9606-9af575bca911_kbtradex.png?auto=compress,format"
  },
  "2613_0": {
    "clientName": "DeFacto Retail UK",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26130000app.png"
  },
  "492_38": {
    "clientName": "Sportsshoes",
    "clientLogo": null
  },
  "2338_0": {
    "clientName": "Lighting & Mobile Accs Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lighting-mobile-acc-logo.jpg"
  },
  "832_0": {
    "clientName": "Cadenzza",
    "clientLogo": null
  },
  "473_9": {
    "clientName": "3M KCI",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "631_104": {
    "clientName": "Road Rat",
    "clientLogo": "https://images.prismic.io/ev-mercury/d3bd1484-195a-48fe-9ea1-db1719ce59b9_road+rat+logo.png?auto=compress,format"
  },
  "336_0": {
    "clientName": "Predator Nutrition",
    "clientLogo": null
  },
  "914_19": {
    "clientName": "Wheelcare Trading",
    "clientLogo": null
  },
  "2526_6": {
    "clientName": "CPM",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25260006app.png"
  },
  "4945_0": {
    "clientName": "Power Body Nutrition Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/2c0ae9d3-b950-4e53-814d-fbf142f2e6e9_DF+Circle+power+body.png?auto=compress,format"
  },
  "734_0": {
    "clientName": "Couture Club",
    "clientLogo": null
  },
  "991_1": {
    "clientName": "Mood Living",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mood-logo.png"
  },
  "458_0": {
    "clientName": "Parcelink",
    "clientLogo": null
  },
  "921_23": {
    "clientName": "GO Outdoors",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/go-outdoors-logonew.png"
  },
  "854_2": {
    "clientName": "OWExpress",
    "clientLogo": null
  },
  "914_25": {
    "clientName": "Ipswich Town FC",
    "clientLogo": null
  },
  "253_34": {
    "clientName": "Jottnar",
    "clientLogo": null
  },
  "2578_0": {
    "clientName": "Oakland International Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/oak2-1-.png"
  },
  "797_0": {
    "clientName": "AMARA",
    "clientLogo": null
  },
  "253_2": {
    "clientName": "Yumi Brands",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/yumi.png"
  },
  "2624_0": {
    "clientName": "Castle Hardware",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26240000app.png"
  },
  "665_0": {
    "clientName": "Arcadia Group Ltd",
    "clientLogo": null
  },
  "551_51": {
    "clientName": "Clearwater Hampers Limited",
    "clientLogo": null
  },
  "2592_0": {
    "clientName": "M Life",
    "clientLogo": null
  },
  "663_1": {
    "clientName": "NextdayLenses",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nextdaylens144x144.jpg"
  },
  "1955_0": {
    "clientName": "Ponden Home",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/pondenhome-logo.png"
  },
  "253_4": {
    "clientName": "Torque Omni Channel Limited",
    "clientLogo": null
  },
  "3813_0": {
    "clientName": "The Little Loop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "729_0": {
    "clientName": "Debenhams@ebay",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "667_5": {
    "clientName": "Bolton 1",
    "clientLogo": null
  },
  "914_22": {
    "clientName": "Aromatherapy Associates",
    "clientLogo": null
  },
  "2_0": {
    "clientName": "eBay",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ebay.png"
  },
  "3910_0": {
    "clientName": "PB Fulfilment ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "974_0": {
    "clientName": "TM Lewin ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tmlewin_new.png"
  },
  "667_12": {
    "clientName": "Bournemouth 4",
    "clientLogo": null
  },
  "652_84": {
    "clientName": "Best Water Technology",
    "clientLogo": null
  },
  "103_0": {
    "clientName": "Next",
    "clientLogo": "https://images.prismic.io/ev-mercury/a1f47abc-1d15-4daf-b06e-035564d9add1_next-logo.jpeg?auto=compress,format"
  },
  "150_0": {
    "clientName": "Medic Animal",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1500000app.png"
  },
  "171_1": {
    "clientName": "In The Style Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1710000.png"
  },
  "1056_9": {
    "clientName": "Landmark US A",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "358_0": {
    "clientName": "FTS UK Ltd",
    "clientLogo": null
  },
  "701_0": {
    "clientName": "MandM",
    "clientLogo": "https://images.prismic.io/ev-mercury/244391b5-95f9-4ab7-bc47-0fc094e5d45a_MandM.png?auto=compress,format"
  },
  "5317_6": {
    "clientName": "Evri",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "762_4": {
    "clientName": "Ideal World",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/iw-logo.png"
  },
  "786_2": {
    "clientName": "Superdrug",
    "clientLogo": null
  },
  "333_7": {
    "clientName": "UK Bargains 4U Ltd",
    "clientLogo": null
  },
  "160_23": {
    "clientName": "Test",
    "clientLogo": null
  },
  "4029_1": {
    "clientName": "eliquid.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40290001app.png"
  },
  "652_120": {
    "clientName": "Plow Hearth",
    "clientLogo": null
  },
  "5350_0": {
    "clientName": "JFCK1",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4514_2": {
    "clientName": "Terry’s Fabric",
    "clientLogo": ""
  },
  "3647_0": {
    "clientName": "Face Theory",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_166": {
    "clientName": "The Art Group Pyramid Intern",
    "clientLogo": null
  },
  "3409_0": {
    "clientName": "Hawthorn Distribution LTD ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5091_0": {
    "clientName": "Big Clothing 4 U",
    "clientLogo": "https://images.prismic.io/ev-mercury/d971fad4-fd9c-4f77-afd4-32ed786bff7e_BC4U+resized+4.jpg?auto=compress,format"
  },
  "2770_26": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "652_48": {
    "clientName": "Sky Business Park",
    "clientLogo": null
  },
  "4332_0": {
    "clientName": "Westbound Logistics Services Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "975_3": {
    "clientName": "TOM03",
    "clientLogo": null
  },
  "631_107": {
    "clientName": "Arrowtown",
    "clientLogo": "https://images.prismic.io/ev-mercury/ea305a46-8558-4fa2-b21c-ce60b28c2ef8_ARROW+TOWN.png?auto=compress,format"
  },
  "2555_0": {
    "clientName": "AGKM Trading Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25550000app.png"
  },
  "3857_0": {
    "clientName": "Rollersnakes",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "406_0": {
    "clientName": "Custom Gateway",
    "clientLogo": null
  },
  "826_9": {
    "clientName": "Bon Prix",
    "clientLogo": null
  },
  "632_0": {
    "clientName": "Tooltime",
    "clientLogo": null
  },
  "40_18": {
    "clientName": "Splesh",
    "clientLogo": "https://images.prismic.io/ev-mercury/cfd2ea73-8f98-4b00-8649-ada1f4bcf0a0_splesh+circle+logo.png?auto=compress,format"
  },
  "886_4": {
    "clientName": "Asda",
    "clientLogo": null
  },
  "50_38": {
    "clientName": "ITD Carousel Car Parts",
    "clientLogo": "https://images.prismic.io/ev-mercury/83729f14-77aa-44bc-9c1a-cf7a99eabeff_ITD+Carousel+Car+Parts+Logo+%28002%29.png?auto=compress,format"
  },
  "577_0": {
    "clientName": "z&u Online",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fusion.png"
  },
  "652_159": {
    "clientName": "Maxim Lighting",
    "clientLogo": null
  },
  "2242_2": {
    "clientName": "ECCO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ecco-logo-144x144.jpg"
  },
  "5317_2": {
    "clientName": "CIATE London",
    "clientLogo": "https://images.prismic.io/ev-mercury/fc01c594-4ed3-4b12-b81e-53d9c3ccfe8e_ciate+london+cirlce.png?auto=compress,format"
  },
  "665_7": {
    "clientName": "Topshop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/topshop.png"
  },
  "549_0": {
    "clientName": "Ginger Ray Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/79790753-f980-43b0-a30d-7244f7db211d_GingerRay.png?auto=compress,format"
  },
  "2770_13": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "550_12": {
    "clientName": "UK Flooring Direct Ltd",
    "clientLogo": null
  },
  "160_15": {
    "clientName": "Samuel Windsor",
    "clientLogo": null
  },
  "2219_1": {
    "clientName": "Anker Innovations",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/anker_144x144.jpg"
  },
  "5072_0": {
    "clientName": "PrimeTools",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "772_0": {
    "clientName": "Estee Lauder",
    "clientLogo": null
  },
  "653_5": {
    "clientName": "Superfood UK",
    "clientLogo": null
  },
  "999_8": {
    "clientName": "Lovebug",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lovebug-master-logo-dark-01.png"
  },
  "811_16": {
    "clientName": "Charlotte Tilbury",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/charlottetilbury.png"
  },
  "551_52": {
    "clientName": "The Baby Shower Company",
    "clientLogo": null
  },
  "772_11": {
    "clientName": "Bobbi Brown",
    "clientLogo": null
  },
  "4028_0": {
    "clientName": "GLS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "596_0": {
    "clientName": "Express Gifts Chadderton",
    "clientLogo": null
  },
  "2623_0": {
    "clientName": "Gym + Coffee",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26230000app.png"
  },
  "921_0": {
    "clientName": "JD Sports",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-sports.png"
  },
  "543_1": {
    "clientName": "Photobox",
    "clientLogo": null
  },
  "551_41": {
    "clientName": "Brigade Clothing",
    "clientLogo": null
  },
  "472_0": {
    "clientName": "Zalando",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/zalando.png"
  },
  "287_115": {
    "clientName": "Hampers.com",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "665_1": {
    "clientName": "Burton",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/burton.png"
  },
  "408_5": {
    "clientName": "Canterbury",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/canterbury.png"
  },
  "253_87": {
    "clientName": "Bytomic",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2530087app.png"
  },
  "31_2": {
    "clientName": "Mennace",
    "clientLogo": null
  },
  "947_1": {
    "clientName": "Mango",
    "clientLogo": null
  },
  "921_2": {
    "clientName": "Size",
    "clientLogo": null
  },
  "5067_7": {
    "clientName": "Vapouriz",
    "clientLogo": "https://images.prismic.io/ev-mercury/7eb67740-a305-43ab-828f-188755095c3a_Vapouriz-100.jpg?auto=compress,format"
  },
  "5570_2": {
    "clientName": "RandF UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/8d3f7e00-fce7-43c2-8313-279b67485b1a_fineway.png?auto=compress,format"
  },
  "2141_0": {
    "clientName": "Kayfast Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kayfast-logo.png"
  },
  "5564_0": {
    "clientName": "Pomchick Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/3efff1dd-128c-48c0-92cb-f7175ca4cd77_POMCHICK.png?auto=compress,format"
  },
  "4944_1": {
    "clientName": "Nadine Merabi Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/7f177db0-e543-474e-a356-1a0e34bc1d19_nadinenew.png?auto=compress,format"
  },
  "4944_3": {
    "clientName": "Never Fully Dressed ",
    "clientLogo": "https://images.prismic.io/ev-mercury/2d9aba05-9906-44c0-9c5e-9c93262a2772_never+fully+dressed.png?auto=compress,format"
  },
  "652_18": {
    "clientName": "Atrium Ltd",
    "clientLogo": null
  },
  "5546_1": {
    "clientName": "ITV Shop",
    "clientLogo": "https://images.prismic.io/ev-mercury/cbfb9cd9-d443-4709-be40-c9b0421d21b7_itv.png?auto=compress,format"
  },
  "5592_0": {
    "clientName": "Happy Sport Ltd ",
    "clientLogo": "https://images.prismic.io/ev-mercury/15956575-adb2-4ab8-ad92-40127e394615_happy.png?auto=compress,format"
  },
  "875_0": {
    "clientName": "YoursClothing",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/emails/logos/8750000.png"
  },
  "620_38": {
    "clientName": "Tower",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6200038app.png"
  },
  "2749_27": {
    "clientName": "Doonails",
    "clientLogo": "https://images.prismic.io/ev-mercury/b9de8a81-03aa-48fd-be2f-2635d6e3e0f1_doonails.png?auto=compress,format"
  },
  "4694_2": {
    "clientName": "Aldo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/46940002app.png"
  },
  "492_37": {
    "clientName": "Scotts DD",
    "clientLogo": null
  },
  "2390_2": {
    "clientName": "Premier Products",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/premierproducts-logo.jpg"
  },
  "2217_0": {
    "clientName": "Asendia",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5067_3": {
    "clientName": "Total Vapour ",
    "clientLogo": "https://images.prismic.io/ev-mercury/0ec9c60a-0e18-4318-a9a7-feffdacdb308_Total+Vapour-100.jpg?auto=compress,format"
  },
  "541_1": {
    "clientName": "Harper Collins",
    "clientLogo": null
  },
  "2431_5": {
    "clientName": "Beauty Cloud",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beauty-cloud-logo.png"
  },
  "50_10": {
    "clientName": "Simon Jersey",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/simon-jersey.png"
  },
  "383_0": {
    "clientName": "Oceanside Logistics",
    "clientLogo": null
  },
  "5437_0": {
    "clientName": "TEMU (Impex)",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2215_6": {
    "clientName": "RASCAL",
    "clientLogo": "https://images.prismic.io/ev-mercury/e577aa33-3c08-4861-98cf-4b463cc4ee91_DF+Circle+rascal+logo.png?auto=compress,format"
  },
  "1813_0": {
    "clientName": "Sprint Logistics Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sprint-logistics-logo-144x144.png"
  },
  "4305_0": {
    "clientName": "Zabou",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "667_22": {
    "clientName": "Croydon 2",
    "clientLogo": null
  },
  "652_29": {
    "clientName": "OBaby",
    "clientLogo": null
  },
  "5317_0": {
    "clientName": "Synergy Retail Support",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "855_0": {
    "clientName": "Bestseller UK",
    "clientLogo": null
  },
  "4409_0": {
    "clientName": "Shipmonk",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2541_0": {
    "clientName": "My 1st Years",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25410000appv2.png"
  },
  "831_0": {
    "clientName": "Huxloe Logistics Kettering",
    "clientLogo": null
  },
  "77_1": {
    "clientName": "Thane",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/thane-logo.png"
  },
  "667_8": {
    "clientName": "Bolton 4",
    "clientLogo": null
  },
  "2769_0": {
    "clientName": "Ruggable",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_47": {
    "clientName": "Millhouse Manufacturing Design",
    "clientLogo": null
  },
  "551_24": {
    "clientName": "We Can Source It Ltd",
    "clientLogo": null
  },
  "1643_0": {
    "clientName": "Tobias & The Bear",
    "clientLogo": null
  },
  "1958_4": {
    "clientName": "Tigers Global Thurrock TeeZed",
    "clientLogo": null
  },
  "521_0": {
    "clientName": "Merc Clothing",
    "clientLogo": null
  },
  "3611_0": {
    "clientName": "BraStop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "772_35": {
    "clientName": "Glamglow",
    "clientLogo": null
  },
  "1056_7": {
    "clientName": "BPack Belgium",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_113": {
    "clientName": "ShireSheds",
    "clientLogo": null
  },
  "335_0": {
    "clientName": "Peacocks",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/peacocks.png"
  },
  "914_9": {
    "clientName": "Shundaguoji Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/clearance.png"
  },
  "781_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "5354_0": {
    "clientName": "DFYNE",
    "clientLogo": "https://images.prismic.io/ev-mercury/8d107616-d190-48d5-abd7-39d33105e647_DFYNE.png?auto=compress,format"
  },
  "2218_0": {
    "clientName": "Fishing Republic",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fishingrepublic-logo.png"
  },
  "622_0": {
    "clientName": "Gap International Returns",
    "clientLogo": null
  },
  "631_114": {
    "clientName": "The Drip",
    "clientLogo": "https://images.prismic.io/ev-mercury/55e05272-140d-404e-98f8-f9a08fe67c68_THE+DRIP.png?auto=compress,format"
  },
  "702_0": {
    "clientName": "Hortic Express Ltd",
    "clientLogo": null
  },
  "667_56": {
    "clientName": "Watford 4",
    "clientLogo": null
  },
  "2656_0": {
    "clientName": "LH Trading",
    "clientLogo": null
  },
  "314_0": {
    "clientName": "Evri",
    "clientLogo": null
  },
  "2756_0": {
    "clientName": "Borderless360",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "2443_1": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "151_65": {
    "clientName": "GET THE LABEL",
    "clientLogo": "https://images.prismic.io/ev-mercury/327f01fb-9f33-4c29-be27-eda3d6deaca6_get+the+label+circle.png?auto=compress,format"
  },
  "4635_0": {
    "clientName": "304 Clothing",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/46350000app.png"
  },
  "397_0": {
    "clientName": "Mountain Warehouse",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mountainwarehouselogo.png"
  },
  "2770_27": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "492_5": {
    "clientName": "Feelunique",
    "clientLogo": null
  },
  "1056_1": {
    "clientName": "Landmark UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "543_2": {
    "clientName": "Photobox",
    "clientLogo": null
  },
  "895_0": {
    "clientName": "NutMeg",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/nutmeg-logo-new.png"
  },
  "844_1": {
    "clientName": "Free People",
    "clientLogo": null
  },
  "3391_5": {
    "clientName": "Swan",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "133_1": {
    "clientName": "JMart",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "1061_0": {
    "clientName": "Footlocker",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/footlocker.png"
  },
  "96_0": {
    "clientName": "Tu Clothing",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tu.png"
  },
  "1004_7": {
    "clientName": "KWT-insured",
    "clientLogo": null
  },
  "151_0": {
    "clientName": "Sports Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/1510000app.png"
  },
  "551_37": {
    "clientName": "H Young (Ops) Ltd T/A Madison",
    "clientLogo": null
  },
  "652_78": {
    "clientName": "Vic Smith Beds",
    "clientLogo": null
  },
  "628_0": {
    "clientName": "JD Williams",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "2391_0": {
    "clientName": "The Turmeric Co",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-turmeric-co-master-144x144.jpg"
  },
  "4350_0": {
    "clientName": "Kikiyo",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/studio-hop-logo-2.png"
  },
  "5317_8": {
    "clientName": "Skinny Tan",
    "clientLogo": "https://images.prismic.io/ev-mercury/1f37376c-c5a0-4702-a776-765cdf2f6144_skinny+tan+logo.png?auto=compress,format"
  },
  "5614_0": {
    "clientName": "GiftUniverse",
    "clientLogo": "https://images.prismic.io/ev-mercury/409fe546-dc3a-48d0-96a7-b0a22d797a35_giftuniverse+logo.png?auto=compress,format"
  },
  "443_1": {
    "clientName": "Faulty Returns Link",
    "clientLogo": null
  },
  "823_0": {
    "clientName": "Superdrug",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/superdrug.png"
  },
  "149_6": {
    "clientName": "Vitaid",
    "clientLogo": null
  },
  "4369_0": {
    "clientName": "Innox Trading Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5067_2": {
    "clientName": "Premier Vaping ",
    "clientLogo": "https://images.prismic.io/ev-mercury/ba9998b2-ba45-44b7-8d45-3f701537d34f_Premier+Retail-100.jpg?auto=compress,format"
  },
  "461_0": {
    "clientName": "Redcats NCC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "652_88": {
    "clientName": "Vitavia",
    "clientLogo": null
  },
  "267_0": {
    "clientName": "Mountain Warehouse",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2670000app.png"
  },
  "617_0": {
    "clientName": "Bloc Blinds",
    "clientLogo": null
  },
  "5674_0": {
    "clientName": "Ocean Bottle",
    "clientLogo": "https://images.prismic.io/ev-mercury/5279c583-5c33-4634-91ea-b30fd1ef5d80_laserite+logo.png?auto=compress,format"
  },
  "924_0": {
    "clientName": "Who Gives A Crap",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/whogivesacrap.png"
  },
  "2431_3": {
    "clientName": "Salon Wholesale",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/salon-wholesale-logo.jpg"
  },
  "287_2": {
    "clientName": "Eve Sleep Plc",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/eve.png"
  },
  "3636_3": {
    "clientName": "Lee Cooper Workwear",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "333_1": {
    "clientName": "Nucleus",
    "clientLogo": null
  },
  "4739_0": {
    "clientName": "Llama Leisure",
    "clientLogo": "https://images.prismic.io/ev-mercury/59ffe8f0-7d23-4a76-9d78-2b67c7f913c6_logo-circle-fb+%28004%29.png?auto=compress,format"
  },
  "4028_18": {
    "clientName": "SWAROVSKI",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280018app.png"
  },
  "4264_2": {
    "clientName": "P-J Crossboard",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4428_3": {
    "clientName": "Truly",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/44280003.png"
  },
  "605_27": {
    "clientName": "Christy",
    "clientLogo": null
  },
  "2699_15": {
    "clientName": "Zelus Sports",
    "clientLogo": "https://images.prismic.io/ev-mercury/dd1367f8-9185-4806-b2cf-4e0034312d65_ZELUSSPORTS.png?auto=compress,format"
  },
  "674_14": {
    "clientName": "Courtesy Shoes",
    "clientLogo": null
  },
  "378_0": {
    "clientName": "Direct 2 Publik",
    "clientLogo": null
  },
  "600_0": {
    "clientName": "wilko",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wilko.png"
  },
  "5062_7": {
    "clientName": "Constable Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/168178d6-415d-422d-b732-86e7c4afb126_Pottiagogo_Logo_Evri_144x144pxs+%28002%29.jpg?auto=compress,format"
  },
  "992_1": {
    "clientName": "Revolve",
    "clientLogo": null
  },
  "438_0": {
    "clientName": "London Loves Beauty",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/llb.png"
  },
  "748_3": {
    "clientName": "Finlux",
    "clientLogo": null
  },
  "667_43": {
    "clientName": "Plymouth 3",
    "clientLogo": null
  },
  "947_2": {
    "clientName": "Pepe Jeans Zalando",
    "clientLogo": null
  },
  "2749_23": {
    "clientName": "Rucksack.de",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "551_31": {
    "clientName": "Bodybuilding.com",
    "clientLogo": null
  },
  "4028_22": {
    "clientName": "TRIXIE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/40280022app.png"
  },
  "551_21": {
    "clientName": "First Class Post 121 Ltd",
    "clientLogo": null
  },
  "29_1": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "937_0": {
    "clientName": "Online Home Shop",
    "clientLogo": "https://images.prismic.io/ev-mercury/22c0a091-5589-41f2-a8f0-a4942611990e_OHS+Logo+%28002%29+RESIZED.png?auto=compress,format"
  },
  "652_148": {
    "clientName": "Jonathan Y",
    "clientLogo": null
  },
  "4892_0": {
    "clientName": "OMNES",
    "clientLogo": "https://images.prismic.io/ev-mercury/65a3fcc2-b412-45ed-a07b-0cae07f676f2_omnes+logo.png?auto=compress,format"
  },
  "848_0": {
    "clientName": "7S Multi-shop",
    "clientLogo": null
  },
  "975_83": {
    "clientName": "Boxraw",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "667_39": {
    "clientName": "Leeds 3",
    "clientLogo": null
  },
  "4713_0": {
    "clientName": "iHunter",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/47130000.png"
  },
  "5538_0": {
    "clientName": "Fodabox Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "5191_0": {
    "clientName": "RX LIVE",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "504_0": {
    "clientName": "The Entertainer",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-entertainer.png"
  },
  "133_6": {
    "clientName": "KD and Jay 50",
    "clientLogo": "https://images.prismic.io/ev-mercury/ff30968a-d7ed-4373-aceb-2e53841da8f9_jmart.png?auto=compress,format"
  },
  "3416_0": {
    "clientName": "Mi Hub Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "962_0": {
    "clientName": "Box",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/box.png"
  },
  "825_3": {
    "clientName": "Kaleidoscope",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kaleidoscopelogonewmarch21.png"
  },
  "492_16": {
    "clientName": "Boden",
    "clientLogo": null
  },
  "4556_0": {
    "clientName": "GLTC",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "628_3": {
    "clientName": "FASHION WORLD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/fashionworld.png"
  },
  "287_9": {
    "clientName": "Squizzas!",
    "clientLogo": null
  },
  "4090_0": {
    "clientName": "STYLEQUE LIMITED",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/001-ev0021-logo-resizing-for-print-in-store-devices_-web-and-app-mbn-footwear-144x144-2-.jpg"
  },
  "274_0": {
    "clientName": "E G Trading",
    "clientLogo": null
  },
  "412_3": {
    "clientName": "Massimodutti",
    "clientLogo": null
  },
  "3138_0": {
    "clientName": "12return BV",
    "clientLogo": null
  },
  "33_0": {
    "clientName": "Select",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/330000app.png"
  },
  "492_7": {
    "clientName": "Hotter Shoes",
    "clientLogo": null
  },
  "742_3": {
    "clientName": "ASOS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/asos1.png"
  },
  "2749_34": {
    "clientName": "Maxstore",
    "clientLogo": "https://images.prismic.io/ev-mercury/a5491211-8168-4545-8c46-abebc5a7bbbe_MAX+STORE.png?auto=compress,format"
  },
  "733_0": {
    "clientName": "DSV Solutions",
    "clientLogo": null
  },
  "4501_0": {
    "clientName": "The Range",
    "clientLogo": "https://images.prismic.io/ev-mercury/108580dd-d26b-4be3-bfad-ddabbe671a64_the+range+logo.png?auto=compress,format"
  },
  "827_3": {
    "clientName": "Vince Camuto",
    "clientLogo": null
  },
  "958_0": {
    "clientName": "The Fragrance Shop",
    "clientLogo": null
  },
  "2744_0": {
    "clientName": "DOLLHOUSE FASHIONS LTD ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3612_0": {
    "clientName": "Curvy Kate",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_62": {
    "clientName": "Sofa Source",
    "clientLogo": null
  },
  "737_4": {
    "clientName": "CMS 3",
    "clientLogo": null
  },
  "345_105": {
    "clientName": "BookTrust",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3450105app.png"
  },
  "835_0": {
    "clientName": "Wayfair 2",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/wayfair.png"
  },
  "551_20": {
    "clientName": "C & C Edmonds",
    "clientLogo": null
  },
  "667_34": {
    "clientName": "Huddersfield 2",
    "clientLogo": null
  },
  "3037_0": {
    "clientName": "Zooplus",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/30370000app.png"
  },
  "979_0": {
    "clientName": "Rhenus Logistics Limited",
    "clientLogo": null
  },
  "312_0": {
    "clientName": "Footasylum",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/footasylum.png"
  },
  "667_63": {
    "clientName": "East London 5",
    "clientLogo": null
  },
  "2523_0": {
    "clientName": "Joseph Joseph",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/25230000app.png"
  },
  "826_4": {
    "clientName": "Look Again",
    "clientLogo": null
  },
  "289_3": {
    "clientName": "Venture Paragon LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/ebe21886-c15e-40f6-8b02-5df403007747_venture+logo.png?auto=compress,format"
  },
  "2489_0": {
    "clientName": "Mainfreight UK Ltd",
    "clientLogo": null
  },
  "2343_0": {
    "clientName": "Elite Pro Sports Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/elite-pro-sports-logo.jpg"
  },
  "303_14": {
    "clientName": "Kitchener Flooring",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/3030014app.png"
  },
  "2691_0": {
    "clientName": "Meta logistics",
    "clientLogo": null
  },
  "829_10": {
    "clientName": "Walker Logistics",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8290010app.png"
  },
  "652_33": {
    "clientName": "Mid North Ltd",
    "clientLogo": null
  },
  "4550_0": {
    "clientName": "Impex",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "507_3": {
    "clientName": "Benefit",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/benefit.png"
  },
  "2753_0": {
    "clientName": "Triumph UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2443_5": {
    "clientName": "Terrys Fabrics ",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2249_0": {
    "clientName": "Greyhaze",
    "clientLogo": "https://images.prismic.io/ev-mercury/36cab95c-8e84-4f4e-bcad-ba5f943ac821_grey+haze+logo+13.12+144x144.+3.png?auto=compress,format"
  },
  "5618_0": {
    "clientName": "David James",
    "clientLogo": "https://images.prismic.io/ev-mercury/708fa565-62bd-40ab-b513-fed2467a13f3_david+james.png?auto=compress,format"
  },
  "40_10": {
    "clientName": "Kit & Kin",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kit-and-kin.png"
  },
  "2782_0": {
    "clientName": "LULLABELLZ LTD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lullabelz-logo_144-black-1-.png"
  },
  "2329_1": {
    "clientName": "Living Nature",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/living-nature-logo.jpg"
  },
  "2749_32": {
    "clientName": "Pegador",
    "clientLogo": "https://images.prismic.io/ev-mercury/1de1f3d7-b587-4f40-8a0f-8bd39d45dc09_pegador.png?auto=compress,format"
  },
  "253_65": {
    "clientName": "Mistral",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mistral-logo.png"
  },
  "5132_0": {
    "clientName": "Menwell Ltd (Operations)",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "614_1": {
    "clientName": "Boohoo",
    "clientLogo": null
  },
  "58_0": {
    "clientName": "GFS Drop Off",
    "clientLogo": null
  },
  "667_18": {
    "clientName": "Bristol 2",
    "clientLogo": null
  },
  "3730_0": {
    "clientName": "Fairfax & Favour",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "982_0": {
    "clientName": "Big Red Group",
    "clientLogo": null
  },
  "4264_1": {
    "clientName": "P-J Local2",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_77": {
    "clientName": "EmpireShedsLtd",
    "clientLogo": null
  },
  "2749_15": {
    "clientName": "Wera Toolrebels",
    "clientLogo": "https://images.prismic.io/ev-mercury/01e6f004-56c3-4451-a745-12b5e5343830_1202258750273824.jhODXZEmuyaGcG5l97PC_height640.png?auto=compress,format"
  },
  "652_127": {
    "clientName": "Kenroy Home",
    "clientLogo": null
  },
  "975_100": {
    "clientName": "Gym+Coffee UK",
    "clientLogo": "https://images.prismic.io/ev-mercury/a290b318-e338-4d4a-b365-26979cab4ccb_Gym__Coffee_Logo_for_PPTX_200x100+%28002%29+resized.jpg?auto=compress,format"
  },
  "2749_8": {
    "clientName": "Mr Beam",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "928_0": {
    "clientName": "Charles Tyrwhitt",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/charles-tyrwhitt.png"
  },
  "2620_1": {
    "clientName": "XBite",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/26200001app.png"
  },
  "647_1": {
    "clientName": "Wrap London",
    "clientLogo": null
  },
  "628_12": {
    "clientName": "NATURALLY CLOSE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "311_1": {
    "clientName": "online golf",
    "clientLogo": "https://images.prismic.io/ev-mercury/c3434f59-256e-40a1-9992-c3b88e863a33_og-144px+%28002%29.png?auto=compress,format"
  },
  "652_90": {
    "clientName": "T&ATextilesandHosieryLtd",
    "clientLogo": null
  },
  "652_57": {
    "clientName": "ISM",
    "clientLogo": null
  },
  "4897_0": {
    "clientName": "Londonlovesbeauty.com",
    "clientLogo": "https://images.prismic.io/ev-mercury/20812b76-2e61-4fd6-a125-2d78610d45ea_Logo+for+London+Loves+Beauty+144x144.jpg?auto=compress,format"
  },
  "2699_13": {
    "clientName": "Andrew Hyde",
    "clientLogo": "https://images.prismic.io/ev-mercury/0c4e1d5e-4838-4509-a176-894f60f1f6ed_ANDREWHYDE.png?auto=compress,format"
  },
  "631_97": {
    "clientName": "Prime Time",
    "clientLogo": "https://images.prismic.io/ev-mercury/b0e2301f-45e9-4e24-9d9e-ba3d6e219e49_Prime+Time+LOGO+%28002%29.png?auto=compress,format"
  },
  "3386_0": {
    "clientName": "Tower Boots London Ltd (OCS)",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_132": {
    "clientName": "Imperial Bathrooms",
    "clientLogo": null
  },
  "1_1": {
    "clientName": "Slick Stitch",
    "clientLogo": null
  },
  "227_0": {
    "clientName": "Chums",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/chums.png"
  },
  "2618_1": {
    "clientName": "Crew Clothing Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/754ed685-98cd-496d-8bc0-fd9e4c48e895_crew.png?auto=compress,format"
  },
  "5062_3": {
    "clientName": "Finery London",
    "clientLogo": "https://images.prismic.io/ev-mercury/2c57ce06-df2b-4438-a206-6d206676017e_Finery+154px+x+91px+%28002%29+resized.jpg?auto=compress,format"
  },
  "2208_0": {
    "clientName": "The Perfume Shop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-perfume-shop-logo.jpg"
  },
  "652_111": {
    "clientName": "Trimetals Ltd",
    "clientLogo": null
  },
  "551_61": {
    "clientName": "Garden Pride Marketing Limted",
    "clientLogo": null
  },
  "4110_0": {
    "clientName": "Andrew Lee Home and Living",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "894_1": {
    "clientName": "HQ Hair",
    "clientLogo": null
  },
  "674_0": {
    "clientName": "Zigzag Global",
    "clientLogo": null
  },
  "2485_6": {
    "clientName": "Derbyhouse",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/derby-house-logo.png"
  },
  "840_7": {
    "clientName": "Clearance 365",
    "clientLogo": null
  },
  "975_21": {
    "clientName": "Wish",
    "clientLogo": null
  },
  "479_0": {
    "clientName": "Music Magpie Returns",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/musicmagpie.png"
  },
  "2257_0": {
    "clientName": "Misspap",
    "clientLogo": null
  },
  "628_4": {
    "clientName": "FIFTY PLUS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "733_10": {
    "clientName": "Octopia",
    "clientLogo": "https://images.prismic.io/ev-mercury/e00bdc67-7530-48a7-9d0c-076b1ca742de_Octopia+2+%28002%29.png?auto=compress,format"
  },
  "975_39": {
    "clientName": "Tory Burch",
    "clientLogo": null
  },
  "894_2": {
    "clientName": "Ideal Fit",
    "clientLogo": null
  },
  "652_42": {
    "clientName": "ALF Ltd",
    "clientLogo": null
  },
  "5033_0": {
    "clientName": "Comfort Click Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "109_6": {
    "clientName": "Paul Valentine",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "667_57": {
    "clientName": "Birmingham 5",
    "clientLogo": null
  },
  "551_7": {
    "clientName": "Intermail Limited",
    "clientLogo": null
  },
  "50_15": {
    "clientName": "ITD Printerpix",
    "clientLogo": "https://images.prismic.io/ev-mercury/01b9f78b-51e5-4130-8aca-5fd5bb9b3eb7_printerpix-logo+%28002%29.png?auto=compress,format"
  },
  "647_2": {
    "clientName": "Poetry",
    "clientLogo": null
  },
  "3391_9": {
    "clientName": "Barbary & Oak",
    "clientLogo": "https://images.prismic.io/ev-mercury/6c435e41-d7f8-4bd8-9806-eb42e7b5eeba_Barbary++Oak+Gold+%28002%29+resized.png?auto=compress,format"
  },
  "932_3": {
    "clientName": "MET-RX",
    "clientLogo": null
  },
  "2770_2": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "955_0": {
    "clientName": "Cotton Traders",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/9550000app.png"
  },
  "253_99": {
    "clientName": "hush",
    "clientLogo": "https://images.prismic.io/ev-mercury/d330eae3-3c87-4d9b-b873-adbce4e9d52a_144x144px+hush.png?auto=compress,format"
  },
  "652_126": {
    "clientName": "Kenroy Home",
    "clientLogo": null
  },
  "787_0": {
    "clientName": "Tesco School Uniforms",
    "clientLogo": null
  },
  "551_26": {
    "clientName": "C & W Berry Limited",
    "clientLogo": null
  },
  "631_98": {
    "clientName": "Shandy Shack",
    "clientLogo": "https://images.prismic.io/ev-mercury/e257da0b-f815-4ea2-9186-3346bb5d8218_Shandy+Shack+Logo+Image+%28002%29.png?auto=compress,format"
  },
  "431_0": {
    "clientName": "Direct Link",
    "clientLogo": null
  },
  "273_2": {
    "clientName": "Heritage Pet Products",
    "clientLogo": null
  },
  "912_0": {
    "clientName": "NAKD",
    "clientLogo": null
  },
  "2035_0": {
    "clientName": "Lakeland Returns",
    "clientLogo": null
  },
  "815_0": {
    "clientName": "Monsoon Accessorize",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/monsoon.png"
  },
  "5047_0": {
    "clientName": "SmileDirectClub",
    "clientLogo": "https://images.prismic.io/ev-mercury/3395373a-0661-4a21-b674-97a724167c26_Smile+Direct+Club+-+LOGO+%28002%29.jpeg?auto=compress,format"
  },
  "460_4": {
    "clientName": "EPE International",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "652_45": {
    "clientName": "RCS Logistics/Tee-Zed Products",
    "clientLogo": null
  },
  "652_44": {
    "clientName": "Euroquilt",
    "clientLogo": null
  },
  "223_0": {
    "clientName": "Packlink",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/packlink.png"
  },
  "894_5": {
    "clientName": "Look Fantastic",
    "clientLogo": "https://images.prismic.io/ev-mercury/5834424a-b33c-4e48-9f65-4b2eabc5d95a_lookfantastic.png?auto=compress,format"
  },
  "460_5": {
    "clientName": "Scottish Everlastings Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "652_69": {
    "clientName": "WinGreen",
    "clientLogo": null
  },
  "1960_0": {
    "clientName": "Sira Logistics",
    "clientLogo": null
  },
  "459_0": {
    "clientName": "Worldwide Procurement Ltd",
    "clientLogo": null
  },
  "1067_0": {
    "clientName": "Amazon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon.png"
  },
  "1004_6": {
    "clientName": "YTO",
    "clientLogo": null
  },
  "361_2": {
    "clientName": "Chain Reaction Cycles",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/chain-reaction-cycles.png"
  },
  "652_50": {
    "clientName": "Redhead International",
    "clientLogo": null
  },
  "1023_0": {
    "clientName": "British Heart Foundation ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/amazon-donate.png"
  },
  "3824_0": {
    "clientName": "UK Good Deals",
    "clientLogo": null
  },
  "187_0": {
    "clientName": "Warehouse",
    "clientLogo": "https://images.prismic.io/ev-mercury/d26fa954-f81b-4595-bd7b-fd5b15fc698f_wareh.png?auto=compress,format"
  },
  "253_19": {
    "clientName": "Morph Costumes",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/morph-costumes.png"
  },
  "4280_0": {
    "clientName": "KIIN Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/b1f5cd68-6e31-44d5-9597-c09e060b2504_small+smart.png?auto=compress,format"
  },
  "826_3": {
    "clientName": "Kaleidoscope",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kaleidoscopelogonewmarch21.png"
  },
  "5303_0": {
    "clientName": "CSM Bermondsey",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2035_1": {
    "clientName": "Lakeland Returns for QVC",
    "clientLogo": null
  },
  "3577_0": {
    "clientName": "Schneider-Transport",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "914_14": {
    "clientName": "Landmark Global (Belgium) NV",
    "clientLogo": null
  },
  "652_147": {
    "clientName": "Jonathan Y",
    "clientLogo": null
  },
  "2226_0": {
    "clientName": "Tapi Carpets & Floors",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/22260000app.png"
  },
  "2352_0": {
    "clientName": "Sculpd ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sculpd-pottery-logonew.png"
  },
  "631_26": {
    "clientName": "Guru Makeup Emporium Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310026app.png"
  },
  "2593_2": {
    "clientName": "Face The Future",
    "clientLogo": "https://images.prismic.io/ev-mercury/818595e4-bb64-46a4-b2bf-1667545b1318_face+the+future.png?auto=compress,format"
  },
  "652_43": {
    "clientName": "Danish Design",
    "clientLogo": null
  },
  "5097_0": {
    "clientName": "Laughing Hens",
    "clientLogo": "https://images.prismic.io/ev-mercury/57735d81-b2dc-45e9-afdc-0e959fa4acb6_laughing+hens+resized+.jpg?auto=compress,format"
  },
  "254_3": {
    "clientName": "Chateau Publishing",
    "clientLogo": null
  },
  "2336_0": {
    "clientName": "The Sun on Sunday (BookTrust)",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/sun-on-sunday-logo-for-books-for-kids.png"
  },
  "975_10": {
    "clientName": "Rex Brown",
    "clientLogo": null
  },
  "50_20": {
    "clientName": "ITD Gift Republic ",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/500020.png"
  },
  "3754_0": {
    "clientName": "Staci UK limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "149_0": {
    "clientName": "PROACTIV SKIN HEALTH",
    "clientLogo": null
  },
  "484_0": {
    "clientName": "Bargainmax",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bargainmax-logo.jpg"
  },
  "2964_0": {
    "clientName": "JHM Butt Co LTD",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "160_3": {
    "clientName": "Daily Star Reader Offers",
    "clientLogo": null
  },
  "2443_4": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_41": {
    "clientName": "COBA Europe Ltd",
    "clientLogo": null
  },
  "26_0": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "4695_0": {
    "clientName": "Perfume Direct Limited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "3099_0": {
    "clientName": "CoolRunner ApS",
    "clientLogo": null
  },
  "1942_4": {
    "clientName": "Six Stories",
    "clientLogo": "https://images.prismic.io/ev-mercury/cdf7e0b0-4ecb-4d32-97bb-743bff28a7e5_kArBnFPcixdjcHOzOrpIZiEJvl_1vVgjig+11.1+resized.png?auto=compress,format"
  },
  "287_146": {
    "clientName": "Maison Sassy",
    "clientLogo": "https://images.prismic.io/ev-mercury/256029cf-31b6-4a23-bbf5-786c4e151bfa_Maison+Sassy+Logo+20.12+144x144.jpg?auto=compress,format"
  },
  "2699_9": {
    "clientName": "Personalisation",
    "clientLogo": "https://images.prismic.io/ev-mercury/d203efba-a5fa-4d73-a048-da336ce4040e_PERSONALISATION.png?auto=compress,format"
  },
  "473_33": {
    "clientName": "Noah’s Box",
    "clientLogo": "  https://images.prismic.io/ev-mercury/9f8b58bc-e2a5-4bd6-8253-11934b5e0eb8_noahs+box.jpg?auto=compress,format"
  },
  "886_7": {
    "clientName": "Costco",
    "clientLogo": null
  },
  "51_0": {
    "clientName": "Premiumlamps.co.uk",
    "clientLogo": null
  },
  "551_16": {
    "clientName": "Surgere limited",
    "clientLogo": null
  },
  "551_48": {
    "clientName": "Fenwick Ltd",
    "clientLogo": null
  },
  "932_1": {
    "clientName": "Holland & Barrett",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/newhollandandbarrett.png"
  },
  "628_16": {
    "clientName": "THE BRILLIANT GIFT SHOP",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/jd-williams.png"
  },
  "473_4": {
    "clientName": "GHD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/4730004app.png"
  },
  "652_143": {
    "clientName": "EUCanadianSpaCompany",
    "clientLogo": null
  },
  "253_35": {
    "clientName": "Sinners",
    "clientLogo": null
  },
  "348_0": {
    "clientName": "Webuybooks",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/emails/logos/3480000.png"
  },
  "40_2": {
    "clientName": "Wowcher",
    "clientLogo": null
  },
  "914_24": {
    "clientName": "Perfect Supply Limited",
    "clientLogo": null
  },
  "1941_2": {
    "clientName": "Escapade",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/escapade-logo-144x144px.png"
  },
  "2033_0": {
    "clientName": "Prolife Distribution Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/0977ec44-da8f-4db5-9c23-94efc7c640e8_zendbox+logo.png?auto=compress,format"
  },
  "687_0": {
    "clientName": "Redcats Intu",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "160_25": {
    "clientName": "Fistec",
    "clientLogo": null
  },
  "2749_10": {
    "clientName": "T1TAN",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5043_0": {
    "clientName": "Simply Cake Co",
    "clientLogo": "https://images.prismic.io/ev-mercury/33a5931c-08f8-4b4b-96a6-90b2190ed3f8_simplycake.png?auto=compress,format"
  },
  "253_52": {
    "clientName": "Crew Clothing",
    "clientLogo": null
  },
  "174_0": {
    "clientName": "Lakeland R",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lakeland.png"
  },
  "551_63": {
    "clientName": "UK Flooring Ltd",
    "clientLogo": null
  },
  "117_0": {
    "clientName": "Huxloe Discount Warehouse",
    "clientLogo": null
  },
  "605_0": {
    "clientName": "3P Logistics Sorted",
    "clientLogo": null
  },
  "4131_0": {
    "clientName": "M A Consulting Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/47ba116a-133e-4590-8422-64bc6b8b5256_ma+consulting.png?auto=compress,format"
  },
  "4709_0": {
    "clientName": "Elizabeth Scarlett ",
    "clientLogo": "https://images.prismic.io/ev-mercury/5c24504f-260e-4a43-bf7a-63fe946cecb3_Main+Logo+Rich+BlackESLOGO+NEW.png?auto=compress,format"
  },
  "574_1": {
    "clientName": "Fishtec",
    "clientLogo": null
  },
  "5433_3": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "3999_2": {
    "clientName": "Luxury Grass",
    "clientLogo": "https://images.prismic.io/ev-mercury/0ff06c8e-0c52-49d1-a1d3-1f9e1e25d9d3_LG-logo-evri+%28002%29+11.1+resized+.png?auto=compress,format"
  },
  "2013_0": {
    "clientName": "Retail Distribution",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/rds-logo.png"
  },
  "39_4": {
    "clientName": "BrandAlley",
    "clientLogo": null
  },
  "192_0": {
    "clientName": "Hallmark Homewares Ltd",
    "clientLogo": null
  },
  "5033_1": {
    "clientName": "Weightworld",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "840_10": {
    "clientName": "Lascana",
    "clientLogo": null
  },
  "667_6": {
    "clientName": "Bolton 2",
    "clientLogo": null
  },
  "48_0": {
    "clientName": "Ideal Shopping Direct Ltd",
    "clientLogo": null
  },
  "5639_0": {
    "clientName": "CDB",
    "clientLogo": ""
  },
  "151_63": {
    "clientName": "SCOTTS MENSWEAR",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/scotts.png"
  },
  "5657_0": {
    "clientName": "Killstar",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "975_80": {
    "clientName": "SNS",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "875_5": {
    "clientName": "Littlewoods (Yours Clothing)",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "595_1": {
    "clientName": "UMBRO",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/umbro-logo.jpg"
  },
  "310_17": {
    "clientName": "Hugglepets",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hugglepets-400-x-100.png"
  },
  "940_1": {
    "clientName": "The Klyne Group",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/the-klyne-group.jpg"
  },
  "5258_0": {
    "clientName": "Barking Wholesale Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/bc1b0d58-a6e4-4be8-ba09-ef8b3e7f1044_Full+Logo+Square+EVRi.png?auto=compress,format"
  },
  "5067_4": {
    "clientName": "Dot Pro ",
    "clientLogo": "https://images.prismic.io/ev-mercury/780525ac-f8c5-4463-a115-4cc89ca5a142_Dot+Pro-100.jpg?auto=compress,format"
  },
  "631_80": {
    "clientName": "Wasps RFC",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/6310080app.png"
  },
  "733_1": {
    "clientName": "PUMA",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/puma-logo.png"
  },
  "748_4": {
    "clientName": "QPR",
    "clientLogo": null
  },
  "841_4": {
    "clientName": "Look Again",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lookagain.png"
  },
  "3576_0": {
    "clientName": "Chi Chi London",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/chi-chi-logohighres.png"
  },
  "2770_7": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "826_2": {
    "clientName": "Freemans",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/freemans-new.png"
  },
  "652_108": {
    "clientName": "Woven Magic",
    "clientLogo": null
  },
  "2350_0": {
    "clientName": "Haba Trading B.V. T/A Vida XL",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/haba-trading-b.v..png"
  },
  "873_1": {
    "clientName": "John Lewis & Partners",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/johnlewis.png"
  },
  "2501_0": {
    "clientName": "Pro Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/pds-icon-black.png"
  },
  "963_0": {
    "clientName": "Atlas for men",
    "clientLogo": null
  },
  "5317_1": {
    "clientName": "EVRi",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "652_53": {
    "clientName": "Liberty House Toys Ltd",
    "clientLogo": null
  },
  "5062_5": {
    "clientName": "Sonisk Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/4357ac99-9e6e-4043-a1c9-5320fa254460_Sonisk_Logo_Evri_144x144pxs.jpg?auto=compress,format"
  },
  "471_0": {
    "clientName": "Lounge by Zalando",
    "clientLogo": "https://images.prismic.io/ev-mercury/c605c45a-b6cb-4ff1-ad92-1b82ffba374f_lounge+by+zalando+resized.png?auto=compress,format"
  },
  "57_0": {
    "clientName": "LPP SA",
    "clientLogo": null
  },
  "5509_0": {
    "clientName": "Bargains 4 Ever",
    "clientLogo": "https://images.prismic.io/ev-mercury/98627a1a-c8eb-47e3-81c1-9ec9b85ec819_bargains+4+ever+logo.png?auto=compress,format"
  },
  "831_37": {
    "clientName": "Pepe Jeans Zalando",
    "clientLogo": null
  },
  "320_9": {
    "clientName": "HEAD",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/head-logo.png"
  },
  "649_0": {
    "clientName": "ITD Global Ltd",
    "clientLogo": null
  },
  "2551_0": {
    "clientName": "Tommee Tippee",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/tommeetippee_144x144.jpg"
  },
  "2699_21": {
    "clientName": "Liverpool FC",
    "clientLogo": "https://images.prismic.io/ev-mercury/847b3cf3-6c58-4f0d-99bf-61a12860d8e9_LIVERPOOLFC.png?auto=compress,format"
  },
  "886_3": {
    "clientName": "Comfy Group",
    "clientLogo": null
  },
  "5433_1": {
    "clientName": "AS Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "827_0": {
    "clientName": "Kurt Geiger",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kurtgeiger.png"
  },
  "652_27": {
    "clientName": "Mike Miller Associates Ltd",
    "clientLogo": null
  },
  "827_1": {
    "clientName": "Shoeaholics",
    "clientLogo": null
  },
  "975_6": {
    "clientName": "BootiqueShop",
    "clientLogo": null
  },
  "2356_0": {
    "clientName": "Wallis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/23560000app.png"
  },
  "999_7": {
    "clientName": "Natusan",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/natusan-logo.jpeg"
  },
  "631_117": {
    "clientName": "Revibed ",
    "clientLogo": "https://images.prismic.io/ev-mercury/b1e5d6c3-e1f2-488a-b99f-689cbee5224a_revibed+logo+%281%29.png?auto=compress,format"
  },
  "5256_0": {
    "clientName": "Gym King",
    "clientLogo": "https://images.prismic.io/ev-mercury/0bff6321-f339-416e-9ae9-ee6c01333702_gym+king.png?auto=compress,format"
  },
  "785_15": {
    "clientName": "LK Health",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lk-health-logo.png"
  },
  "902_0": {
    "clientName": "KBF Enterprises Ltd",
    "clientLogo": null
  },
  "160_13": {
    "clientName": "ProteinStop",
    "clientLogo": null
  },
  "4587_0": {
    "clientName": "FUNIDELIA",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "460_3": {
    "clientName": "Daxon",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "408_6": {
    "clientName": "mitre",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mitre.png"
  },
  "458_1": {
    "clientName": "Direct to Depot?",
    "clientLogo": null
  },
  "652_20": {
    "clientName": "GET Ltd",
    "clientLogo": null
  },
  "598_0": {
    "clientName": "Deltamail",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/deltamail-logo.png"
  },
  "652_1": {
    "clientName": "HIB",
    "clientLogo": null
  },
  "99_0": {
    "clientName": "Debenhams Trafford Centre",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "287_1": {
    "clientName": "UK Posting Ltd",
    "clientLogo": null
  },
  "2749_24": {
    "clientName": "BRUNA Jewellery",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "2132_0": {
    "clientName": "ZTP",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/shein-logonew.png"
  },
  "975_23": {
    "clientName": "Fossil",
    "clientLogo": null
  },
  "2244_0": {
    "clientName": "REISS Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/reiss-logonew.png"
  },
  "2770_3": {
    "clientName": "Dunelm",
    "clientLogo": "https://images.prismic.io/ev-mercury/81533168-b9e4-4227-add0-7b5900ba00ed_Dunelm+LOGO+144x144.jpg?auto=compress,format"
  },
  "631_122": {
    "clientName": "Qwerty Beer Box",
    "clientLogo": "https://images.prismic.io/ev-mercury/c851f09c-6f83-4c83-bc94-4e80c2ba3e08_qwerty.png?auto=compress,format"
  },
  "975_103": {
    "clientName": "Lyle & Scott Returns",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "759_999": {
    "clientName": "Hub Europe - Feelunique.com",
    "clientLogo": null
  },
  "310_15": {
    "clientName": "Beauty Kicks",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beautykick-logo.png"
  },
  "724_0": {
    "clientName": "Cycleon B.V",
    "clientLogo": null
  },
  "492_51": {
    "clientName": "MRZ Stationery Distribution LTD",
    "clientLogo": null
  },
  "589_0": {
    "clientName": "Miisee Limited",
    "clientLogo": null
  },
  "2215_4": {
    "clientName": "Sobuy",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/e29ff619500d10cec395009f01ed2ca.png"
  },
  "802_0": {
    "clientName": "Debenhams Direct",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/8020000app.png"
  },
  "253_3": {
    "clientName": "Yumi",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/yumi.png"
  },
  "772_7": {
    "clientName": "Origins",
    "clientLogo": null
  },
  "253_5": {
    "clientName": "Live Unlimited",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "817_3": {
    "clientName": "Strivectin",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "4514_5": {
    "clientName": "Terrys Fabrics",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "4976_0": {
    "clientName": "ConfidenceClub",
    "clientLogo": "https://images.prismic.io/ev-mercury/ffeaf4d5-1d41-466f-ad14-286071f8e655_cc-icon-144x144.png?auto=compress,format"
  },
  "408_1": {
    "clientName": "Kickers",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kickers.png"
  },
  "551_56": {
    "clientName": "Skin Research Ltd",
    "clientLogo": null
  },
  "492_43": {
    "clientName": "Super Smart Services Ltd",
    "clientLogo": null
  },
  "2749_7": {
    "clientName": "Fundis",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "3854_0": {
    "clientName": "Lights 4 Fun",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/lights4fun_144x144.jpg"
  },
  "4349_0": {
    "clientName": "wall art prints",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "652_99": {
    "clientName": "HighgateBedsLtd-Bretton",
    "clientLogo": null
  },
  "2231_1": {
    "clientName": "SLEEPEEZEE",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/22310001app.png"
  },
  "2645_0": {
    "clientName": "Savage X",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/0000001-savage-x.png"
  },
  "115_0": {
    "clientName": "Debenhams Cardiff",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/debenhams-new.png"
  },
  "368_18": {
    "clientName": "Whistl",
    "clientLogo": null
  },
  "362_2": {
    "clientName": "Free Returns",
    "clientLogo": null
  },
  "5014_0": {
    "clientName": "Army & Outdoors",
    "clientLogo": "https://images.prismic.io/ev-mercury/e681ff30-3b3a-4bc4-a81d-926f003bc393_default-logo.png?auto=compress,format"
  },
  "103_2": {
    "clientName": "SDF NXT",
    "clientLogo": null
  },
  "652_161": {
    "clientName": "Baumhaus",
    "clientLogo": null
  },
  "5663_1": {
    "clientName": "National Gallery",
    "clientLogo": "https://images.prismic.io/ev-mercury/551811eb-bc1e-4835-a089-6be4af03349c_national+gallery+logo.png?auto=compress,format"
  },
  "592_0": {
    "clientName": "Elixir Garden Supplies",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/5920000app.png"
  },
  "2745_0": {
    "clientName": "Tower London",
    "clientLogo": "https://images.prismic.io/ev-mercury/9b6277ab-696e-4289-8f55-cd59d1917141_Picture1.png?auto=compress,format"
  },
  "4658_0": {
    "clientName": "Mobile Fun Limited",
    "clientLogo": "https://images.prismic.io/ev-mercury/2598f364-548b-4f52-92ea-8f604cd6c816_Circle-Icon-Primary+%281%29+%28002%29+resized.png?auto=compress,format"
  },
  "473_25": {
    "clientName": "Moccy Moo",
    "clientLogo": "https://images.prismic.io/ev-mercury/07320af8-ffb7-45ba-b395-1381e68a96e7_Moccy+moo+Evri+logo+144x144.png?auto=compress,format"
  },
  "185_1": {
    "clientName": "Hawkshead",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/hawkshead.png"
  },
  "287_5": {
    "clientName": "Winfields Limited",
    "clientLogo": null
  },
  "667_19": {
    "clientName": "Bristol 3",
    "clientLogo": null
  },
  "492_39": {
    "clientName": "SRG",
    "clientLogo": null
  },
  "104_1": {
    "clientName": "Tesco",
    "clientLogo": null
  },
  "652_22": {
    "clientName": "Eden H Limited",
    "clientLogo": null
  },
  "2578_1": {
    "clientName": "With Ukraine",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "683_2": {
    "clientName": "BeautyBay - BeautyBay Premium",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/beauty-bay.png"
  },
  "289_0": {
    "clientName": "Desiretech",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/desire-london.png"
  },
  "48_1": {
    "clientName": "Deramores",
    "clientLogo": null
  },
  "847_2": {
    "clientName": "Ace",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/ace-from-studio.png"
  },
  "460_2": {
    "clientName": "Vertbaudet",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/la-redoute.png"
  },
  "160_0": {
    "clientName": "BVG",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/bvg.png"
  },
  "827_2": {
    "clientName": "Nine West",
    "clientLogo": null
  },
  "4914_0": {
    "clientName": "Confidence Club ",
    "clientLogo": "https://images.prismic.io/ev-mercury/ffeaf4d5-1d41-466f-ad14-286071f8e655_cc-icon-144x144.png?auto=compress,format"
  },
  "1963_5": {
    "clientName": "Steel Toe Boots",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/stb-logo.png"
  },
  "312_1": {
    "clientName": "Kings will Dream",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/kingswilldream.png"
  },
  "716_0": {
    "clientName": "Larra Limited",
    "clientLogo": null
  },
  "551_32": {
    "clientName": "Digiflex",
    "clientLogo": null
  },
  "272_6": {
    "clientName": "smarTrike",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/smartrike-logo.png"
  },
  "652_35": {
    "clientName": "Gillerson Pine",
    "clientLogo": null
  },
  "841_5": {
    "clientName": "Curvissa",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/curvissa.png"
  },
  "63_0": {
    "clientName": "Drinkstuff",
    "clientLogo": null
  },
  "2749_17": {
    "clientName": "Driftelement",
    "clientLogo": "https://images.prismic.io/ev-mercury/ed64c156-21da-45e5-b800-c03cf9057807_driftelement-logo-wide-ORIGINAL.png?auto=compress,format"
  },
  "999_3": {
    "clientName": "Tesco",
    "clientLogo": null
  },
  "435_0": {
    "clientName": "Lesara 1",
    "clientLogo": null
  },
  "2485_3": {
    "clientName": "Webtogs",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/webtogs-logo.png"
  },
  "3865_0": {
    "clientName": "Fyne Packaging Ltd",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/default-logo.png"
  },
  "5281_1": {
    "clientName": "Christy",
    "clientLogo": "https://images.prismic.io/ev-mercury/04bcb47c-b61c-475c-be1b-9f1a9553cd88_Christy+Logo_154+x+91px+%28002%29.jpg?auto=compress,format"
  },
  "607_0": {
    "clientName": "ITD",
    "clientLogo": null
  },
  "1637_6": {
    "clientName": "Red Candy",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/redcandylogonew.jpg"
  },
  "4124_0": {
    "clientName": "The Original Factory Shop",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/2line-logo-lozenge-002-.png"
  },
  "5628_0": {
    "clientName": "Robust Car Parts Ltd",
    "clientLogo": "https://images.prismic.io/ev-mercury/bf4eb3b5-0542-453c-810a-e25a41aede25_robust.png?auto=compress,format"
  },
  "492_35": {
    "clientName": "Moss Bros",
    "clientLogo": null
  },
  "914_16": {
    "clientName": "Rustrock Limited",
    "clientLogo": null
  },
  "488_0": {
    "clientName": "Litecraft",
    "clientLogo": null
  },
  "291_0": {
    "clientName": "Look N Buy",
    "clientLogo": "https://www.myhermes.co.uk/_assets/images/logos/mass-dynamics-look-n-buy-.png"
  },
  "287_4": {
    "clientName": "Classique Fashions Limited",
    "clientLogo": null
  },
  "975_69": {
    "clientName": "GYM+COFFEE",
    "clientLogo": null
  },
  "72_0": {
    "clientName": "Whistl",
    "clientLogo": null
  }
};