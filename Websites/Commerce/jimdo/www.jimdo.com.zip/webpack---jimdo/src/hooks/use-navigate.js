export const useNavigate = () => {
  throw new Error(
    "useNavigate is removed. Use import { navigate } from 'gatsby' instead"
  )
}
