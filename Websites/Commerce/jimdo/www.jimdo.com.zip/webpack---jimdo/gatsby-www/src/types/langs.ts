export enum Langs {
    EN_US = 'en-US',
    DE_DE = 'de-DE',
    NL_NL = 'nl-NL',
    ES_ES = 'es-ES',
    FR_FR = 'fr-FR',
    IT_IT = 'it-IT',
    JA_JP = 'ja-JP',
}
