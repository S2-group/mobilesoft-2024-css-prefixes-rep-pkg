exports.phraseAppConfig = {
    projectId: 'c2ffa9c4d21569d2741de39b0bd8b4c0',
    prefix: '{{__',
    suffix: '__}}',
    fullReparse: true,
    enabled: true,
    debugMode: true,
    ajaxObserver: false,
    autoLowercase: false,
    forceLocale: 'en-US',
};
